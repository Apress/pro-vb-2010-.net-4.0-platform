﻿Module Module1
    Sub Main()

        Console.WriteLine("***** Welcome to MyTypeViewer *****")
        Dim typeName As String = ""

        Do
            Console.WriteLine(vbLf & "Enter a type name to evaluate")
            Console.Write("or enter Q to quit: ")

            ' Get name of type.
            typeName = Console.ReadLine()

            ' Does user want to quit?
            If typeName.ToUpper() = "Q" Then
                Exit Do
            End If

            ' Try to display type.
            Try
                Dim t As Type = Type.GetType(typeName)
                Console.WriteLine("")
                ListVariousStats(t)
                ListFields(t)
                ListProps(t)
                ListMethods(t)
                ListInterfaces(t)
            Catch
                Console.WriteLine("Sorry, can't find type")
            End Try
        Loop While True
    End Sub
#Region "Helper methods"
    ' Display method names of type.
    Sub ListMethods(ByVal t As Type)
        Console.WriteLine("***** Methods *****")
        Dim methodNames = From n In t.GetMethods() _
          Select n
        For Each name In methodNames
            Console.WriteLine("->{0}", name)
        Next
        Console.WriteLine()
    End Sub

    ' Display field names of type.
    Sub ListFields(ByVal t As Type)
        Console.WriteLine("***** Fields *****")
        Dim fieldNames = From f In t.GetFields() _
                         Select f.Name
        For Each name In fieldNames
            Console.WriteLine("->{0}", name)
        Next
        Console.WriteLine()
    End Sub

    ' Display property names of type.
    Sub ListProps(ByVal t As Type)
        Console.WriteLine("***** Properties *****")
        Dim propNames = From p In t.GetProperties() _
                        Select p.Name
        For Each name In propNames
            Console.WriteLine("->{0}", name)
        Next
        Console.WriteLine()
    End Sub

    ' Display implemented interfaces.
    Sub ListInterfaces(ByVal t As Type)
        Console.WriteLine("***** Interfaces *****")
        Dim ifaces = From i In t.GetInterfaces() _
                     Select i
        For Each i As Type In ifaces
            Console.WriteLine("->{0}", i.Name)
        Next
    End Sub

    ' Just for good measure.
    Sub ListVariousStats(ByVal t As Type)
        Console.WriteLine("***** Various Statistics *****")
        Console.WriteLine("Base class is: {0}", t.BaseType)
        Console.WriteLine("Is type abstract? {0}", t.IsAbstract)
        Console.WriteLine("Is type sealed? {0}", t.IsSealed)
        Console.WriteLine("Is type generic? {0}", t.IsGenericTypeDefinition)
        Console.WriteLine("Is type a class type? {0}", t.IsClass)
        Console.WriteLine()
    End Sub
#End Region
End Module
