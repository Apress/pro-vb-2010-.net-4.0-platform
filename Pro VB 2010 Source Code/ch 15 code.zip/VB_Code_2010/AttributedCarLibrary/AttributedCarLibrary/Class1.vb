﻿<Assembly: CLSCompliant(True)> 

'A custom attribute.
<AttributeUsage(AttributeTargets.Class Or AttributeTargets.Struct, AllowMultiple:=False, Inherited:=False)> _
Public NotInheritable Class VehicleDescriptionAttribute
    Inherits System.Attribute

    Public Property Description() As String

    Public Sub New(ByVal vehicalDescription As String)
        Description = vehicalDescription
    End Sub
    Public Sub New()
    End Sub
End Class
<Serializable()> _
<VehicleDescription(Description:="My rocking Harley")> _
Public Class Motorcycle
End Class
<SerializableAttribute()> _
<ObsoleteAttribute("Use another vehicle!")> _
<VehicleDescription("The old gray mare, she ain't what she used to be...")> _
Public Class HorseAndBuggy
End Class
<VehicleDescription("A very long, slow, but feature-rich auto")> _
Public Class Winnebago

End Class


