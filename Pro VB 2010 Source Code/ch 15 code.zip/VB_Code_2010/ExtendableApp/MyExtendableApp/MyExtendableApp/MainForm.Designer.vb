﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mainMenuStrip = New System.Windows.Forms.MenuStrip()
        Me.fileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SnapInModuleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lstLoadedSnapIns = New System.Windows.Forms.ListBox()
        Me.mainMenuStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'mainMenuStrip
        '
        Me.mainMenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.fileToolStripMenuItem})
        Me.mainMenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.mainMenuStrip.Name = "mainMenuStrip"
        Me.mainMenuStrip.Size = New System.Drawing.Size(509, 24)
        Me.mainMenuStrip.TabIndex = 0
        Me.mainMenuStrip.Text = "MenuStrip1"
        '
        'fileToolStripMenuItem
        '
        Me.fileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SnapInModuleToolStripMenuItem})
        Me.fileToolStripMenuItem.Name = "fileToolStripMenuItem"
        Me.fileToolStripMenuItem.Size = New System.Drawing.Size(35, 20)
        Me.fileToolStripMenuItem.Text = "File"
        '
        'SnapInModuleToolStripMenuItem
        '
        Me.SnapInModuleToolStripMenuItem.Name = "SnapInModuleToolStripMenuItem"
        Me.SnapInModuleToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.SnapInModuleToolStripMenuItem.Text = "Snap In Module..."
        '
        'lstLoadedSnapIns
        '
        Me.lstLoadedSnapIns.FormattingEnabled = True
        Me.lstLoadedSnapIns.Location = New System.Drawing.Point(12, 37)
        Me.lstLoadedSnapIns.Name = "lstLoadedSnapIns"
        Me.lstLoadedSnapIns.Size = New System.Drawing.Size(485, 186)
        Me.lstLoadedSnapIns.TabIndex = 1
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(509, 245)
        Me.Controls.Add(Me.lstLoadedSnapIns)
        Me.Controls.Add(Me.mainMenuStrip)
        Me.mainMenuStrip = Me.mainMenuStrip
        Me.Name = "MainForm"
        Me.Text = "My Extenisble App!"
        Me.mainMenuStrip.ResumeLayout(False)
        Me.mainMenuStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents mainMenuStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents fileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SnapInModuleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lstLoadedSnapIns As System.Windows.Forms.ListBox

End Class
