﻿Imports System.Reflection
Imports CommonSnappableTypes.CommonSnappableTypes

Public Class MainForm
#Region "Menu handler"
    Sub SnapInModuleToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SnapInModuleToolStripMenuItem.Click
        'Allow user to select an assembly to load.
        Dim dlg As New OpenFileDialog()
        If dlg.ShowDialog() = DialogResult.OK Then
            If dlg.FileName.Contains("CommonSnappableTypes") Then
                MessageBox.Show("CommonSnappableTypes has no snap-ins!")
            ElseIf Not LoadExternalModule(dlg.FileName) Then
                MessageBox.Show("Nothing implements IAppFunctionality!")
            End If
        End If
    End Sub
#End Region

#Region "Load external assembly"
    Function LoadExternalModule(ByVal path As String) As Boolean
        Dim foundSnapIn As Boolean = False
        Dim theSnapInAsm As Assembly = Nothing
        Try
            'Dynamically load the selected assembly.
            theSnapInAsm = Assembly.LoadFrom(path)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            Return foundSnapIn
        End Try
        'Get all IAppFunctionality compatible classes in assembly.
        Dim theClassTypes = From t In theSnapInAsm.GetTypes() _
                            Where t.IsClass AndAlso (t.GetInterface("IAppFunctionality") _
                                                     IsNot Nothing) _
                            Select t
        'Now, create the object and call DoIt() method.
        For Each t As Type In theClassTypes
            foundSnapIn = True
            'Use late binding to create the type.
            Dim itfApp As IAppFunctionality = DirectCast(theSnapInAsm.CreateInstance(t.FullName, True), IAppFunctionality)
            itfApp.DoIt()
            lstLoadedSnapIns.Items.Add(t.FullName)
            'Show company info.
            DisplayCompanyData(t)
        Next
        Return foundSnapIn
    End Function
#End Region


#Region "Show company info"
    Private Sub DisplayCompanyData(ByVal t As Type)
        'Get <CompanyInfo> data.
        Dim compInfo = From ci In t.GetCustomAttributes(False) _
         Where (ci.GetType() = GetType(CompanyInfoAttribute)) _
         Select ci
        ' Show data.
        For Each c As CompanyInfoAttribute In compInfo
            MessageBox.Show(c.CompanyUrl, String.Format("More info about {0} can be found at", c.CompanyName))
        Next
    End Sub
#End Region

End Class
