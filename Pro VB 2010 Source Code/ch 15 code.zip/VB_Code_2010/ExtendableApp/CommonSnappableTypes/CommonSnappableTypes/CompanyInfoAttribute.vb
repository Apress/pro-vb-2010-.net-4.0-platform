﻿Namespace CommonSnappableTypes
    Public Interface IAppFunctionality
        Sub DoIt()
    End Interface
    <AttributeUsage(AttributeTargets.Class)> _
    Public NotInheritable Class CompanyInfoAttribute
        Inherits System.Attribute
        Public Property CompanyName() As String

        Public Property CompanyUrl() As String

    End Class
End Namespace
