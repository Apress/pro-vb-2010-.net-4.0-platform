﻿Imports AttributedCarLibrary
Module Module1

    Sub Main()
        Console.WriteLine("***** Value of VehicleDescriptionAttribute *****" & vbLf)
        ReflectOnAttributesWithEarlyBinding()
        Console.ReadLine()
    End Sub
    Sub ReflectOnAttributesWithEarlyBinding()
        'Get a Type representing the Winnebago.
        Dim t As Type = GetType(Winnebago)
        'Get all attributes on the Winnebago.
        Dim customAtts As Object() = t.GetCustomAttributes(False)
        'Print the description.
        For Each v As VehicleDescriptionAttribute In customAtts
            Console.WriteLine("-> {0}" & vbLf, v.Description)
        Next
    End Sub
End Module
