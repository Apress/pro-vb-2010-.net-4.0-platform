﻿Imports System.Reflection
Imports System.IO

'This program will load an external library, 
'and create an object using late binding.
Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Late Binding *****")
        'Try to load a local copy of CarLibrary.
        Dim a As Assembly = Nothing
        Try
            a = Assembly.Load("CarLibrary")
        Catch ex As FileNotFoundException
            Console.WriteLine(ex.Message)
            Return
        End Try
        If a IsNot Nothing Then
            CreateUsingLateBinding(a)
            InvokeMethodWithArgsUsingLateBinding(a)
        End If
        Console.ReadLine()
    End Sub

#Region "Invoke method with no args"
    Sub CreateUsingLateBinding(ByVal asm As Assembly)
        Try
            'Get metadata for the MiniVan type.
            Dim miniVanType As Type = asm.GetType("CarLibrary.MiniVan")
            ' Create the MiniVan on the fly.
            Dim obj As Object = Activator.CreateInstance(miniVanType)

            Console.WriteLine("Created a {0} using late binding!", obj)
            'Get info for TurboBoost.
            Dim mi As MethodInfo = miniVanType.GetMethod("TurboBoost")
            'Invoke method ('Nothing' for no parameters).
            mi.Invoke(obj, Nothing)
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try
    End Sub
#End Region

#Region "Invoke method with args"
    Sub InvokeMethodWithArgsUsingLateBinding(ByVal asm As Assembly)
        Try
            'First, get a metadata description of the sports car. 
            Dim sport As Type = asm.GetType("CarLibrary.SportsCar")
            'Now, create the sports car.
            Dim obj As Object = Activator.CreateInstance(sport)
            'Invoke TurnOnRadio() with arguments.
            Dim mi As MethodInfo = sport.GetMethod("TurnOnRadio")
            mi.Invoke(obj, New Object() {True, 2})
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try
    End Sub
#End Region

End Module
