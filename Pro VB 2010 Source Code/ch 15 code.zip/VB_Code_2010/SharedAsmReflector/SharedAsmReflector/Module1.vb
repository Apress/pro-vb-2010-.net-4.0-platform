﻿Imports System.Reflection

Module Module1
#Region "DisplayInfo helper method"
    Sub DisplayInfo(ByVal a As Assembly)
        Console.WriteLine("***** Info about Assembly *****")
        Console.WriteLine("Loaded from GAC? {0}", a.GlobalAssemblyCache)
        Console.WriteLine("Asm Name: {0}", a.GetName().Name)
        Console.WriteLine("Asm Version: {0}", a.GetName().Version)
        Console.WriteLine("Asm Culture: {0}", a.GetName().CultureInfo.DisplayName)
        Console.WriteLine(vbLf & "Here are the public enums:")

        'Use a LINQ query to find the public enums.
        Dim types As Type() = a.GetTypes()
        Dim publicEnums = From pe In types _
                          Where pe.IsEnum AndAlso pe.IsPublic _
                          Select pe
        For Each pe In types
            Console.WriteLine(pe)
        Next
    End Sub
#End Region

    Sub Main()
        Console.WriteLine("***** The Shared Asm Reflector App *****" & vbLf)

        'Load System.Windows.Forms.dll from GAC.
        Dim displayName As String = "System.Windows.Forms," & "Version=4.0.0.0," & "PublicKeyToken=b77a5c561934e089," & "Culture="""
        Dim asm As Assembly = Assembly.Load(displayName)
        DisplayInfo(asm)
        Console.WriteLine("Done!")
        Console.ReadLine()

    End Sub

End Module
