﻿Module Module1
    Sub Main()
        Dim mule As New HorseAndBuggy()
    End Sub
End Module

#Region "Simple classes for testing"
'This class can be saved to disk.
<Serializable()> _
Public Class Motorcycle
    'However this field will not be persisted.

    <NonSerialized()> _
    Private weightOfCurrentPassengers As Single
    ''These fields are still serializable.
    Private hasRadioSystem As Boolean
    Private hasHeadSet As Boolean
    Private hasSissyBar As Boolean
End Class

<Serializable(), Obsolete("Use another vehicle!")> _
Public Class HorseAndBuggy
    '....
End Class
#End Region