﻿Imports System.Reflection

Module Module1
#Region "Helper function"
    Sub DisplayTypesInAsm(ByVal asm As Assembly)
        Console.WriteLine(vbLf & "***** Types in Assembly *****")
        Console.WriteLine("->{0}", asm.FullName)
        Dim types As Type() = asm.GetTypes()
        For Each t As Type In types
            Console.WriteLine("Type: {0}", t)
        Next
        Console.WriteLine("")
    End Sub
#End Region
    Sub Main()
        Console.WriteLine("***** External Assembly Viewer *****")
        Dim asmName As String = ""
        Dim asm As Assembly = Nothing
        Do
            Console.WriteLine(vbLf & "Enter an assembly to evaluate")
            Console.Write("or enter Q to quit: ")
            'Get name of assembly.
            asmName = Console.ReadLine()
            If asmName.ToUpper() = "Q" Then
                Exit Do
            End If
            'Try to load assembly.
            Try
                asm = Assembly.Load(asmName)
                DisplayTypesInAsm(asm)
            Catch
                Console.WriteLine("Sorry, can't find assembly.")
            End Try
        Loop While True
    End Sub

End Module
