﻿Imports System.Reflection

Module Module1

    Sub Main()
        Console.WriteLine("***** Value of VehicleDescriptionAttribute *****" & vbLf)
        ReflectAttributesUsingLateBinding()
    
        Console.ReadLine()
    End Sub
#Region "Helper method"
    Sub ReflectAttributesUsingLateBinding()
        Try
            'Load the local copy of AttributedCarLibrary.
            Dim asm As Assembly = Assembly.Load("AttributedCarLibrary")

            'Get type info of VehicleDescriptionAttribute.
            Dim vehicleDesc As Type = asm.GetType("AttributedCarLibrary.VehicleDescriptionAttribute")

            'Get type info of the Description property.
            Dim propDesc As PropertyInfo = vehicleDesc.GetProperty("Description")

            ' Get all types in the assembly.
            Dim types As Type() = asm.GetTypes()

            'Iterate over each type and obtain any VehicleDescriptionAttributes.
            For Each t As Type In types
                Dim objs As Object() = t.GetCustomAttributes(vehicleDesc, False)
                'Iterate over each VehicleDescriptionAttribute and print
                'the description using late binding.
                For Each o As Object In objs
                    Console.WriteLine("-> {0}: {1}" & vbLf, t.Name, propDesc.GetValue(o, Nothing))
                Next
            Next
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try
    End Sub
#End Region

End Module
