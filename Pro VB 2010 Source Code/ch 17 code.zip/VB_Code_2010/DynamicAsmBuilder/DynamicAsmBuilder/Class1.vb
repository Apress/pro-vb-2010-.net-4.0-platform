﻿Public Class Class1
    Shared Function Add(ByVal x As Integer, ByVal y As Integer) As Integer
        Return x + y
    End Function
    Public Sub PrintMessage()
        Dim myMessage As String = "Hello."
        Console.WriteLine(myMessage)
    End Sub
End Class

