﻿'Need these!
Imports System.Reflection
Imports System.Reflection.Emit
Imports System.Threading

Module Module1

    Sub Main()
        Console.WriteLine("***** The Amazing Dynamic Assembly Builder App *****")

        'Get the application domain for the current thread.
        Dim curAppDomain As AppDomain = Thread.GetDomain()

        'Create the dynamic assembly using our helper method.
        CreateMyAsm(curAppDomain)
        Console.WriteLine("-> Finished creating MyAssembly.dll.")

        'Now load the new assembly from file.
        Console.WriteLine("-> Loading MyAssembly.dll from file.")
        Dim a As Assembly = Assembly.Load("MyAssembly")

        'Get the HelloWorld type.
        Dim hello As Type = a.GetType("MyAssembly.HelloWorld")

        'Create HelloWorld object and call the correct ctor.
        Console.Write("-> Enter message to pass HelloWorld class: ")
        Dim msg As String = Console.ReadLine()
        Dim ctorArgs As Object() = New Object(0) {}
        ctorArgs(0) = msg
        Dim obj As Object = Activator.CreateInstance(hello, ctorArgs)

        'Call SayHello and show returned string.
        Console.WriteLine("-> Calling SayHello() via late binding.")
        Dim mi As MethodInfo = hello.GetMethod("SayHello")
        mi.Invoke(obj, Nothing)

        'Invoke method. 
        mi = hello.GetMethod("GetMsg")
        Console.WriteLine(mi.Invoke(obj, Nothing))
        Console.ReadLine()
    End Sub

#Region "Dynamic assembly creation method"
    'The caller sends in an AppDomain type.
    Public Sub CreateMyAsm(ByVal curAppDomain As AppDomain)

        'Establish general assembly characteristics.
        Dim assemblyName As New AssemblyName()
        assemblyName.Name = "MyAssembly"
        assemblyName.Version = New Version("1.0.0.0")

        'Create new assembly within the current AppDomain.
        Dim assembly As AssemblyBuilder = curAppDomain.DefineDynamicAssembly(assemblyName, AssemblyBuilderAccess.Save)

        '  Given that we are building a single-file
        ' assembly, the name of the module is the same as the assembly.
        Dim theMod As ModuleBuilder = assembly.DefineDynamicModule("MyAssembly", "MyAssembly.dll")

        'Define a public class named "MyAssembly.HelloWorld".
        Dim helloWorldClass As TypeBuilder = theMod.DefineType("MyAssembly.HelloWorld", TypeAttributes.Public)

        'Define a private String member variable named "theMessage".
        Dim msgField As FieldBuilder = helloWorldClass.DefineField("theMessage", Type.GetType("System.String"), FieldAttributes.Private)

        'Create the custom ctor.
        Dim constructorArgs As Type() = New Type(0) {}
        constructorArgs(0) = GetType(String)
        Dim constructor As ConstructorBuilder = helloWorldClass.DefineConstructor(MethodAttributes.Public, CallingConventions.Standard, constructorArgs)
        Dim constructorIL As ILGenerator = constructor.GetILGenerator()
        constructorIL.Emit(OpCodes.Ldarg_0)
        Dim objectClass As Type = GetType(Object)
        Dim superConstructor As ConstructorInfo = objectClass.GetConstructor(New Type() {})
        constructorIL.Emit(OpCodes.Call, superConstructor)
        constructorIL.Emit(OpCodes.Ldarg_0)
        constructorIL.Emit(OpCodes.Ldarg_1)
        constructorIL.Emit(OpCodes.Stfld, msgField)
        constructorIL.Emit(OpCodes.Ret)

        'Create the default ctor.
        helloWorldClass.DefineDefaultConstructor(MethodAttributes.Public)

        ' Now create the GetMsg() method.
        Dim getMsgMethod As MethodBuilder = helloWorldClass.DefineMethod("GetMsg", MethodAttributes.Public, GetType(String), Nothing)
        Dim methodIL As ILGenerator = getMsgMethod.GetILGenerator()
        methodIL.Emit(OpCodes.Ldarg_0)
        methodIL.Emit(OpCodes.Ldfld, msgField)
        methodIL.Emit(OpCodes.Ret)

        'Create the SayHello method.
        Dim sayHiMethod As MethodBuilder = helloWorldClass.DefineMethod("SayHello", MethodAttributes.Public, Nothing, Nothing)
        methodIL = sayHiMethod.GetILGenerator()
        methodIL.EmitWriteLine("Hello from the HelloWorld class!")
        methodIL.Emit(OpCodes.Ret)

        ' 'Bake' the class HelloWorld.
        '(Baking is the formal term for emitting the type)

        helloWorldClass.CreateType()
        '(Optionally) save the assembly to file.
        assembly.Save("MyAssembly.dll")
    End Sub
#End Region
End Module
