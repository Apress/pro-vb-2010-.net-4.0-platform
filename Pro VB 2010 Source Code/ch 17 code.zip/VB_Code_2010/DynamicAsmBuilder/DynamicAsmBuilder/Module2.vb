﻿'A simple VB 2010 console app.
'Note that we are not wrapping our class in a namespace, 
'to help simplify the generated CIL code. 
Module Module2
    Sub Main()
        Console.WriteLine("Hello CIL code!")
        Console.ReadLine()
    End Sub
End Module