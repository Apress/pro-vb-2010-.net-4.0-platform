﻿
Module Calc

    Sub Main()
        Dim c As New Calc()
        Dim ans As Integer = c.Add(10, 84)
        Console.WriteLine("10 + 84 is {0}.", ans)

        ' Wait for user to press the Enter key before shutting down.
        Console.ReadLine()
    End Sub
    Public Class Calc
        Public Function Add(ByVal x As Integer, ByVal y As Integer) As Integer

            Return x + y
        End Function
    End Class
End Module
