﻿Imports System.Activities
Imports CheckInventoryWorkflowLib

Module Module1

    Sub Main()
        Console.WriteLine("**** Inventory Look up ****")

        ' Get user preferences.
        Console.Write("Enter Color: ")
        Dim color As String = Console.ReadLine()
        Console.Write("Enter Make: ")
        Dim make As String = Console.ReadLine()

        ' Package up data for workflow.
        Dim wfArgs As New Dictionary(Of String, Object)() From {{"RequestedColor", color}, {"RequestedMake", make}}

        Try
            ' Send data to workflow!
            Dim outputArgs As IDictionary(Of String, Object) = WorkflowInvoker.Invoke(New CheckInventory(), wfArgs)
            Console.WriteLine(outputArgs("FormattedResponse"))
            Console.ReadLine()
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try

    End Sub

End Module
