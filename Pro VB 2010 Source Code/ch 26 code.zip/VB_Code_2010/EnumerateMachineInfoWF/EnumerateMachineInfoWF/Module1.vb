﻿Imports System.Activities
Imports System.Activities.Statements
Imports System.Diagnostics
Imports System.Linq

Module Module1

    Sub Main()
        Try
            Dim wfArgs As New Dictionary(Of String, Object)()
            wfArgs.Add("UserName", "Andrew")

            WorkflowInvoker.Invoke(New Workflow1(), wfArgs)
        Catch ex As Exception
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.Data("Reason"))

        End Try
        Console.ReadLine()
    End Sub

End Module
