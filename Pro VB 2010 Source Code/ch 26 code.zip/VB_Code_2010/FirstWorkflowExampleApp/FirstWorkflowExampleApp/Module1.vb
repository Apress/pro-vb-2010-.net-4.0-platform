﻿Imports System.Activities
Imports System.Activities.Statements
Imports System.Diagnostics
Imports System.Linq
Imports System.Threading

Module Module1
    Sub Main()

        Console.WriteLine("***** Welcome to this amazing WF application *****")

        ' Get data from user, to pass to workflow. 
        Console.Write("Please enter the data to pass the workflow: ")
        Dim wfData As String = Console.ReadLine()

        ' Package up the data as a dictionary. 
        Dim wfArgs As New Dictionary(Of String, Object)()
        wfArgs.Add("MessageToShow", wfData)

        Dim waitHandle As New AutoResetEvent(False)

        ' Pass to the workflow. 
        Dim app As New WorkflowApplication(New Workflow1(), wfArgs)

        ' Hook up an event with this app. 
        app.Completed = Sub(completedArgs)
                            waitHandle.Set()
                            Console.WriteLine("The workflow is done!")
                        End Sub

        ' Start the workflow! 
        app.Run()

        ' Wait until we are notified the workflow is done.
        waitHandle.WaitOne()
        Console.WriteLine("Thanks for playing")

        Console.ReadLine()
    End Sub
End Module
