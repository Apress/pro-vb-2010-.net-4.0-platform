﻿Imports System.Activities
Imports System.Text
Imports System.IO.File

Public NotInheritable Class CreateSalesMemoActivity
    Inherits CodeActivity

    ' Two properties for our custom activity
    Public Property Make() As InArgument(Of String)
    Public Property Color() As InArgument(Of String)

    ' If your activity returns a value, derive from CodeActivity(Of TResult)
    ' and return the value from the Execute method.
    Protected Overrides Sub Execute(ByVal context As CodeActivityContext)

        ' Dump a message to a local text file.
        Dim salesMessage As New StringBuilder()
        salesMessage.AppendLine("***** Attention sales team! *****")
        salesMessage.AppendLine("Please order the following ASAP!")
        salesMessage.AppendFormat("1 {0} {1}" & vbLf, context.GetValue(Color), context.GetValue(Make))
        salesMessage.AppendLine("*********************************")

        WriteAllText("SalesMemo.txt", salesMessage.ToString())
    End Sub
End Class