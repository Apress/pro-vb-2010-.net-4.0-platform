﻿Public Class MainForm

    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Display current XML inventory document in TextBox control. 
        txtInventory.Text = LinqToXmlObjectModel.GetXmlInventory().ToString()
    End Sub

    Private Sub btnLookUpColors_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLookUpColors.Click
        LinqToXmlObjectModel.LookUpColorsForMake(txtMakeToLookUp.Text)
    End Sub

    Private Sub btnAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddNewItem.Click
        ' Add new item to doc.
        LinqToXmlObjectModel.InsertNewElement(txtMake.Text, txtColor.Text, txtPetName.Text)

        ' Display current XML inventory document in TextBox control. 
        txtInventory.Text = LinqToXmlObjectModel.GetXmlInventory().ToString()
    End Sub
End Class
