﻿Public Class LinqToXmlObjectModel

#Region "Load XML doc"
    Public Shared Function GetXmlInventory() As XDocument
        Try
            Dim inventoryDoc As XDocument = XDocument.Load("Inventory.xml")
            Return inventoryDoc
        Catch ex As System.IO.FileNotFoundException
            MessageBox.Show(ex.Message)
            Return Nothing
        End Try
    End Function
#End Region

#Region "Insert new item"
    Public Shared Sub InsertNewElement(ByVal make As String, ByVal color As String, ByVal petName As String)
        ' Load current document. 
        Dim inventoryDoc As XDocument = XDocument.Load("Inventory.xml")

        ' Generate a random number for the ID.
        Dim r As New Random()

        ' Make new XElement based on incoming parameters. 
        Dim newElement As New XElement("Car", New XAttribute("ID", r.Next(50000)), New XElement("Color", color), New XElement("Make", make), New XElement("PetName", petName))

        ' Add to in-memory object.
        inventoryDoc.Descendants("Inventory").First().Add(newElement)

        ' Save changes to disk.
        inventoryDoc.Save("Inventory.xml")
    End Sub
#End Region

#Region "Query doc"
    Public Shared Sub LookUpColorsForMake(ByVal make As String)
        ' Load current document. 
        Dim inventoryDoc As XDocument = XDocument.Load("Inventory.xml")

        ' Find the colors for a given make.
        Dim makeInfo = From car In inventoryDoc.Descendants("Car")
                       Where CStr(car.Element("Make")) = make
                       Select car.Element("Color").Value

        ' Build a string representing each color. 
        Dim data As String = String.Empty
        For Each item In makeInfo.Distinct()
            data &= String.Format("- {0}" & vbLf, item)
        Next

        ' Show colors. 
        MessageBox.Show(data, String.Format("{0} colors:", make))
    End Sub
#End Region

End Class
