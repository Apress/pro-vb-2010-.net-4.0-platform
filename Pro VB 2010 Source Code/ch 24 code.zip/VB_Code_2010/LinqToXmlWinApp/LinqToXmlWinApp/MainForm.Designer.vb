﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtInventory = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtMake = New System.Windows.Forms.TextBox()
        Me.txtColor = New System.Windows.Forms.TextBox()
        Me.txtPetName = New System.Windows.Forms.TextBox()
        Me.label5 = New System.Windows.Forms.Label()
        Me.txtMakeToLookUp = New System.Windows.Forms.TextBox()
        Me.btnLookUpColors = New System.Windows.Forms.Button()
        Me.btnAddNewItem = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtInventory
        '
        Me.txtInventory.BackColor = System.Drawing.SystemColors.Control
        Me.txtInventory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtInventory.Location = New System.Drawing.Point(28, 47)
        Me.txtInventory.Multiline = True
        Me.txtInventory.Name = "txtInventory"
        Me.txtInventory.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtInventory.Size = New System.Drawing.Size(215, 188)
        Me.txtInventory.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(25, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Current Inventory"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnAddNewItem)
        Me.GroupBox1.Controls.Add(Me.txtPetName)
        Me.GroupBox1.Controls.Add(Me.txtColor)
        Me.GroupBox1.Controls.Add(Me.txtMake)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(264, 47)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(277, 162)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Add Inventory Item"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnLookUpColors)
        Me.GroupBox2.Controls.Add(Me.txtMakeToLookUp)
        Me.GroupBox2.Controls.Add(Me.label5)
        Me.GroupBox2.Location = New System.Drawing.Point(264, 215)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(277, 110)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Look up Colors for Make"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(18, 30)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(34, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Make"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(18, 61)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(31, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Color"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(18, 94)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(54, 13)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Pet Name"
        '
        'txtMake
        '
        Me.txtMake.Location = New System.Drawing.Point(86, 30)
        Me.txtMake.Name = "txtMake"
        Me.txtMake.Size = New System.Drawing.Size(168, 20)
        Me.txtMake.TabIndex = 6
        '
        'txtColor
        '
        Me.txtColor.Location = New System.Drawing.Point(86, 61)
        Me.txtColor.Name = "txtColor"
        Me.txtColor.Size = New System.Drawing.Size(168, 20)
        Me.txtColor.TabIndex = 7
        '
        'txtPetName
        '
        Me.txtPetName.Location = New System.Drawing.Point(86, 87)
        Me.txtPetName.Name = "txtPetName"
        Me.txtPetName.Size = New System.Drawing.Size(168, 20)
        Me.txtPetName.TabIndex = 8
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Location = New System.Drawing.Point(6, 37)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(90, 13)
        Me.label5.TabIndex = 1
        Me.label5.Text = "Make to Look Up"
        '
        'txtMakeToLookUp
        '
        Me.txtMakeToLookUp.Location = New System.Drawing.Point(121, 30)
        Me.txtMakeToLookUp.Name = "txtMakeToLookUp"
        Me.txtMakeToLookUp.Size = New System.Drawing.Size(150, 20)
        Me.txtMakeToLookUp.TabIndex = 2
        Me.txtMakeToLookUp.Text = "BMW"
        '
        'btnLookUpColors
        '
        Me.btnLookUpColors.Location = New System.Drawing.Point(63, 63)
        Me.btnLookUpColors.Name = "btnLookUpColors"
        Me.btnLookUpColors.Size = New System.Drawing.Size(150, 23)
        Me.btnLookUpColors.TabIndex = 3
        Me.btnLookUpColors.Text = "Look Up Colors"
        Me.btnLookUpColors.UseVisualStyleBackColor = True
        '
        'btnAddNewItem
        '
        Me.btnAddNewItem.Location = New System.Drawing.Point(104, 123)
        Me.btnAddNewItem.Name = "btnAddNewItem"
        Me.btnAddNewItem.Size = New System.Drawing.Size(109, 23)
        Me.btnAddNewItem.TabIndex = 9
        Me.btnAddNewItem.Text = "Add"
        Me.btnAddNewItem.UseVisualStyleBackColor = True
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(553, 337)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtInventory)
        Me.Name = "MainForm"
        Me.Text = "Fun with LINQ to XML"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtInventory As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtPetName As System.Windows.Forms.TextBox
    Friend WithEvents txtColor As System.Windows.Forms.TextBox
    Friend WithEvents txtMake As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Private WithEvents btnLookUpColors As System.Windows.Forms.Button
    Private WithEvents txtMakeToLookUp As System.Windows.Forms.TextBox
    Private WithEvents label5 As System.Windows.Forms.Label
    Private WithEvents btnAddNewItem As System.Windows.Forms.Button

End Class
