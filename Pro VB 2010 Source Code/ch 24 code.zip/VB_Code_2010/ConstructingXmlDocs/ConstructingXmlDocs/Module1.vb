﻿Module Module1
    Sub Main()
        Console.WriteLine("***** Fun making XML docs! *****")
        CreateFullXDocument()
        CreateRootAndChildren()
        MakeXElementFromArray()
        Console.WriteLine()

        ParseAndLoadExistingXml()
        Console.ReadLine()
    End Sub

#Region "Create full XDocument"
    Sub CreateFullXDocument()
        Dim inventoryDoc As New XDocument(New XComment("Current Inventory of cars!"), New XProcessingInstruction("xml-stylesheet", "href='MyStyles.css' title='Compact' type='text/css'"), New XElement("Inventory", New XElement("Car", New XAttribute("ID", "1"), New XElement("Color", "Green"), New XElement("Make", "BMW"), New XElement("PetName", "Stan")), New XElement("Car", New XAttribute("ID", "2"), New XElement("Color", "Pink"), New XElement("Make", "Yugo"), New XElement("PetName", "Melvin"))))
        ' Save to disk.
        inventoryDoc.Save("FullXmlDoc.xml")

    End Sub
#End Region

#Region "Make XElement and save to disk."
    Sub CreateRootAndChildren()
        Dim inventoryDoc As New XElement("Inventory", New XComment("Current Inventory of cars!"), New XElement("Car", New XAttribute("ID", "1"), New XElement("Color", "Green"), New XElement("Make", "BMW"), New XElement("PetName", "Stan")), New XElement("Car", New XAttribute("ID", "2"), New XElement("Color", "Pink"), New XElement("Make", "Yugo"), New XElement("PetName", "Melvin")))

        ' Save to disk.
        inventoryDoc.Save("SimpleInventory.xml")
    End Sub
#End Region

#Region "Map array to XElement"
    Sub MakeXElementFromArray()
        ' Create an anonymous array of anonymous types.
        Dim people = {New With {Key .FirstName = "Mandy", Key .Age = 40}, New With {Key .FirstName = "Andrew", Key .Age = 32}, New With {Key .FirstName = "Dave", Key .Age = 41}, New With {Key .FirstName = "Sara", Key .Age = 31}}

        Dim arrayDataAsXElements = From c In people
                                   Select New XElement("Person", New XAttribute("Age", c.Age), New XElement("FirstName", c.FirstName))

        Dim peopleDoc As New XElement("People", arrayDataAsXElements)
        Console.WriteLine(peopleDoc)
    End Sub
#End Region

#Region "Parse / Load"
    Sub ParseAndLoadExistingXml()
        ' Build an XElement from String.
        Dim myElement As String = "<Car ID ='3'>" & ControlChars.CrLf & " <Color>Yellow</Color>" & ControlChars.CrLf & "                  <Make>Yugo</Make>" & ControlChars.CrLf & "                </Car>"
        Dim newElement As XElement = XElement.Parse(myElement)
        Console.WriteLine(newElement)
        Console.WriteLine()

        ' Load the SimpleInventory.xml file.
        Dim myDoc As XDocument = XDocument.Load("SimpleInventory.xml")
        Console.WriteLine(myDoc)
    End Sub
#End Region

End Module
