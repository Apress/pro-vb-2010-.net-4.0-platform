﻿'For older DOM support.
Imports System.Xml

'For newer LINQ to XML support. 
Imports System.Xml.Linq

Module Module1

    Sub Main()
        Console.WriteLine("***** A Tale of Two XML APIs *****")
        BuildXmlDocWithDOM()
        BuildXmlDocWithLINQToXml()

        ' Test functionality from the VB 2010 library in this solution.
        Dim vbXml As New VbXmlLiteralLibrary.XmlLiteralExample()
        vbXml.MakeXmlFileUsingLiterals()

        Console.WriteLine("XML data saved to output directory.")

        ' Delete a node. 
        DeleteNodeFromDoc()
        Console.ReadLine()

    End Sub

#Region "Build XML file using System.Xml.dll types."
    Private Sub BuildXmlDocWithDOM()
        ' Make a new XML document in memory.
        Dim doc As New XmlDocument()

        ' Fill this document with a root element
        ' named <Inventory>.
        Dim inventory As XmlElement = doc.CreateElement("Inventory")

        ' Now, make a sub element named <Car> with 
        ' an ID attribute. 
        Dim car As XmlElement = doc.CreateElement("Car")
        car.SetAttribute("ID", "1000")

        ' Build the data within the <Car> element. 
        Dim name As XmlElement = doc.CreateElement("PetName")
        name.InnerText = "Jimbo"
        Dim color As XmlElement = doc.CreateElement("Color")
        color.InnerText = "Red"
        Dim make As XmlElement = doc.CreateElement("Make")
        make.InnerText = "Ford"

        ' Add <PetName>, <Color> and <Make> to the <Car>
        ' element. 
        car.AppendChild(name)
        car.AppendChild(color)
        car.AppendChild(make)

        ' Add the <Car> element to the <Inventory> element. 
        inventory.AppendChild(car)

        ' Insert the complete XML into the XmlDocument object,
        ' and save to file. 
        doc.AppendChild(inventory)
        doc.Save("Inventory.xml")
    End Sub
#End Region

#Region "Build XML doc with LINQ to XML"
    Private Sub BuildXmlDocWithLINQToXml()
        ' Create a 'functional' XML document.
        Dim doc As New XElement("Inventory", New XElement("Car", New XAttribute("ID", "1000"), New XElement("PetName", "Jimbo"), New XElement("Color", "Red"), New XElement("Make", "Ford")))

        ' Save to file.
        doc.Save("InventoryWithLINQ.xml")
    End Sub
#End Region

#Region "Remove an element."
    Private Sub DeleteNodeFromDoc()
        ' Create a 'functional' XML document.
        Dim doc As New XElement("Inventory", New XElement("Car", New XAttribute("ID", "1000"), New XElement("PetName", "Jimbo"), New XElement("Color", "Red"), New XElement("Make", "Ford")))

        ' Delete the PetName element from the tree. 
        doc.Descendants("PetName").Remove()
        Console.WriteLine(doc)
    End Sub
#End Region
End Module
