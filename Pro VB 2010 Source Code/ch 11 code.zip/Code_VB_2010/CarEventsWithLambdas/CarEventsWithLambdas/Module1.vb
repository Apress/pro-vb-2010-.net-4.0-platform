﻿Module Module1

    Sub Main()
        Console.WriteLine("***** More Fun with Lambdas *****" & vbLf)
        'Make a car as usual.
        Dim c1 As New Car("SlugBug", 100, 10)
        'Now with lambdas!
        AddHandler c1.AboutToBlow, Sub(sender, e)
                                       Console.WriteLine(e.msg)
                                   End Sub

        AddHandler c1.Exploded, Sub(sender, e)
                                    Console.WriteLine(e.msg)
                                End Sub

        'Speed up (this will generate the events).
        Console.WriteLine(vbLf & "***** Speeding up *****")

        For i = 0 To 5
            c1.Accelerate(20)

        Next
        Console.ReadLine()
    End Sub

End Module
