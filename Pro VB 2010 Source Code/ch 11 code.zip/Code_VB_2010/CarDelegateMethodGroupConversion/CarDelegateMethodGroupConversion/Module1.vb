﻿Module Module1

    Sub Main()
        Console.WriteLine("***** Method Group Conversion *****" & vbLf)

        Dim c1 As New Car()
        ' Register the simple method name.
        c1.RegisterWithCarEngine(AddressOf CallMeHere)

        Console.WriteLine("***** Speeding up *****")
        For i As Integer = 0 To 5
            c1.Accelerate(20)
        Next
        ' Unregister the simple method name.
        c1.UnRegisterWithCarEngine(AddressOf CallMeHere)

        ' No more notifications!
        For i As Integer = 0 To 5
            c1.Accelerate(20)
        Next
        Console.ReadLine()
    End Sub
    Sub CallMeHere(ByVal msg As String)
        Console.WriteLine("=> Message from Car: {0}", msg)
    End Sub
End Module
