﻿Module Module1
    Sub Main()
        Console.WriteLine("***** Anonymous Methods *****" & vbLf)
        

        Dim c1 As New Car("SlugBug", 100, 10)
        Dim aboutToBlowCounter As Integer = 0
        ' Register event handlers as anonymous methods.
        ' Assume "SomeDelegate" can point to methods taking no
        ' args and having no return value.
        AddHandler c1.AboutToBlow, Sub()
                                       aboutToBlowCounter = aboutToBlowCounter + 1
                                       Console.WriteLine("Eek! Going too fast!")
                                   End Sub

        AddHandler c1.AboutToBlow, Sub(sender As Object, e As CarEventArgs)
                                       aboutToBlowCounter += 1
                                       Console.WriteLine("Message from Car: {0}", e.msg)
                                   End Sub

        AddHandler c1.Exploded, Sub(sender As Object, e As CarEventArgs)
                                    Console.WriteLine("Fatal Message from Car: {0}", e.msg)
                                End Sub

        ' This will eventually trigger the events.
        For i As Integer = 0 To 5
            c1.Accelerate(20)
        Next
        Console.WriteLine("AboutToBlow event was fired {0} times.", aboutToBlowCounter)
        Console.ReadLine()
    End Sub


End Module