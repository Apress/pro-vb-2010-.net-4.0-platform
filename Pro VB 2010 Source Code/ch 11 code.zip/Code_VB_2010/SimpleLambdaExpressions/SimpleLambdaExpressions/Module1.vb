﻿
Module Module1
    Sub Main()
        Console.WriteLine("***** Fun with Lambdas *****" & vbLf)
        TraditionalDelegateSyntax()
        AnonymousMethodSyntax()
        Console.WriteLine()
        LambdaExpressionSyntax()
        Console.ReadLine()
    End Sub

#Region "Traditional delegates"
    Sub TraditionalDelegateSyntax()
        ' Make a list of Integers.
        Dim list As New List(Of Integer)()
        list.AddRange(New Integer() {20, 1, 4, 8, 9, 44})

        ' Call FindAll() using traditional delegate syntax.
        Dim callback As New Predicate(Of Integer)(AddressOf IsEvenNumber)
        Dim evenNumbers As List(Of Integer) = list.FindAll(callback)

        Console.WriteLine("Here are your even numbers:")
        For Each evenNumber As Integer In evenNumbers
            Console.Write("{0}" & vbTab, evenNumber)
        Next
        Console.WriteLine()
    End Sub

    ' Target for the Predicate() delegate.
    Private Function IsEvenNumber(ByVal i As Integer) As Boolean
        ' Is it an even number?
        Return (i Mod 2) = 0
    End Function
#End Region

#Region "Anonymous method"
    Private Sub AnonymousMethodSyntax()
        ' Make a list of Integers.
        Dim list As New List(Of Integer)()
        list.AddRange(New Integer() {20, 1, 4, 8, 9, 44})

        ' Now, use an anonymous method.
        'This lambda expression...
        Dim evenNumbers As List(Of Integer) = list.FindAll(Function(i As Integer) (i Mod 2) = 0)
        Console.WriteLine("Here are your even numbers:")
        For Each evenNumber As Integer In evenNumbers
            Console.Write("{0}" & vbTab, evenNumber)
        Next
        Console.WriteLine()
    End Sub


#End Region

#Region "Lambda!"
    Private Sub LambdaExpressionSyntax()
        ' Make a list of Integers.
        Dim list As New List(Of Integer)()
        list.AddRange(New Integer() {20, 1, 4, 8, 9, 44})

        ' Now process each argument within a group of
        ' code statements.
        Dim evenNumbers As List(Of Integer) = list.FindAll(
            Function(i)
                Console.WriteLine("value of i is currently: {0}", i)
                Dim isEven As Boolean = ((i Mod 2) = 0)
                Return isEven
            End Function)

        ' The function returns the nested lambda, with 3 as the 
        ' value of parameter level2.

        Console.WriteLine("Here are your even numbers:")
        For Each evenNumber As Integer In evenNumbers
            Console.Write("{0}" & vbTab, evenNumber)
        Next
        Console.WriteLine()
    End Sub
#End Region
End Module
