﻿Module Module1

    Sub Main()
        Console.WriteLine("***** Agh!  No Encapsulation! *****" & vbLf)

        'Make a Car.
        Dim myCar As New Car()

        'We have direct access to the delegate!
        myCar.listOfHandlers = New Car.CarEngineHandler(AddressOf CallWhenExploded)
        myCar.Accelerate(10)

        ' We can now assign to a whole new object...
        'confusing at best.
        myCar.listOfHandlers = New Car.CarEngineHandler(AddressOf CallHereToo)
        myCar.Accelerate(10)

        'The caller can also directly invoke the delegate!
        myCar.listOfHandlers.Invoke("hee, hee, hee...")
        Console.ReadLine()
    End Sub
#Region "Targets for delegates"
    Sub CallWhenExploded(ByVal msg As String)
        Console.WriteLine(msg)
    End Sub
    Sub CallHereToo(ByVal msg As String)
        Console.WriteLine(msg)
    End Sub
#End Region
End Module

#Region "Simple Car & public delegate"
Public Class Car
    Public Delegate Sub CarEngineHandler(ByVal msgForCaller As String)
    ' Now a public member!
    Public listOfHandlers As CarEngineHandler
    'Just fire out the Exploded notification.
    Public Sub Accelerate(ByVal delta As Integer)
        If listOfHandlers IsNot Nothing Then
            listOfHandlers("Sorry, this car is dead...")
        End If
    End Sub
End Class
#End Region
