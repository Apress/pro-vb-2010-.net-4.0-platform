﻿Module Module1
    Sub Main()
        Console.WriteLine("***** Delegates as event enablers *****" & vbLf)

        'First, make a Car object.
        Dim c1 As New Car("SlugBug", 100, 10)

        'Register multiple targets for the notifications. 
        c1.RegisterWithCarEngine(New Car.CarEngineHandler(AddressOf OnCarEngineEvent))

        'This time, hold onto the delegate object,
        'so we can unregister later. 
        Dim handler2 As New Car.CarEngineHandler(AddressOf OnCarEngineEvent2)
        c1.RegisterWithCarEngine(handler2)

        'Speed up (this will trigger the events).
        Console.WriteLine("***** Speeding up *****")
        For i = 0 To 5
            c1.Accelerate(20)

        Next
        'Unregister from the second handler. 
        c1.UnRegisterWithCarEngine(handler2)
        'We won't see the 'upper case' message anymore!
        Console.WriteLine("***** Speeding up *****")
        For i = 0 To 5
            c1.Accelerate(20)
        Next
        Console.ReadLine()
    End Sub
#Region "Targets for the delegate."
    'We now have TWO methods that will be called by the Car
    'when sending notifications. 
    Public Sub OnCarEngineEvent(ByVal msg As String)
        Console.WriteLine(vbLf & "***** Message From Car Object *****")
        Console.WriteLine("=> {0}", msg)
        Console.WriteLine("***********************************" & vbLf)
    End Sub
    Public Sub OnCarEngineEvent2(ByVal msg As String)
        Console.WriteLine("=> {0}", msg.ToUpper())
    End Sub
#End Region
End Module
