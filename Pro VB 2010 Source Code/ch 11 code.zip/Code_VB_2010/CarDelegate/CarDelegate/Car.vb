﻿Public Class Car
#Region "Basic Car state data / constructors"
    ' Internal state data.
    Public Property CurrentSpeed() As Integer
    Public Property MaxSpeed() As Integer
    Public Property PetName() As String
    ' Is the car alive or dead?	
    Private carIsDead As Boolean
    Public Sub New()
        MaxSpeed = 100
    End Sub
    Public Sub New(ByVal name As String, ByVal maxSp As Integer, ByVal currSp As Integer)
        CurrentSpeed = currSp
        MaxSpeed = maxSp
        PetName = name
    End Sub
#End Region
#Region "Delegate infrastructure"
    ' 1) Define the delegate type.
    Public Delegate Sub CarEngineHandler(ByVal msgForCaller As String)
    ' 2) Define a member variable of the delegate.
    Private listOfHandlers As CarEngineHandler
    ' 3) Add registration function for the caller.
    Public Sub RegisterWithCarEngine(ByVal methodToCall As CarEngineHandler)
        listOfHandlers = methodToCall

    End Sub
    Public Sub UnRegisterWithCarEngine(ByVal methodToCall As CarEngineHandler)
        listOfHandlers = CType(System.Delegate.Remove(listOfHandlers, _
        methodToCall), CarEngineHandler)

    End Sub
#End Region
#Region "Accelerate method"
    Public Sub Accelerate(ByVal delta As Integer)
        'If this car is 'dead', send dead message.
        If carIsDead Then
            'Anybody listening?
            If listOfHandlers IsNot Nothing Then
                listOfHandlers("Sorry, this car is dead...")
            End If
        Else
            CurrentSpeed += delta
            ' Is this car 'almost dead'?
            If 10 = (MaxSpeed - CurrentSpeed) AndAlso listOfHandlers IsNot Nothing Then
                listOfHandlers("Careful buddy!  Gonna blow!")
            End If
            If CurrentSpeed >= MaxSpeed Then
                carIsDead = True
            Else
                Console.WriteLine("CurrentSpeed = {0}", CurrentSpeed)
            End If
        End If

    End Sub
#End Region
End Class
