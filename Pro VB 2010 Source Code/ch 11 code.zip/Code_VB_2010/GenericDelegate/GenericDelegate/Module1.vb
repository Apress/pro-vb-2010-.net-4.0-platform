﻿' This generic delegate can call any method
' returning void and taking a single type parameter.
Public Delegate Sub MyGenericDelegate(Of T)(ByVal arg As T)
Public Delegate Sub MyDelegate(ByVal arg As Object)

Module Module1
    Sub Main()
        Console.WriteLine("***** Generic Delegates *****" & vbLf)

        ' Register targets.
        Dim strTarget As New MyGenericDelegate(Of String)(AddressOf StringTarget)
        strTarget("Some string data")

        Dim intTarget__1 As New MyGenericDelegate(Of Integer)(AddressOf IntTarget)
        intTarget__1(9)

        Dim d As New MyDelegate(AddressOf MyTarget)
        d("More string data")

        ' Method group conversion syntax.
        Dim d2 As MyDelegate = AddressOf MyTarget
        d2(9)
        ' Boxing penalty.
        Console.ReadLine()
    End Sub

#Region "Targets for delegates"
    Sub StringTarget(ByVal arg As String)
        Console.WriteLine("arg in uppercase is: {0}", arg.ToUpper())
    End Sub

    Sub IntTarget(ByVal arg As Integer)
        arg += 1
        Console.WriteLine("incremented  arg is: {0}", arg)
    End Sub

    ' Due to a lack of type safety, we must
    ' determine the underlying type before casting.
    Public Sub MyTarget(ByVal arg As Object)
        If TypeOf arg Is Integer Then
            Dim i As Integer = CInt(arg)
            ' Unboxing penalty.
            i += 1
            Console.WriteLine("incremented  arg is: {0}", i)
        End If

        If TypeOf arg Is String Then
            Dim s As String = CStr(arg)
            Console.WriteLine("arg in uppercase is: {0}", s.ToUpper())
        End If
    End Sub

#End Region
End Module