﻿Module Program
    Sub Main()
        Console.WriteLine("***** Fun with Events *****" & vbLf)
        Dim c1 As New Car("SlugBug", 100, 10)
        'Register event handlers.
        AddHandler c1.AboutToBlow, AddressOf CarAboutToBlow
        AddHandler c1.AboutToBlow, AddressOf CarIsAlmostDoomed
        AddHandler c1.Exploded, AddressOf CarExploded

        Console.WriteLine("***** Speeding up *****")

        For i = 0 To 5
            c1.Accelerate(20)

        Next
        RemoveHandler c1.AboutToBlow, AddressOf CarExploded
        Console.WriteLine(vbLf & "***** Speeding up *****")

        For i = 0 To 5
            c1.Accelerate(20)

        Next
        Console.ReadLine()
    End Sub
#Region "Targets for events"
    Public Sub CarAboutToBlow(ByVal msg As String)
        Console.WriteLine(msg)
    End Sub
    Public Sub CarIsAlmostDoomed(ByVal msg As String)
        Console.WriteLine("=> Critical Message from Car: {0}", msg)
    End Sub
    Public Sub CarExploded(ByVal msg As String)
        Console.WriteLine(msg)
    End Sub

#End Region
  
End Module
