﻿Public Class Car
#Region "Basic Car state data / constructors"
    ' Internal state data.
    Public Property CurrentSpeed() As Integer
    Public Property MaxSpeed() As Integer
    Public Property PetName() As String
    'Is the car alive or dead?
    Private carIsDead As Boolean
    Public Sub New()
        MaxSpeed = 100
    End Sub
    Public Sub New(ByVal name As String, ByVal maxSp As Integer, ByVal currSp As Integer)
        CurrentSpeed = currSp
        MaxSpeed = maxSp
        PetName = name
    End Sub
#End Region

    'This delegate works in conjunction with the
    'Car's events.
    Public Delegate Sub CarEngineHandler(ByVal msg As String)
    'This car can send these events.
    Public Event Exploded As CarEngineHandler
    Public Event AboutToBlow As CarEngineHandler

    Public Sub Accelerate(ByVal delta As Integer)
        'If the car is dead, fire Exploded event.
        If carIsDead Then

            RaiseEvent Exploded("Sorry, this car is dead...")
        Else

            CurrentSpeed += delta
            'Almost dead?
            If 10 = MaxSpeed - CurrentSpeed Then
                RaiseEvent AboutToBlow("Careful buddy!  Gonna blow!")
            End If
            'Still OK!
            If CurrentSpeed >= MaxSpeed Then
                carIsDead = True
            Else
                Console.WriteLine("CurrentSpeed = {0}", CurrentSpeed)
            End If
        End If
    End Sub
End Class
