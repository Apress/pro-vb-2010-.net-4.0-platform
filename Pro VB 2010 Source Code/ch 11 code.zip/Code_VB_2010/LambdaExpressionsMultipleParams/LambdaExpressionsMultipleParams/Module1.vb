﻿Module Module1
    Sub Main()
        'Register w/ delegate as a lambda expression.
        Dim m As New SimpleMath()
        m.SetMathHandler(Sub(msg As String, result As Integer)
                             Console.WriteLine("Message: {0}, Result: {1}", msg, result)
                         End Sub)

        'This will execute the lambda expression.
        m.Add(10, 10)
        Console.ReadLine()
    End Sub
End Module
#Region "SimpleMath, round two!"
Public Class SimpleMath
    Public Delegate Sub MathMessage(ByVal msg As String, ByVal result As Integer)
    Private mmDelegate As MathMessage

    Public Sub SetMathHandler(ByVal target As MathMessage)
        mmDelegate = target
    End Sub

    Public Sub Add(ByVal x As Integer, ByVal y As Integer)
        If mmDelegate IsNot Nothing Then
            mmDelegate.Invoke("Adding has completed!", x + y)
        End If
    End Sub
End Class
#End Region
