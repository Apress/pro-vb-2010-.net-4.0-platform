﻿Public Class CarEventArgs
    Inherits EventArgs
    Public ReadOnly msg As String
    Public Sub New(ByVal message As String)
        msg = message
    End Sub
End Class
