﻿Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Events *****" & vbLf)
        Dim c1 As New Car("SlugBug", 100, 10)

        ' Register event handlers.
        AddHandler c1.AboutToBlow, AddressOf CarAboutToBlow
        AddHandler c1.Exploded, AddressOf CarExploded

        Console.WriteLine("***** Speeding up *****")
        For i As Integer = 0 To 5
            c1.Accelerate(20)
        Next
        AddHandler c1.Exploded, AddressOf CarExploded

        Console.WriteLine(vbLf & "***** Speeding up *****")
        For i As Integer = 0 To 5
            c1.Accelerate(20)
        Next

        Console.ReadLine()
    End Sub
#Region "Targets for events"
    Public Sub CarAboutToBlow(ByVal sender As Object, ByVal e As CarEventArgs)
        ' Just to be safe, perform a
        ' runtime check before casting.
        If TypeOf sender Is Car Then
            Dim c As Car = DirectCast(sender, Car)
            Console.WriteLine("Critical Message from {0}: {1}", c.PetName, e.msg)
        End If
    End Sub

    Public Sub CarExploded(ByVal sender As Object, ByVal e As CarEventArgs)
        Console.WriteLine(e.msg)
    End Sub
#End Region
End Module
