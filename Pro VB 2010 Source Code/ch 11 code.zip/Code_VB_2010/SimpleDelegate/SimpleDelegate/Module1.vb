﻿Module Module1
    'This delegate can point to any method,
    'taking two integers and returning an integer.
    Public Delegate Function BinaryOp(ByVal x As Integer, ByVal y As Integer) As Integer
#Region "SimpleMath class"
    'This class contains methods BinaryOp will
    'point to.
    Public Class SimpleMath
        Public Shared Function Add(ByVal x As Integer, ByVal y As Integer) As Integer
            Return x + y
        End Function
        Public Shared Function Subtract(ByVal x As Integer, ByVal y As Integer) As Integer
            Return x - y
        End Function
        Public Shared Function SquareNumber(ByVal a As Integer) As Integer
            Return a * a
        End Function

    End Class

#End Region
    Sub Main()
        Console.WriteLine("***** Simple Delegate Example *****" & vbLf)
        'Error! Method does not match delegate pattern!
        'Dim b2 As New BinaryOp(SimpleMath.SquareNumber)
        '.NET delegates can also point to instance methods as well.
        Dim b As New BinaryOp(AddressOf SimpleMath.Add)
        DisplayDelegateInfo(b)
        'Invoke Add() method indirectly using delegate object.
        Console.WriteLine("10 + 10 is {0}", b(10, 10))
        Console.ReadLine()
    End Sub
#Region "Helper method to display what a delegate is pointing to."
    Sub DisplayDelegateInfo(ByVal delObj As [Delegate])
        'Print the names of each member in the
        'delegate's invocation list.
        For Each d As [Delegate] In delObj.GetInvocationList()
            Console.WriteLine("Method Name: {0}", d.Method)
            Console.WriteLine("Type Name: {0}", d.Target)
        Next
    End Sub
#End Region


End Module
