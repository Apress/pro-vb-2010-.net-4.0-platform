﻿Module Module1
    ' Define a single delegate that may return a Car
    ' or SportsCar.
    Public Delegate Function ObtainVehicalDelegate() As Car

    Public Function GetBasicCar() As Car
        Return New Car()
    End Function

    Public Function GetSportsCar() As SportsCar
        Return New SportsCar()
    End Function

    Sub Main()
        Console.WriteLine("***** Delegate Covariance *****" & vbLf)
        Dim targetA As New ObtainVehicalDelegate(AddressOf GetBasicCar)
        Dim c As Car = targetA()
        Console.WriteLine("Obtained a {0}", c)

        ' Covariance allows this target assignment.
        Dim targetB As New ObtainVehicalDelegate(AddressOf GetSportsCar)
        Dim sc As SportsCar = DirectCast(targetB(), SportsCar)
        Console.WriteLine("Obtained a {0}", sc)
        Console.ReadLine()


    End Sub

End Module




