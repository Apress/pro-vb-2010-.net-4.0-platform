Imports System
Imports System.Windows.Forms
Imports CorLibDumper
Imports System.Drawing

Namespace WinFormsClientApp
  ' Application object.
  Public  Class Program
	
	Public Shared Sub Main(ByVal args() As String)
	  Application.Run(New MainWindow())
	End Sub
  End Class

  ' Our simple Window.
  Public Class MainWindow
	  Inherits Form
	Private btnDumpToFile As New Button()
	Private txtTypeName As New TextBox()

	Public Sub New()
	  ' Config the UI.
	  ConfigControls()
	End Sub

	Public Sub ConfigControls()
	  ' Configure the Form.
	  Text = "My Mono Win Forms App!"
	  ClientSize = New System.Drawing.Size(366, 90)
	  StartPosition = FormStartPosition.CenterScreen
	  AcceptButton = btnDumpToFile

	  ' Configure the Button.
	  btnDumpToFile.Text = "Dump"
	  btnDumpToFile.Location = New System.Drawing.Point(13, 40)

	  ' Handle click event anonymously.
	  AddHandler btnDumpToFile.Click, Sub()
		If TypeDumper.DumpTypeToFile(txtTypeName.Text) Then
		  MessageBox.Show(String.Format("Data saved into {0}.txt", txtTypeName.Text))
		Else
		  MessageBox.Show("Error!  Can't find that type...")
		End If
	  End Sub
	  Controls.Add(btnDumpToFile)

	  ' Configure the TextBox.
	  txtTypeName.Location = New System.Drawing.Point(13, 13)
	  txtTypeName.Size = New System.Drawing.Size(341, 20)
	  Controls.Add(txtTypeName)
	End Sub
  End Class
End Namespace