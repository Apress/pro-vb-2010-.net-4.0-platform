
Imports CorLibDumper

Namespace ConsoleClientApp
     Module Module1
	Sub Main()
	  Console.WriteLine("***** The Type Dumper App *****" & vbLf)

	  ' Ask user for name of type.
	  Dim typeName As String = ""
	  Console.Write("Please enter type name: ")
	  typeName = Console.ReadLine()

	  ' Now send it to the helper library.
	  If TypeDumper.DumpTypeToFile(typeName) Then
		 Console.WriteLine("Data saved into {0}.txt", typeName)
	  Else
		Console.WriteLine("Error!  Can't find that type...")
	  End If
	End Sub
  End Module
End Namespace