' CoreLibDumper.vb
Imports System.Reflection
Imports System.IO

' Define assembly version.
<Assembly:AssemblyVersion("1.0.0.0")>

Namespace CorLibDumper
  Public Class TypeDumper
	Public Shared Function DumpTypeToFile(ByVal typeToDisplay As String) As Boolean
	  ' Attempt to load type into memory.
	  Dim theType As Type = Nothing
	  Try
		 ' Throw exception if we can't find it.
		 theType = Type.GetType(typeToDisplay, True)
	  Catch
		  Return False
	  End Try

	  ' Create local *.txt file.
	  Using sw As StreamWriter = File.CreateText(String.Format("{0}.txt", theType.FullName))
		' Now dump type to file.
		sw.WriteLine("Type Name: {0}", theType.FullName)
		sw.WriteLine("Members:")
		For Each mi As MemberInfo In theType.GetMembers()
		  sw.WriteLine(vbTab & "-> {0}", mi.ToString())
		Next mi

	  End Using
	  Return True
	End Function
  End Class
End Namespace