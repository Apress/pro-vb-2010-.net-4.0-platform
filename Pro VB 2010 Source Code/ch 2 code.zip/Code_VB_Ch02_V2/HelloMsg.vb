﻿Imports System
Imports System.Windows.Forms

Public Class HelloMsg
    Public Sub Speak()

        MessageBox.Show("Hello...")
    End Sub
End Class
