﻿Imports System.Windows.Forms
Module TestApp
    Sub main()
        Console.WriteLine("Testing! 1, 2, 3")
        ' Don't need this anymore either.
        'MessageBox.Show("Hello...")
        ' Use the HelloMessage class!
        Dim h As New HelloMsg()
        h.Speak()
    End Sub
End Module
