﻿Public Class Point
    Implements IComparable
    Public Property X() As Integer

    Public Property Y() As Integer

    Public Sub New(ByVal xPos As Integer, ByVal yPos As Integer)
        X = xPos
        Y = yPos
    End Sub
#Region "Binary ops"

    Public Overrides Function ToString() As String
        Return String.Format("[{0}, {1}]", Me.X, Me.Y)
    End Function
    'overloaded operator +
    Public Shared Operator +(ByVal p1 As Point, ByVal p2 As Point) As Point
        Return New Point(p1.X + p2.X, p1.Y + p2.Y)
    End Operator
    'overloaded operator -
    Public Shared Operator -(ByVal p1 As Point, ByVal p2 As Point) As Point
        Return New Point(p1.X - p2.X, p1.Y - p2.Y)
    End Operator
    Public Shared Operator +(ByVal p1 As Point, ByVal change As Integer) As Point
        Return New Point(p1.X + change, p1.Y + change)
    End Operator
    Public Shared Operator +(ByVal change As Integer, ByVal p1 As Point) As Point
        Return New Point(p1.X + change, p1.Y + change)
    End Operator
#End Region

#Region "Equality logic"
    Public Overrides Function Equals(ByVal o As Object) As Boolean
        Return o.ToString() = Me.ToString()
    End Function
    Public Overrides Function GetHashCode() As Integer
        Return Me.ToString().GetHashCode()
    End Function
    'Now let's overload the = and <> operators.
    Public Shared Operator =(ByVal p1 As Point, ByVal p2 As Point) As Boolean
        Return p1.Equals(p2)
    End Operator
    Public Shared Operator <>(ByVal p1 As Point, ByVal p2 As Point) As Boolean
        Return Not p1.Equals(p2)
    End Operator
#End Region

#Region "Compare ops"
    'Point is also comparable using the comparison operators.
    Public Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
        If TypeOf obj Is Point Then
            Dim p As Point = DirectCast(obj, Point)
            If Me.X > p.X AndAlso Me.Y > p.Y Then
                Return 1
            End If
            If Me.X < p.X AndAlso Me.Y < p.Y Then
                Return -1
            Else
                Return 0
            End If
        Else
            Throw New ArgumentException()
        End If
    End Function
    Public Shared Operator <(ByVal p1 As Point, ByVal p2 As Point) As Boolean
        Return (p1.CompareTo(p2) < 0)
    End Operator
    Public Shared Operator >(ByVal p1 As Point, ByVal p2 As Point) As Boolean
        Return (p1.CompareTo(p2) > 0)
    End Operator
    Public Shared Operator <=(ByVal p1 As Point, ByVal p2 As Point) As Boolean
        Return (p1.CompareTo(p2) <= 0)
    End Operator
    Public Shared Operator >=(ByVal p1 As Point, ByVal p2 As Point) As Boolean
        Return (p1.CompareTo(p2) >= 0)
    End Operator


#End Region
End Class

