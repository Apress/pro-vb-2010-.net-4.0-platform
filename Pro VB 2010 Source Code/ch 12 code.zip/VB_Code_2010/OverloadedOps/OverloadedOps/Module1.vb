﻿Module Module1

    Sub Main()
       
        Console.WriteLine("***** Fun with Overloaded Operators *****" & vbLf)
        ' Make two points.
        Dim ptOne As New Point(100, 100)
        Dim ptTwo As New Point(40, 40)
        Console.WriteLine("ptOne = {0}", ptOne)
        Console.WriteLine("ptTwo = {0}", ptTwo)

        'Add the points to make a bigger point?
        Console.WriteLine("ptOne + ptTwo: {0} ", ptOne + ptTwo)

        'Subtract the points to make a smaller point?
        Console.WriteLine("ptOne - ptTwo: {0} ", ptOne - ptTwo)

        ' Freebie +=
        Dim ptThree As New Point(90, 5)
        Console.WriteLine("ptThree = {0}", ptThree)
        ptThree += ptTwo
        Console.WriteLine("ptThree += ptTwo: {0}", ptThree)

        ' Freebie -=
        Dim ptFour As New Point(0, 500)
        Console.WriteLine("ptFour = {0}", ptFour)
        ptFour -= ptThree
        Console.WriteLine("ptFour -= ptThree: {0}", ptFour)

        Dim ptSix As New Point(20, 20)

        Console.WriteLine("ptOne = ptTwo : {0}", ptOne = ptTwo)
        Console.WriteLine("ptOne <> ptTwo : {0}", ptOne <> ptTwo)

        Console.WriteLine("ptOne < ptTwo : {0}", ptOne < ptTwo)
        Console.WriteLine("ptOne > ptTwo : {0}", ptOne > ptTwo)
        Console.ReadLine()
    End Sub

End Module
