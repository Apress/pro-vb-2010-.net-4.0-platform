﻿Public Class PeopleCollection
    Implements IEnumerable

    Private arPeople As New ArrayList()

    'Custom indexer for this class.
    Default Public Property Item(ByVal index As Integer) As Person
        Get
            Return DirectCast(arPeople(index), Person)
        End Get
        Set(ByVal value As Person)
            arPeople.Insert(index, value)
        End Set
    End Property

    Public Sub New()
    End Sub

    'Cast for caller.
    Public Function GetPerson(ByVal pos As Integer) As Person
        Return DirectCast(arPeople(pos), Person)
    End Function

    'Only insert Person types.
    Public Sub AddPerson(ByVal p As Person)
        arPeople.Add(p)
    End Sub

    Public Sub ClearPeople()
        arPeople.Clear()
    End Sub

    Public ReadOnly Property Count() As Integer
        Get
            Return arPeople.Count
        End Get
    End Property

    'Foreach enumeration support. 
    Function GetEnumerator() As IEnumerator Implements IEnumerable.GetEnumerator
        Return arPeople.GetEnumerator()
    End Function
End Class
