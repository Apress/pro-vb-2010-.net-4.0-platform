﻿'Indexers allow you to access items in an array-like fashion.
Module Module1
    Sub Main()

        Console.WriteLine("***** Fun with Indexers *****" & vbLf)
        Dim myPeople As New PeopleCollection()
        'Add objects with indexer syntax.
        myPeople(0) = New Person("Homer", "Simpson", 40)
        myPeople(1) = New Person("Marge", "Simpson", 38)
        myPeople(2) = New Person("Lisa", "Simpson", 9)
        myPeople(3) = New Person("Bart", "Simpson", 7)
        myPeople(4) = New Person("Maggie", "Simpson", 2)

        'Now obtain and display each item using indexer.
        For i = 0 To myPeople.Count - 1
            Console.WriteLine("Person number: {0}", i)
            Console.WriteLine("Name: {0} {1}", myPeople(i).FirstName, myPeople(i).LastName)
            Console.WriteLine("Age: {0}", myPeople(i).Age)
            Console.WriteLine()
        Next
        Console.ReadLine()
    End Sub

#Region "Generic containers already support indexers!"
    Sub UseGenericListOfPeople()

        Dim myPeople As New List(Of Person)()
        myPeople.Add(New Person("Lisa", "Simpson", 9))
        myPeople.Add(New Person("Bart", "Simpson", 7))
        'Change first person with indexer.
        myPeople(0) = New Person("Maggie", "Simpson", 2)
        'Now obtain and display each item using indexer.

        For i = 0 To myPeople.Count - 1
            Console.WriteLine("Person number: {0}", i)
            Console.WriteLine("Name: {0} {1}", myPeople(i).FirstName, myPeople(i).LastName)
            Console.WriteLine("Age: {0}", myPeople(i).Age)
            Console.WriteLine()

        Next
    End Sub
#End Region
End Module
