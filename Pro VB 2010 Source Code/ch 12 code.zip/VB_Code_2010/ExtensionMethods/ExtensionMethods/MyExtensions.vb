﻿Imports System.Reflection
Imports System.Runtime.CompilerServices

#Region "MyExtensions type"
Module MyExtensions
    'This method allows any object to display the assembly 
    'it is defined in.
    <Extension()> _
    Public Sub DisplayDefiningAssembly(ByVal obj As Object)
        Console.WriteLine("{0} lives here: => {1}" & vbLf, obj.GetType().Name, Assembly.GetAssembly(obj.GetType()).GetName().Name)
    End Sub

    'This method allows any any Integer to reverse its digits.
    'for example, 56 would return 65.
    <Extension()> _
    Public Function ReverseDigits(ByVal i As Integer) As Integer

        'Translate Integer into a character string, and then
        'get all the characters. 
        Dim digits As Char() = i.ToString().ToCharArray()

        'Now reverse items in the array.
        Array.Reverse(digits)

        'Put back into String.
        Dim newDigits As New String(digits)

        'Finally, return the modified String back as an Integer.
        Return Integer.Parse(newDigits)
    End Function
End Module
#End Region

#Region "TesterUtilModule type"
Module TesterUtilModule

    'Every Int32 now has a Foo() method...
    <Extension()> _
    Public Sub Foo(ByVal i As Integer)
        Console.WriteLine("{0} called the Foo() method.", i)
    End Sub

    '...which has been overloaded to take a String!
    <Extension()> _
    Public Sub Foo(ByVal i As Integer, ByVal msg As String)
        Console.WriteLine("{0} called Foo() and told me: {1}", i, msg)
    End Sub
End Module
#End Region



