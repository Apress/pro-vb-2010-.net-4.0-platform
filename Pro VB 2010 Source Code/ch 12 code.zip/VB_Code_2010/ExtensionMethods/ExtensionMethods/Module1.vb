﻿
Module Module1
    Sub Main()

        Console.WriteLine("***** Fun with Extension Methods *****" & vbLf)

        'The Integer has assumed a new identity!
        Dim myInt As Integer = 12345678
        myInt.DisplayDefiningAssembly()
        myInt.DisplayDefiningAssembly()

        'So this has the DataSet!
        Dim d As New System.Data.DataSet()
        d.DisplayDefiningAssembly()

        'And the SoundPlayer!
        Dim sp As New System.Media.SoundPlayer()
        sp.DisplayDefiningAssembly()

        'Remember!  Extension methods can be called as normal Shared
        'methods. 
        MyExtensions.DisplayDefiningAssembly(False)

        'Use new Integer functionality.
        Console.WriteLine("Value of myInt: {0}", myInt)
        Console.WriteLine("Reversed digits of myInt: {0}", myInt.ReverseDigits())
        myInt.Foo()
        myInt.Foo("Integers that Foo?  Who would have thought it!")
        UseCar()
        Console.ReadLine()

    End Sub
    Sub UseCar()
        Dim c As New Car()
        Console.WriteLine("Speed: {0}", c.SpeedUp())
        Console.WriteLine("Speed: {0}", c.SlowDown())
    End Sub
End Module