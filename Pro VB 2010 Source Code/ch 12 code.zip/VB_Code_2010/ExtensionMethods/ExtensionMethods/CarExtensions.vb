﻿Imports System.Runtime.CompilerServices

Public Class Car

    Public Speed As Integer
    Public Function SpeedUp() As Integer
        Speed += 1
        Return Speed
    End Function
End Class

Public Module CarExtensions
    <Extension()> _
    Public Function SlowDown(ByVal c As Car) As Integer
        c.Speed -= 1
        Return c.Speed
    End Function
End Module
