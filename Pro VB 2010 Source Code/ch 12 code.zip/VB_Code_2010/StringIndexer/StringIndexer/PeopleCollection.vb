﻿Public Class PeopleCollection
    Implements IEnumerable

    Dim listPeople As New Dictionary(Of String, Person)()

    'This indexer returns a person based on a string index.
    Default Public Property Item(ByVal name As String) As Person
        Get
            Return DirectCast(listPeople(name), Person)
        End Get
        Set(ByVal value As Person)
            listPeople(name) = value
        End Set
    End Property

    Public Sub ClearPeople()
        listPeople.Clear()
    End Sub

    Public ReadOnly Property Count() As Integer
        Get
            Return listPeople.Count
        End Get
    End Property

    Function GetEnumerator() As IEnumerator Implements IEnumerable.GetEnumerator
        Return listPeople.GetEnumerator()
    End Function
End Class
