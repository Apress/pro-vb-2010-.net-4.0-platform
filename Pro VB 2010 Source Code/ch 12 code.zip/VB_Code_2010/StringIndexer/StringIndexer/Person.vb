﻿Public Class Person
    Public Property Age() As Integer
        
    Public Property FirstName() As String
      
    Public Property LastName() As String
        
    Public Sub New()
    End Sub

    Public Sub New(ByVal firstName As String, ByVal lastName As String, ByVal age As Integer)
        Me.Age = age
        Me.FirstName = firstName
        Me.LastName = lastName
    End Sub

    Public Overrides Function ToString() As String
        Return String.Format("Name: {0} {1}, Age: {2}", FirstName, LastName, Age)
    End Function
End Class
