﻿Module Module1
    Sub Main()

        Console.WriteLine("***** Fun with Indexers *****" & vbLf)
        Dim myPeople As New PeopleCollection()
        myPeople("Homer") = New Person("Homer", "Simpson", 40)
        myPeople("Marge") = New Person("Marge", "Simpson", 38)
        'Get "Homer" and print data.
        Dim homer As Person = myPeople("Homer")
        Console.WriteLine(homer.ToString())
        Console.ReadLine()
    End Sub
End Module
