﻿Imports System.Runtime.CompilerServices

#Region "Types to represent basic math stuff"

'Define a normal interface in VB 2010.
Public Interface IBasicMath
    Function Add(ByVal x As Integer, ByVal y As Integer) As Integer
End Interface

'Implementation of IBasicMath.
Public Class MyCalc
    Implements IBasicMath

    Public Function Add(ByVal x As Integer, ByVal y As Integer) As Integer Implements IBasicMath.Add
        Return x + y
    End Function
End Class

#End Region

Module Module1

    <Extension()>
    Public Function Subtract(ByVal itf As IBasicMath, ByVal x As Integer, ByVal y As Integer) As Integer
        Return x - y
    End Function

    Sub Main()
        Console.WriteLine("***** Extending an interface *****" & vbLf)
        'Call IBasicMath members from MyCalc object.
        Dim c As New MyCalc()

        Console.WriteLine("1 + 2 = {0}", c.Add(1, 2))
        Console.WriteLine("1 - 2 = {0}", c.Subtract(1, 2))

        'Can also cast into IBasicMath to invoke extension.
        Console.WriteLine("30 - 9 = {0}", (DirectCast(c, IBasicMath)).Subtract(30, 9))
        'This would NOT work!
        'Dim itfBM As New IBasicMath()
        'itfBM.Subtract(10, 10)
        Console.ReadLine()
    End Sub

End Module
