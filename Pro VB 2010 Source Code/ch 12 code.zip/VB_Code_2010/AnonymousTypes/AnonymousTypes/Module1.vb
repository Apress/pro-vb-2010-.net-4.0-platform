﻿Option Explicit On
Module Module1
    Sub Main()
        Console.WriteLine("***** Fun with Anonymous types *****" & vbLf)

        ' Make an anonymous type representing a car.
        Dim myCar = New With { _
         .Color = "Bright Pink", _
         .Make = "Saab", _
         .CurrentSpeed = 55 _
        }

        ' Reflect over what the compiler generated.
        ReflectOverAnonymousType(myCar)

        EqualityTest()

        ' Make an anonymous type that is composed of another.
        Dim purchaseItem = New With { _
         .TimeBought = DateTime.Now, _
         .ItemBought = New With { _
                        .Color = "Red", _
                        .Make = "Saab", _
                        .CurrentSpeed = 55 _
                                }, _
         .Price = 34.0 _
        }

        ReflectOverAnonymousType(purchaseItem)

        Console.ReadLine()
    End Sub


#Region "Reflect over anonymous type"
    Sub ReflectOverAnonymousType(ByVal obj As Object)
        Console.WriteLine("obj is an instance of: {0}", obj.GetType().Name)
        Console.WriteLine("Base class of {0} is {1}", obj.GetType().Name, obj.GetType().BaseType)
        Console.WriteLine("obj.ToString() = {0}", obj.ToString())
        Console.WriteLine("obj.GetHashCode() = {0}", obj.GetHashCode())
        Console.WriteLine()
    End Sub
#End Region

#Region "Equality test"
    Sub EqualityTest()
        ' Make 2 anonymous classes with identical name/value pairs.
        Dim firstCar = New With { _
         .Color = "Bright Pink", _
         .Make = "Saab", _
         .CurrentSpeed = 55 _
        }
        Dim secondCar = New With { _
         .Color = "Bright Pink", _
         .Make = "Saab", _
         .CurrentSpeed = 55 _
        }

        ' Are they considered equal when using Equals()?
        If firstCar.Equals(secondCar) Then
            Console.WriteLine("Same anonymous object!")
        Else
            Console.WriteLine("Not the same anonymous object!")
        End If

        ' Are they considered equal when using =?
        If (firstCar.GetType() = secondCar.GetType()) Then
            Console.WriteLine("Same anonymous object!")
        Else
            Console.WriteLine("Not the same anonymous object!")
        End If

        ' Are these objects the same underlying type?
        If firstCar.GetType().Name = secondCar.GetType().Name Then
            Console.WriteLine("We are both the same type!")
        Else
            Console.WriteLine("We are different types!")
        End If

        ' Show all the details.
        Console.WriteLine()
        ReflectOverAnonymousType(firstCar)
        ReflectOverAnonymousType(secondCar)
    End Sub
#End Region


End Module



