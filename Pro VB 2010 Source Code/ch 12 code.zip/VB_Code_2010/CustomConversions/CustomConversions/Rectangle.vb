﻿Public Class Rectangle
    Public Property Width() As Integer
      
    Public Property Height() As Integer
       
    Public Sub New(ByVal w As Integer, ByVal h As Integer)
        Width = w
        Height = h
    End Sub
    Public Sub New()
    End Sub
    Public Sub Draw()
        For i = 0 To Height - 1
            For j = 0 To Width - 1
                Console.Write("*")
            Next
            Console.WriteLine()
        Next
    End Sub

    Public Overrides Function ToString() As String
        Return String.Format("[Width = {0}; Height = {1}]", Width, Height)
    End Function
    Public Shared Widening Operator CType(ByVal s As Square) As Rectangle
        Dim r As New Rectangle()
        r.Height = s.Length
        'Assume the length of the new Rectangle with
        '(Length x 2)
        r.Width = s.Length * 2
        Return r
    End Operator
End Class
