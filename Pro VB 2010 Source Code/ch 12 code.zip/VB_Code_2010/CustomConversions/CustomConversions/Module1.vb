﻿Module Module1
    Sub Main()
        Console.WriteLine("***** Fun with Conversions *****" & vbLf)
        'Make a Rectangle.
        Dim r As New Rectangle(15, 4)
        Console.WriteLine(r.ToString())
        r.Draw()
        Console.WriteLine()
        'Convert r into a Square,
        'based on the height of the Rectangle.
        Dim s As Square = CType(r, Square)
        Console.WriteLine(s.ToString())
        s.Draw()
        Console.WriteLine()
        'Convert Rectangle to Square to invoke method.
        Dim rect As New Rectangle(10, 5)
        DrawSquare(CType(rect, Square))
        Console.WriteLine()
        'Converting an Integer to a Square.
        Dim sq2 As Square = CType(90, Square)
        Console.WriteLine("sq2 = {0}", sq2)
        ' Converting a Square to an Integer
        Dim side As Integer = CInt(sq2)
        Console.WriteLine("Side length of sq2 = {0}", side)
        'an Implicit cast OK!
        Dim s3 As New Square()
        s3.Length = 7
        Dim rect2 As Rectangle = s3
        Console.WriteLine("rect2 = {0}", rect2)
        DrawSquare(s3)
        'Explicit cast syntax still OK!
        Dim s4 As New Square()
        s4.Length = 3
        Dim rect3 As Rectangle = CType(s4, Rectangle)
        Console.WriteLine("rect3 = {0}", rect3)
        Console.ReadLine()

    End Sub
    'This method requires a Square type.
    Sub DrawSquare(ByVal sq As Square)
        Console.WriteLine(sq.ToString())
        sq.Draw()
    End Sub
End Module
