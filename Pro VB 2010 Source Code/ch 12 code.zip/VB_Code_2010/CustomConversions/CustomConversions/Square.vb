﻿Public Class Square
    Public Property Length() As Integer
       
    Public Sub New(ByVal l As Integer)
        Length = l
    End Sub
    Public Sub New()
    End Sub
    Public Sub Draw()
        For i = 0 To Length - 1

            For j = 0 To Length - 1
                Console.Write("*")

            Next
            Console.WriteLine()
        Next
    End Sub
    'Rectangles can be explicitly converted
    'into Squares.vb
    Public Overrides Function ToString() As String
        Return String.Format("[Length = {0}]", Length)
    End Function
    Public Shared Narrowing Operator CType(ByVal r As Rectangle) As Square
        Dim s As New Square()
        s.Length = r.Height
        Return s
    End Operator
    Public Shared Narrowing Operator CType(ByVal sideLength As Integer) As Square
        Dim newSq As New Square()
        newSq.Length = sideLength
        Return newSq
    End Operator
    Public Shared Narrowing Operator CType(ByVal s As Square) As Integer
        Return s.Length
    End Operator
End Class
