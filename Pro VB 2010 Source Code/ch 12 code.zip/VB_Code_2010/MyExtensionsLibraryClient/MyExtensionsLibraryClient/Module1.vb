﻿Imports MyExtensionsLibrary

Module Module1
    Sub Main()
        Console.WriteLine("***** Using Library with Extensions *****" & vbLf)
        'This time, these extension methods 
        'have been defined within an external
        '.NET class library.
        Dim myInt As Integer = 987
        myInt.DisplayDefiningAssembly()
        Console.WriteLine("{0} is reversed to {1}", myInt, myInt.ReverseDigits())
        Console.ReadLine()
    End Sub
End Module
