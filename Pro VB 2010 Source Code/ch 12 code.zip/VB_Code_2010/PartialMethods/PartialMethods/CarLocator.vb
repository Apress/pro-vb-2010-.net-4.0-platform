﻿'CarLocator.vb
Partial Public Class CarLocator
    'This member will always be part of the
    'CarLocator class.
    Public Function CarAvailableInZipCode(ByVal zipCode As String) As Boolean
        'This call *may* be part of this method
        'implementation.
        VerifyDuplicates(zipCode)

        ' Assume some interesting database logic
        'here...
        OnZipCodeLookup(zipCode)
        Return True
    End Function
    'This member *may* be part of the CarLocator class!
    Partial Private Sub VerifyDuplicates(ByVal make As String)
    End Sub
    ' A 'lightweight' event handler.
    Partial Private Sub OnZipCodeLookup(ByVal make As String)
    End Sub
End Class
