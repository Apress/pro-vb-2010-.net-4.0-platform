﻿Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Partial Methods *****" & vbLf)
        Console.WriteLine("Load assembly into ildasm to view results")
        Console.ReadLine()
    End Sub
    

End Module
