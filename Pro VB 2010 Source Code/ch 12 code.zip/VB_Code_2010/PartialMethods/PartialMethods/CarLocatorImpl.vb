﻿' CarLocatorImpl.vb
'We don’t need to specify a class as Partial multiple times. 
Public Class CarLocator

    'Method VerifyDuplicate() cannot be declare Partial 
    'multiple times otherwise 
    'it will Produce compiles error. 
    Private Sub VerifyDuplicates(ByVal make As String)
        'Assume some expensive data validation
        'takes place here...
    End Sub
End Class
