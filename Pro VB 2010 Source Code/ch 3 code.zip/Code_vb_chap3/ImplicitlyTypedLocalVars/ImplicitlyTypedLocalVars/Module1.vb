﻿Option Strict On

Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Implicit Typing *****")
        DeclareImplicitVars()
        QueryOverInts()
        Console.WriteLine()
        Console.ReadKey()

    End Sub

#Region "Implicit data typing"
    Sub DeclareImplicitVars()

        'Implicitly typed local variables.
        Dim myInt = 0
        Dim myBool = True
        Dim myString = "Time, marches on..."

        'Print out the underlying type.
        Console.WriteLine("myInt is a: {0}", myInt.GetType().Name)
        Console.WriteLine("myBool is a: {0}", myBool.GetType().Name)
        Console.WriteLine("myString is a: {0}", myString.GetType().Name)
    End Sub

    Function GetAnInt() As Integer
        Dim retVal = 9
        Return retVal
    End Function

    Sub ImplicitTypingIsStrongTyping()
        'The compiler knows "s" is a System.String.
        Dim s = "This variable can only hold String data!"
        s = "This is fine..."

        'Can invoke any member of the underlying type.
        Dim upper As String = s.ToUpper()

        'Error! Can't assign numerical data to a a String!
        's = 44
    End Sub
#End Region

#Region "LINQ example"
    Sub QueryOverInts()
        Dim numbers As Integer() = {10, 20, 30, 40, 1, 2, 3, 8}
        Dim subset = From i In numbers
                     Where i < 10
                     Select i
        Console.Write("Values in subset: ")

        For Each x In subset
            Console.Write("{0} ", x)
        Next
        Console.WriteLine()

        'Hmm...what type is subset?
        Console.WriteLine("subset is a: {0}", subset.GetType().Name)
        Console.WriteLine("subset is defined in: {0}", subset.GetType().Namespace)
    End Sub
#End Region
End Module
