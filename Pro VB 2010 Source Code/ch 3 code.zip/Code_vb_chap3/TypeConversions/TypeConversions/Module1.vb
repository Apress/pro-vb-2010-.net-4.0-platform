﻿Module Module1

    Sub Main()
        Try
            Dim numb1 As Short = 30000, numb2 As Short = 30000

            'Explicitly cast the Integer into a Short (and allow loss of data).
            Dim answer As Short = CShort(Add(numb1, numb2))
            Console.WriteLine("{0} + {1} = {2}", numb1, numb2, answer)

            NarrowingAttempt()
            ProcessBytes()
            Console.ReadLine()

        Catch ex As Exception
            Console.WriteLine(ex.Message)
            Console.ReadLine()
        End Try
      
    End Sub

    Function Add(ByVal x As Integer, ByVal y As Integer) As Integer
        Return x + y
    End Function

#Region "Narrowing / Widening examples"

    Sub NarrowingAttempt()
        Dim myByte As Byte = 0
        Dim myInt As Integer = 200

        'Explicitly cast the Integer into a Byte (no loss of data).
        myByte = CByte(myInt)
        Console.WriteLine("Value of myByte: {0}", myByte)
    End Sub

    Sub ProcessBytes()
        Dim b1 As Byte = 100
        Dim b2 As Byte = 250

        ' This time, tell the compiler to add CIL code
        'to throw an exception if overflow/underflow
        'takes place.
        Try
            Dim sum As Byte = CByte(Add(b1, b2))
            Console.WriteLine("sum = {0}", sum)
        Catch ex As OverflowException
            Console.WriteLine(ex.Message)
        End Try
    End Sub

    Sub NarrowWithConvert()
        Dim myByte As Byte = 0
        Dim myInt As Integer = 200
        Console.WriteLine("Value of myByte: {0}", myByte)
    End Sub
#End Region


End Module
