﻿Module Module1
    Sub Main()
        Console.WriteLine("***** Basic Console I/O *****")
        GetUserData()
        Console.WriteLine()
        FormatNumericalData()
        Console.ReadLine()
    End Sub

#Region "Get some information about the user"
    Sub GetUserData()
        'Get name and age.
        Console.Write("Please enter your name: ")
        Dim userName As String = Console.ReadLine()
        Console.Write("Please enter your age: ")
        Dim userAge As String = Console.ReadLine()
        Dim prevColor As ConsoleColor = Console.ForegroundColor

        'Change echo color, just for fun.
        Console.ForegroundColor = ConsoleColor.Yellow

        'Echo to the console.
        Console.WriteLine("Hello {0}!  You are {1} years old.", userName, userAge)

        'Restore previous color.
        Console.ForegroundColor = prevColor
    End Sub
#End Region

#Region "Format some numerical data"
    ' Now make use of some format tags.
    Sub FormatNumericalData()
        Console.WriteLine("The value 99999 in various formats:")
        Console.WriteLine("c format: {0:c}", 99999)
        Console.WriteLine("d9 format: {0:d9}", 99999)
        Console.WriteLine("f3 format: {0:f3}", 99999)
        Console.WriteLine("n format: {0:n}", 99999)

        'Notice that upper- or lowercasing for hex
        ' determines if letters are upper- or lowercase.
        Console.WriteLine("E format: {0:E}", 99999)
        Console.WriteLine("e format: {0:e}", 99999)
        Console.WriteLine("X format: {0:X}", 99999)
        Console.WriteLine("x format: {0:x}", 99999)
    End Sub
#End Region
End Module
