﻿' Note!  This project has some hard-coded command line args,
' which were set via the Debug tab of the Properties editor.

Module Module1

    ' Note we are now returning an Integer, rather than Sub(return no value).
    Function Main(ByVal args() As String) As Integer
        ' Display a message and wait for Enter key to be pressed.
        Console.WriteLine("***** My First VB App *****")
        Console.WriteLine("Hello World!")
        Console.WriteLine()

        ' Process any incoming args using For Each construct.
        For Each arg As String In args
            Console.WriteLine("Arg: {0}", arg)
        Next arg

        ShowEnvironmentDetails()

        Console.ReadLine()

        ' Return an arbitrary error code.
        ' The supplied *.bat file can be used
        ' to receive this value.
        Return -1
    End Function

    Private Sub ShowEnvironmentDetails()
        ' Print out the drives on this machine,
        ' and other interesting details.
        For Each drive As String In Environment.GetLogicalDrives()
            Console.WriteLine("Drive: {0}", drive)
        Next drive

        Console.WriteLine("OS: {0}", Environment.OSVersion)
        Console.WriteLine("Number of processors: {0}", Environment.ProcessorCount)
        Console.WriteLine(".NET Version: {0}", Environment.Version)
    End Sub

End Module
