﻿Module Module1

    Sub Main()
        Console.WriteLine("***** Loops and Choices *****")
        'ForAndForEachLoop()
        'ImplicitTypingInForEachLoop()
        'ExecuteWhileLoop()
        'ExecuteDoWhileLoop()
        'ExecuteIfElse()
        'ExecuteSwitch()
        ExecuteSwitchOnString()
        Console.ReadLine()
    End Sub

#Region "For / For Each loops"
    ' A basic for loop.
    Sub ForAndForEachLoop()

        'Note! "i" is only visible within the scope of the For loop.
        For j = 0 To 4
            Console.WriteLine("Number is: {0} ", j)
        Next

        '"i" is not visible here.
        Console.WriteLine()

        Dim carTypes As String() = {"Ford", "BMW", "Yugo", "Honda"}
        For Each c In carTypes
            Console.WriteLine(c)
        Next

        Console.WriteLine()

        Dim myInts As Integer() = {10, 20, 30, 40}
        For Each i In myInts
            Console.WriteLine(i)
        Next
    End Sub
#End Region

#Region "ImplicitTyping In For Each Loop"
    Sub ImplicitTypingInForEachLoop()
        Dim myInts As Integer() = {10, 20, 30, 40}

        'Use "ImplicitTyping" in a standard For Each loop.
        For Each item In myInts
            Console.WriteLine("Item value: {0}", item)
        Next
    End Sub
#End Region

#Region "While loop"
    Sub ExecuteWhileLoop()
        Dim userIsDone As String = ""

        'Test on a lower-class copy of the string.
        While userIsDone.ToLower() <> "yes"
            Console.Write("Are you done? [yes] [no]: ")
            userIsDone = Console.ReadLine()
            Console.WriteLine("In While loop")
        End While
    End Sub
#End Region

#Region "Do/While loop"
    Sub ExecuteDoWhileLoop()
        Dim userIsDone As String = ""
        Do
            Console.WriteLine("In do/while loop")
            Console.Write("Are you done? [yes] [no]: ")
            userIsDone = Console.ReadLine()
        Loop While userIsDone.ToLower() <> "yes"
    End Sub
#End Region

#Region "If/Else"

    Sub ExecuteIfElse()
        Dim stringData As String = "My textual data"

        'This is illegal, given that Length returns an Integer, not a Boolean.
        If stringData.Length > 0 Then
            Console.WriteLine("string is greater than 0 characters")
        End If
    End Sub
#End Region

#Region "Select/Case statements"
    'Select/Case on a numerical value.
    Sub ExecuteSwitch()
        Console.WriteLine("1 [VB], 2 [C#]")
        Console.Write("Please pick your language preference: ")
        Dim langChoice As String = Console.ReadLine()
        Dim n As Integer = Integer.Parse(langChoice)
        Select Case n
            Case 1
                Console.WriteLine("Good choice, C# is a fine language.")
            Case 2
                Console.WriteLine("VB .NET: OOP, multithreading, and more!")
            Case Else
                Console.WriteLine("Well...good luck with that!")
        End Select
    End Sub

    Sub ExecuteSwitchOnString()
        Console.WriteLine("C# or VB")
        Console.Write("Please pick your language preference: ")
        Dim langChoice As String = Console.ReadLine()
        Select Case langChoice
            Case "C#"
                Console.WriteLine("Good choice, C# is a fine language.")
            Case "VB"
                Console.WriteLine("VB .NET: OOP, multithreading and more!")
            Case Else
                Console.WriteLine("Well...good luck with that!")
        End Select
    End Sub

#End Region

End Module
