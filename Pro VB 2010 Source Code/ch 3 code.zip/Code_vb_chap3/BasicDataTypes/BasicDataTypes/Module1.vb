﻿Imports System.Numerics
Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Basic Data Types *****" & vbLf)
        'DataTypeFunctionality()
        'LocalVarDeclarations()
        'NewingDataTypes()
        'ObjectFunctionality()
        'DataTypeFunctionality()
        'CharFunctionality()
        'ParseFromStrings()
        ' UseDatesAndTimes()
        UseBigInteger()
        Console.ReadLine()
    End Sub

#Region "Local variable declarations"
    Sub LocalVarDeclarations()
        Console.WriteLine("=> Data Declarations:")

        ' Local variables are declared and initialized as follows:
        'Dim varName As dataType = initialValue
        Dim myInt As Integer = 0
        Dim myString As String
        myString = "This is my character data"

        'Declare 3 Booleans on a single line.
        Dim b1 As Boolean = True, b2 As Boolean = False, b3 As Boolean = b1
        'Very verbose manner in which to declare a Boolean.
        Dim b4 As Boolean = False
        Console.WriteLine("Your data: {0}, {1}, {2}, {3}, {4}, {5}", myInt, myString, b1, b2, b3, b4)
        Console.WriteLine()
    End Sub

    Sub NewingDataTypes()
        Console.WriteLine("=> Using new to create intrinsic data types:")
        Dim b As New Boolean()   'Set to False.
        Dim i As New Integer()   'Set to 0.
        Dim d As New Double()    'Set to 0.
        Dim dt As New DateTime()  'Set to 1/1/0001 12:00:00 AM
        Console.WriteLine("{0}, {1}, {2}, {3}", b, i, d, dt)
        Console.WriteLine()
    End Sub

#End Region

#Region "Test Object functionality"

    Sub ObjectFunctionality()
        Console.WriteLine("=> System.Object Functionality:")

        'A VB Integer is really a shorthand for System.Int32.
        'which inherits the following members from System.Object.
        Console.WriteLine("12.GetHashCode() = {0}", 12.GetHashCode())
        Console.WriteLine("12.Equals(23) = {0}", 12.Equals(23))
        Console.WriteLine("12.ToString() = {0}", 12.ToString())
        Console.WriteLine("12.GetType() = {0}", 12.GetType())
        Console.WriteLine()
    End Sub
#End Region

#Region "Test data type functionality"
    Sub DataTypeFunctionality()
        Console.WriteLine("=> Data type Functionality:")
        Console.WriteLine("Max of Integer: {0}", Integer.MaxValue)
        Console.WriteLine("Min of Integer: {0}", Integer.MinValue)
        Console.WriteLine("Max of Double: {0}", Double.MaxValue)
        Console.WriteLine("Min of Double: {0}", Double.MinValue)
        Console.WriteLine("Double.Epsilon: {0}", Double.Epsilon)
        Console.WriteLine("Double.PositiveInfinity: {0}", Double.PositiveInfinity)
        Console.WriteLine("Double.NegativeInfinity: {0}", Double.NegativeInfinity)
        Console.WriteLine("Boolean.FalseString: {0}", Boolean.FalseString)
        Console.WriteLine("Boolean.TrueString: {0}", Boolean.TrueString)
        Console.WriteLine()
    End Sub
#End Region

#Region "Test Char data type"
    Sub CharFunctionality()
        Console.WriteLine("=> char type Functionality:")
        Dim myChar As Char = "a"c
        Console.WriteLine("Char.IsDigit('a'): {0}", Char.IsDigit(myChar))
        Console.WriteLine("Char.IsLetter('a'): {0}", Char.IsLetter(myChar))
        Console.WriteLine("Char.IsWhiteSpace('Hello There', 5): {0}", Char.IsWhiteSpace("Hello There", 5))
        Console.WriteLine("Char.IsWhiteSpace('Hello There', 6): {0}", Char.IsWhiteSpace("Hello There", 6))
        Console.WriteLine("Char.IsPunctuation('?'): {0}", Char.IsPunctuation("?"c))
        Console.WriteLine()
    End Sub
#End Region

#Region "Parsing data"
    Sub ParseFromStrings()
        Console.WriteLine("=> Data type parsing:")
        Dim b As Boolean = Boolean.Parse("True")
        Console.WriteLine("Value of b: {0}", b)
        Dim d As Double = Double.Parse("99.884")
        Console.WriteLine("Value of d: {0}", d)
        Dim i As Integer = Integer.Parse("8")
        Console.WriteLine("Value of i: {0}", i)
        Dim c As Char = Char.Parse("w")
        Console.WriteLine("Value of c: {0}", c)
        Console.WriteLine()
    End Sub
#End Region

#Region "Work with dates / times"

    Sub UseDatesAndTimes()
        Console.WriteLine("=> Dates and Times:")

        'This constructor takes (year, month, day)
        Dim dt As New DateTime(2004, 10, 17)

        'What day of the month is this?
        Console.WriteLine("The day of {0} is {1}", dt.Date, dt.DayOfWeek)
        dt = dt.AddMonths(2) 'Month is now December.
        Console.WriteLine("Daylight savings: {0}", dt.IsDaylightSavingTime())

        'This constructor takes (hours, minutes, seconds)
        Dim ts As New TimeSpan(4, 30, 0)
        Console.WriteLine(ts)

        'Subtract 15 minutes from the current TimeSpan and
        'print the result.
        Console.WriteLine(ts.Subtract(New TimeSpan(0, 15, 0)))
    End Sub
#End Region

#Region "Use BigInteger"

    Sub UseBigInteger()
        Console.WriteLine("=> Use BigInteger:")
        Dim biggy As BigInteger = BigInteger.Parse("999999999999999999999999999999999999999999")
        Console.WriteLine("Value of biggy is {0}", biggy)
        Console.WriteLine("Is biggy an even value?: {0}", biggy.IsEven)
        Console.WriteLine("Is biggy a power of two?: {0}", biggy.IsPowerOfTwo)
        Dim reallyBig As BigInteger = BigInteger.Multiply(biggy, BigInteger.Parse("888888888888888888888888888888888888888"))
        Console.WriteLine("Value of reallyBig is {0}", reallyBig)

    End Sub
#End Region

End Module
