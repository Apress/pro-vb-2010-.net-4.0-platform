﻿Imports System.Text

Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Strings *****" & vbLf)

        'BasicStringFunctionality()
        'StringConcatenation()
        'EscapeChars()
        'StringsAreImmutable()
        FunWithStringBuilder()
        Console.ReadLine()
    End Sub

#Region "String basics"
    Sub BasicStringFunctionality()
        Console.WriteLine("=> Basic String functionality:")
        Dim firstName As String = "Freddy"
        Console.WriteLine("Value of firstName: {0}", firstName)
        Console.WriteLine("firstName has {0} characters.", firstName.Length)
        Console.WriteLine("firstName in uppercase: {0}", firstName.ToUpper())
        Console.WriteLine("firstName in lowercase: {0}", firstName.ToLower())
        Console.WriteLine("firstName contains the letter y?: {0}", firstName.Contains("y"))
        Console.WriteLine("firstName after replace: {0}", firstName.Replace("dy", ""))
        Console.WriteLine()
    End Sub
#End Region

#Region "Concatenation"
    Sub StringConcatenation()
        Console.WriteLine("=> String concatenation:")
        Dim s1 As String = "Programming the "
        Dim s2 As String = "PsychoDrill (PTP)"
        Dim s3 As String = s1 & s2
        Console.WriteLine(s3)
        Console.WriteLine()
    End Sub
#End Region

#Region "Escape Chars"
    Sub EscapeChars()
        Console.WriteLine("=> Escape characters:" & ChrW(7))
        Dim strWithTabs As String = "Model" & vbTab & "Color" & vbTab & "Speed" & vbTab & "Pet Name" & ChrW(7) & " "
        Console.WriteLine(strWithTabs)
        Console.WriteLine("Everyone loves ""Hello World""" & ChrW(7) & " ")
        Console.WriteLine("C:\MyApp\bin\Debug" & ChrW(7) & " ")
        Console.WriteLine("All finished." & vbLf & vbLf & vbLf & ChrW(7) & " ")
        Console.WriteLine()
        Console.WriteLine("C:\MyApp\bin\Debug")
        Dim myLongString As String = "This is a very" & vbCr & vbLf & " very" & vbCr & vbLf & "very" & vbCr & vbLf & "                           long string"
        Console.WriteLine(myLongString)
        Console.WriteLine()
        Console.WriteLine("Cerebus said ""Darrr! Pret-ty sun-sets""")
    End Sub
#End Region

#Region "Immutable test"
    Sub StringsAreImmutable()
        Dim s2 As String = "My other string"
        s2 = "New string value"
        Console.WriteLine(s2)
    End Sub
#End Region

#Region "StringBuilder"
    Sub FunWithStringBuilder()
        Console.WriteLine("=> Using the StringBuilder:")

        'Make a StringBuilder with an initial size of 256.
        Dim sb As New StringBuilder("**** Fantastic Games ****", 256)
        sb.Append(vbLf)
        sb.AppendLine("Half Life")
        sb.AppendLine("Beyond Good and Evil")
        sb.AppendLine("Deus Ex 2")
        sb.AppendLine("System Shock")
        Console.WriteLine(sb.ToString())
        sb.Replace("2", "Invisible War")
        Console.WriteLine(sb.ToString())
        Console.WriteLine("sb as {0} chars.", sb.Length)
        Console.WriteLine()
    End Sub
#End Region

End Module
