﻿Imports AutoLotDAL
Public Class MainForm

    Dim context As New AutoLotEntities()

    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Bind the ObjectSet(Of Inventory) collection to the grid.
        gridInventory.DataSource = context.Inventories

    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        context.SaveChanges()
        MessageBox.Show("Data saved!")

    End Sub

    Private Sub MainForm_FormClosed(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        context.Dispose()

    End Sub
End Class
