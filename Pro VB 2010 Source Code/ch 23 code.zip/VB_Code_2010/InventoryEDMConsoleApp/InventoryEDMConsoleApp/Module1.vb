﻿Imports System.Data.EntityClient
Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with ADO.NET *****")
        PrintAllInventory()
        AddNewRecord()
        UpdateRecord()
        FunWithLINQQueries()
        FunWithEntitySQL()
        FunWithEntityDataReader()
        RemoveRecord()
        RemoveRecordWithLINQ()

        Console.ReadLine()
    End Sub



#Region "Add new record"
    Private Sub AddNewRecord()
        ' Add record to the Inventory table of the AutoLot
        ' database. 
        Using context As New AutoLotEntities()
            Try
                context.Cars.AddObject(New Car() With {.CarID = 2222, .Make = "Yugo", .Color = "Brown", .CarNickname = "vidya"})
                context.SaveChanges()
            Catch ex As Exception
                Console.WriteLine(ex.InnerException.Message)
            End Try
        End Using
    End Sub
#End Region

#Region "Print all records"
    Private Sub PrintAllInventory()
        ' Select all items from the Inventory table of AutoLot,
        ' and print out the data using our custom ToString()
        ' of the Car entity class. 
        Using context As New AutoLotEntities()
            For Each c As Car In context.Cars
                Console.WriteLine(c)
            Next c
        End Using
    End Sub
#End Region

#Region "Remove and update records"
    Private Sub RemoveRecord()
        ' Find a car to delete by primary key.
        Using context As New AutoLotEntities()
            ' Define a key for the entity we are looking for.
            Dim key As New EntityKey("AutoLotEntities.Cars", "CarID", 2222)

            ' See if we have it.
            Dim carToDelete As Car = CType(context.GetObjectByKey(key), Car)
            If carToDelete IsNot Nothing Then
                context.DeleteObject(carToDelete)
                context.SaveChanges()
            End If
        End Using
    End Sub

    Private Sub UpdateRecord()
        ' Find a car to delete by primary key.
        Using context As New AutoLotEntities()
            ' Define a key for the entity we are looking for.
            Dim key As New EntityKey("AutoLotEntities.Cars", "CarID", 2222)

            ' Grab the car, change it, save! 
            Dim carToUpdate As Car = CType(context.GetObjectByKey(key), Car)
            Console.WriteLine(carToUpdate.EntityState)
            If carToUpdate IsNot Nothing Then
                carToUpdate.Color = "Blue"
                context.SaveChanges()
            End If
        End Using
    End Sub
#End Region


    Private Sub RemoveRecordWithLINQ()
        ' Find a car to delete by primary key.
        Using context As New AutoLotEntities()
            ' See if we have it.
            Dim carToDelete = (
                From c In context.Cars
                Where c.CarID = 2222
                Select c).FirstOrDefault()

            If carToDelete IsNot Nothing Then
                context.DeleteObject(carToDelete)
                context.SaveChanges()
            End If
        End Using
    End Sub

#Region "Various LINQ queries"
    Private Sub FunWithLINQQueries()
        Using context As New AutoLotEntities()
            ' Get all data from the Inventory table.
            ' could also write:
            ' var allData = (from item in context.Cars select item).ToArray();
            Dim allData = context.Cars.ToArray()

            ' Get a projection of new data. 
            Dim colorsMakes = From item In allData
                              Select New With {Key item.Color, Key item.Make}
            For Each item In colorsMakes
                Console.WriteLine(item)
            Next

            ' Get only items where CarID < 1000
            Dim idsLessThan1000 = From item In allData
                                  Where item.CarID < 1000
                                  Select item
            For Each item In idsLessThan1000
                Console.WriteLine(item)
            Next
        End Using
    End Sub
#End Region

#Region "Entity SQL example"
    Private Sub FunWithEntitySQL()
        Using context As New AutoLotEntities()
            ' Build a string containing Entity SQL syntax.
            Dim query As String = "SELECT VALUE car FROM AutoLotEntities.Cars AS car WHERE car.Color='black'"

            ' Now build a ObjectQuery(Of T) based on the string.
            Dim blackCars = context.CreateQuery(Of Car)(query)

            For Each item In blackCars
                Console.WriteLine(item)
            Next
        End Using
    End Sub
#End Region

#Region "Entity Data Reader"
    Private Sub FunWithEntityDataReader()
        ' Make a connection object, based on our *.config file. 
        Using cn As New EntityConnection("name=AutoLotEntities")
            cn.Open()

            ' Now build an Entity SQL query.
            Dim query As String = "SELECT VALUE car FROM AutoLotEntities.Cars AS car"

            ' Create a command object.
            Using cmd As EntityCommand = cn.CreateCommand()
                cmd.CommandText = query

                ' Finally, get the data reader and process records.
                Using dr As EntityDataReader = cmd.ExecuteReader(CommandBehavior.SequentialAccess)
                    Do While dr.Read()
                        Console.WriteLine("***** RECORD *****")
                        Console.WriteLine("ID: {0}", dr("CarID"))
                        Console.WriteLine("Make: {0}", dr("Make"))
                        Console.WriteLine("Color: {0}", dr("Color"))
                        Console.WriteLine("Pet Name: {0}", dr("CarNickname"))
                        Console.WriteLine()
                    Loop
                End Using
            End Using
        End Using
    End Sub
#End Region
End Module
