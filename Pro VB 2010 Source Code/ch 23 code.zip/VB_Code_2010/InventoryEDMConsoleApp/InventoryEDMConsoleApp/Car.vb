﻿#Region "Extended Car data."
Partial Public Class Car

    Public Overrides Function ToString() As String
        ' Since the PetName column could be empty, supply
        ' the default name of **No Name**.
        Return String.Format("{0} is a {1} {2} with ID {3}.", If(Me.CarNickname, "**No Name**"), Me.Color, Me.Make, Me.CarID)
    End Function

    Private Sub OnCarNicknameChanging(ByVal value As Global.System.String)
        Console.WriteLine(vbTab & "-> Changing name to: {0}", value)
    End Sub

    Private Sub OnCarNicknameChanged()
        Console.WriteLine(vbTab & "-> Name of car has been changed!")
    End Sub
End Class
#End Region
