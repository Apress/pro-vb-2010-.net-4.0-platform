﻿Imports AutoLotDAL
Imports System.Data.Objects

Module Module1

    Sub Main()
        Console.WriteLine("***** Navigation Properties *****")
        Console.Write("Please enter customer ID: ")
        Dim custID As String = Console.ReadLine()

        PrintCustomerOrders(custID)
        CallStoredProc()
        Console.WriteLine("All done!")
        Console.ReadLine()

    End Sub
#Region "Print customer orders"
    Private Sub PrintCustomerOrders(ByVal custID As String)
        Dim id As Integer = Integer.Parse(custID)

        Using context As New AutoLotEntities()
            Dim carsOnOrder = From o In context.Orders
                              Where o.CustID = id
                              Select o.Inventory

            Console.WriteLine(vbLf & "Customer has {0} orders pending:", carsOnOrder.Count())

            For Each item In carsOnOrder
                Console.WriteLine("-> {0} {1} named {2}.", item.Color, item.Make, item.PetName)
            Next item
        End Using
    End Sub
#End Region

#Region "Invoke stored proc"
    Private Sub CallStoredProc()
        Using context As New AutoLotEntities()
            Dim input As New ObjectParameter("carID", 83)
            Dim output As New ObjectParameter("petName", GetType(String))

            ' Call ExecuteFunction off the context....
            context.ExecuteFunction("GetPetName", input, output)

            ' ....or use the strongly typed method on the context.
            context.GetPetName(83, output)

            Console.WriteLine("Car #83 is named {0}", output.Value)
        End Using
    End Sub
#End Region

End Module
