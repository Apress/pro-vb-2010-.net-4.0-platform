﻿Imports Microsoft.VisualBasic
#Region "Simple person class"
Public Class Person
    Public Property FirstName() As String
    Public Property LastName() As String
End Class
#End Region


Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with the Dynamic Type *****")
        ImplicitlyTypedVariable()
        Console.WriteLine()

        UseObjectVarible()
        Console.WriteLine()

        PrintThreeStrings()
        Console.WriteLine()

        ChangeDynamicDataType()
        Console.WriteLine()

        InvokeMembersOnDynamicData()
        Console.WriteLine()

        Console.ReadLine()
    End Sub

#Region "Implicit typing review..."
    Sub ImplicitlyTypedVariable()
        ' a is of type List(Of Integer).
        Dim a = New List(Of Integer)()
        a.Add(90)

        ' This would be an error!
        'a = "Hello"
    End Sub
#End Region

#Region "Object has reference review..."
    Sub UseObjectVarible()
        ' Assume we have a class named Person. 
        Dim o As Object = New Person() With {.FirstName = "Mike", .LastName = "Larson"}

        ' Must cast object as Person to gain access 
        ' to the Person properties. 
        Console.WriteLine("Person's first name is {0}", (CType(o, Person)).FirstName)
    End Sub
#End Region

#Region "implict, obj ref and dynamic string data"
    Sub PrintThreeStrings()
        Dim s1 = "Greetings"
        Dim s2 As Object = "From"
        Dim s3 As Object = "Minneapolis"

        Console.WriteLine("s1 is of type: {0}", s1.GetType())
        Console.WriteLine("s2 is of type: {0}", s2.GetType())
        Console.WriteLine("s3 is of type: {0}", s3.GetType())
    End Sub
#End Region

#Region "Change a dynamic local variable on the fly. "
    Sub ChangeDynamicDataType()
        ' Declare a single dynamic data point
        ' named 't'.
        Dim t As Object = "Hello!"
        Console.WriteLine("t is of type: {0}", t.GetType())

        t = False
        Console.WriteLine("t is of type: {0}", t.GetType())

        t = New List(Of Integer)()
        Console.WriteLine("t is of type: {0}", t.GetType())
    End Sub
#End Region


#Region "Invoke members on dynamic data"
    Sub InvokeMembersOnDynamicData()
        Dim textData1 As Object = "Hello"

        Try
            Console.WriteLine(textData1.ToUpper())
            Console.WriteLine(textData1.ToUpper1())
            Console.WriteLine(textData1.Foo(10, "ee", Date.Now))
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try
    End Sub
#End Region
End Module
