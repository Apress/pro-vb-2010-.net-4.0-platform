﻿Imports System.Reflection
Imports MathLibrary

Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Dynamic Types*****")
        AddWithReflection()
        AddWithDynamic()
        Console.ReadLine()
    End Sub
#Region "Late binding with dynamic"
    Private Sub AddWithDynamic()
        Dim asm As Assembly = Assembly.Load("MathLibrary")
        Try
            'Get metadata for the SimpleMath type.
            Dim math As Type = asm.GetType("MathLibrary.SimpleMath")
            'Create a SimpleMath on the fly.
            Dim obj As Object = Activator.CreateInstance(math)
            Console.WriteLine("Result is: {0}", obj.Add(10, 70))
        Catch ex As Microsoft.CSharp.RuntimeBinder.RuntimeBinderException
            Console.WriteLine(ex.Message)
        End Try
    End Sub
#End Region


#Region "Late binding with reflection"
    Private Sub AddWithReflection()
        Dim asm As Assembly = Assembly.Load("MathLibrary")
        Try
            'Get metadata for the SimpleMath type.
            Dim math As Type = asm.GetType("MathLibrary.SimpleMath")
            ' Create a SimpleMath on the fly.
            Dim obj As Object = Activator.CreateInstance(math)
            'Get info for Add.
            Dim mi As MethodInfo = math.GetMethod("Add")
            'Invoke method (with parameters).
            Dim args As Object() = {10, 70}
            Console.WriteLine("Result is: {0}", mi.Invoke(obj, args))
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try
    End Sub
#End Region
    

End Module
