﻿Public Class NewCarDialog

    Public theCar As Car = Nothing

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        theCar = New Car() With {.PetName = txtCarName.Text, .Make = lstMakes.Text, .Color = lstColors.Text}
    End Sub

End Class