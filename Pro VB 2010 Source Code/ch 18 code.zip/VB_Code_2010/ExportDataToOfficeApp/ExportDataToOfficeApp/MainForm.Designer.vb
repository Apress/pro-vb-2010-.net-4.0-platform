﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.dataGridCars = New System.Windows.Forms.DataGridView()
        Me.btnAddNewCar = New System.Windows.Forms.Button()
        Me.btnExportToExcel = New System.Windows.Forms.Button()
        CType(Me.dataGridCars, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblInstructions
        '
        Me.lblInstructions.AutoSize = True
        Me.lblInstructions.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstructions.Location = New System.Drawing.Point(27, 35)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(134, 17)
        Me.lblInstructions.TabIndex = 0
        Me.lblInstructions.Text = "Current Inventory"
        '
        'dataGridCars
        '
        Me.dataGridCars.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dataGridCars.Location = New System.Drawing.Point(30, 73)
        Me.dataGridCars.Name = "dataGridCars"
        Me.dataGridCars.Size = New System.Drawing.Size(397, 150)
        Me.dataGridCars.TabIndex = 1
        '
        'btnAddNewCar
        '
        Me.btnAddNewCar.Location = New System.Drawing.Point(41, 245)
        Me.btnAddNewCar.Name = "btnAddNewCar"
        Me.btnAddNewCar.Size = New System.Drawing.Size(175, 23)
        Me.btnAddNewCar.TabIndex = 2
        Me.btnAddNewCar.Text = "Add New Entry to Inventory"
        Me.btnAddNewCar.UseVisualStyleBackColor = True
        '
        'btnExportToExcel
        '
        Me.btnExportToExcel.Location = New System.Drawing.Point(244, 245)
        Me.btnExportToExcel.Name = "btnExportToExcel"
        Me.btnExportToExcel.Size = New System.Drawing.Size(183, 23)
        Me.btnExportToExcel.TabIndex = 3
        Me.btnExportToExcel.Text = "Export Current Inventory to Excel"
        Me.btnExportToExcel.UseVisualStyleBackColor = True
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(469, 290)
        Me.Controls.Add(Me.btnExportToExcel)
        Me.Controls.Add(Me.btnAddNewCar)
        Me.Controls.Add(Me.dataGridCars)
        Me.Controls.Add(Me.lblInstructions)
        Me.Name = "MainForm"
        Me.Text = "The Office COM Interop App!"
        CType(Me.dataGridCars, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblInstructions As System.Windows.Forms.Label
    Friend WithEvents dataGridCars As System.Windows.Forms.DataGridView
    Friend WithEvents btnAddNewCar As System.Windows.Forms.Button
    Friend WithEvents btnExportToExcel As System.Windows.Forms.Button

End Class
