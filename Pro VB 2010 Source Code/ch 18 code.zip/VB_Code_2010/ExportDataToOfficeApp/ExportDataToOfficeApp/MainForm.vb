﻿'Create an alais to the Excel object model.
Imports Excel = Microsoft.Office.Interop.Excel

Public Class MainForm
   
    Dim carsInStock As List(Of Car) = Nothing

#Region "UI event handlers"
    Private Sub btnExportToExcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExportToExcel.Click
        ExportToExcel(carsInStock)
        'ExportToExcel2010(carsInStock)
    End Sub

    Private Sub btnAddNewCar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddNewCar.Click
        Dim d As New NewCarDialog()
        If d.ShowDialog() = DialogResult.OK Then
            ' Add new car to list.
            carsInStock.Add(d.theCar)
            UpdateGrid()
        End If
    End Sub

    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        carsInStock = New List(Of Car) From {
                New Car With {.Color = "Green", .Make = "VW", .PetName = "Mary"},
                New Car With {.Color = "Red", .Make = "Saab", .PetName = "Mel"},
                New Car With {.Color = "Black", .Make = "Ford", .PetName = "Hank"},
                New Car With {.Color = "Yellow", .Make = "BMW", .PetName = "Davie"}
           }
        UpdateGrid()
    End Sub
#End Region

#Region "Export to Excel spreadsheet using VB 4.0 features."
   Shared Sub ExportToExcel(ByVal carsInStock As List(Of Car))
        ' Load up Excel, then make a new empty workbook.
        Dim excelApp As New Excel.Application()
        excelApp.Workbooks.Add()

        ' This example uses a single workSheet. 
        Dim workSheet As Excel._Worksheet = excelApp.ActiveSheet

        ' Establish column headings in cells.
        workSheet.Cells(1, "A") = "Make"
        workSheet.Cells(1, "B") = "Color"
        workSheet.Cells(1, "C") = "Pet Name"

        ' Now, map all data in List(Of Car) to the cells of the spread sheet. 
        Dim row As Integer = 1
        For Each c In carsInStock
            row += 1
            workSheet.Cells(row, "A") = c.Make
            workSheet.Cells(row, "B") = c.Color
            workSheet.Cells(row, "C") = c.PetName
        Next

        ' Give our table data a nice look and feel. 
        workSheet.Range("A1").AutoFormat(Excel.XlRangeAutoFormat.xlRangeAutoFormatClassic2)

        ' Save the file, quit Excel and display message to user. 
        workSheet.SaveAs(String.Format("{0}\Inventory.xlsx", Environment.CurrentDirectory))
        excelApp.Quit()
        MessageBox.Show("The Inventory.xslx file has been saved to your app folder", "Export complete!")
    End Sub
#End Region

#Region "Export to Excel spreadsheed without VB 4.0 features."
    Shared Sub ExportToExcel2010(ByVal carsInStock As List(Of Car))
        Dim excelApp As New Excel.Application()

        ' Must mark missing params! 
        excelApp.Workbooks.Add(Type.Missing)

        ' Must cast Object as _Worksheet! 
        Dim workSheet As Excel._Worksheet = CType(excelApp.ActiveSheet, Excel._Worksheet)

        ' Must cast each Object as Range object then call
        ' call low level Value2 property!
        CType(excelApp.Cells(1, "A"), Excel.Range).Value2 = "Make"
        CType(excelApp.Cells(1, "B"), Excel.Range).Value2 = "Color"
        CType(excelApp.Cells(1, "C"), Excel.Range).Value2 = "Pet Name"

        Dim row As Integer = 1
        For Each c In carsInStock
            row += 1
            ' Must cast each Object as Range and call low level Value2 prop!
            CType(workSheet.Cells(row, "A"), Excel.Range).Value2 = c.Make
            CType(workSheet.Cells(row, "B"), Excel.Range).Value2 = c.Color
            CType(workSheet.Cells(row, "C"), Excel.Range).Value2 = c.PetName
        Next

        ' Must call get_Range method and then specify all missing args!. 
        excelApp.get_Range("A1", Type.Missing).AutoFormat(Excel.XlRangeAutoFormat.xlRangeAutoFormatClassic2, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing)

        ' Must specify all missing optional args!  
        workSheet.SaveAs(String.Format("{0}\Inventory.xlsx", Environment.CurrentDirectory), Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing)
        excelApp.Quit()
        MessageBox.Show("The Inventory.xslx file has been saved to your app folder", "Export complete!")
    End Sub
#End Region

#Region "Update the grid."
    Private Sub UpdateGrid()
        'Reset the source of data. 
        dataGridCars.DataSource = Nothing
        dataGridCars.DataSource = carsInStock
    End Sub
#End Region

End Class
