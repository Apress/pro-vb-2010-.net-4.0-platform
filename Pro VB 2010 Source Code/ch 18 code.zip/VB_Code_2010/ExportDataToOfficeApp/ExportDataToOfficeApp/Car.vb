﻿Public Class Car

    Public Property Make() As String
    Public Property Color() As String
    Public Property PetName() As String

End Class
