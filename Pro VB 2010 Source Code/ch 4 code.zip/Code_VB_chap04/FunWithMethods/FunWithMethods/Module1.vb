﻿Imports System.Runtime.InteropServices

Module Module1
    Sub Main()
        Console.WriteLine("***** Fun with Methods *****" & vbLf)
        'Pass two variables in by value.
        'Dim x As Integer = 9, y As Integer = 10
        'Console.WriteLine("Before call: X: {0}, Y: {1}", x, y)
        'Console.WriteLine("Answer is: {0}", Add(x, y))
        'Console.WriteLine("After call: X: {0}, Y: {1}", x, y)

        'No need to assign initial value to local variables
        'used as output parameters.
        'Dim ans As Integer
        'Add(90, 90, ans)
        'Console.WriteLine("90 + 90 = {0}", ans)
        'Dim i As Integer, str As String, b As Boolean
        'FillTheseValues(i,str, b);
        'Console.WriteLine("Integer is: {0}", i)
        'Console.WriteLine("String is: {0}", str)
        'Console.WriteLine("Boolean is: {0}", b)

        'Dim s1 As String = "Flip"
        'Dim s2 As String = "Flop"
        'Console.WriteLine("Before: {0}, {1} ", s1, s2)
        ' SwapStrings(s1, s2)
        'Console.WriteLine("After: {0}, {1} ", s1, s2)

        ' Pass in a comma-delimited list of Doubles...
        'Dim average As Double
        'average = CalculateAverage(4.0, 3.2, 5.7, 64.22, 87.2)
        'Console.WriteLine("Average of data is: {0}", average)

        '...or pass an array of doubles.
        'Dim data() As Double = {4.0, 3.2, 5.7}
        'average = CalculateAverage(data)
        'Console.WriteLine("Average of data is: {0}", average)

        ' Average of 0 is 0!
        'Console.WriteLine("Average of data is: {0}", CalculateAverage())

        'EnterLogData("Oh no! Grid can't find data")
        'EnterLogData("Oh no! I can't find the payroll data", "CFO")
        DisplayFancyMessage(message:="Wow!  Very Fancy indeed!", textColor:=ConsoleColor.DarkRed, backgroundColor:=ConsoleColor.White)

        DisplayFancyMessage(backgroundColor:=ConsoleColor.Green, message:="Testing...", textColor:=ConsoleColor.DarkBlue)

        ' This is OK, as positional args are listed before named args.
        DisplayFancyMessage(ConsoleColor.Blue, message:="Testing...", backgroundColor:=ConsoleColor.White)

        ' These work only if all args are optional.
        DisplayFancyMessage(message:="Hello!")
        DisplayFancyMessage(backgroundColor:=ConsoleColor.Green)

        Console.ReadLine()

    End Sub

#Region "By-value parameters"
    ' Arguments are passed By-value by default.
    Function Add(ByVal x As Integer, ByVal y As Integer) As Integer
        Dim ans As Integer = x + y

        ' Caller will not see these changes
        ' as you are modifying a copy of the
        ' original data.
        x = 10000
        y = 88888
        Return ans
    End Function
#End Region

#Region "Output parameters"
    ' Output parameters must be assigned by the called method.
    Sub Add(ByVal x As Integer, ByVal y As Integer, <Out()> ByRef ans As Integer)
        ans = x + y
    End Sub

    ' Returning multiple output parameters.
    Sub FillTheseValues(<Out()> ByRef a As Integer, <Out()> ByRef b As String, <Out()> ByRef c As Boolean)
        a = 9
        b = "Enjoy your string."
        c = True
    End Sub
#End Region

#Region "Ref parameters"
    ' Reference parameters.
    Public Sub SwapStrings(ByRef s1 As String, ByRef s2 As String)
        Dim tempStr As String = s1
        s1 = s2
        s2 = tempStr
    End Sub
#End Region

#Region "ParamArray"
    ' Return average of "some number" of doubles.
    Function CalculateAverage(ByVal ParamArray values As Double()) As Double
        Console.WriteLine("You sent me {0} Doubles.", values.Length)

        Dim sum As Double = 0
        If values.Length = 0 Then
            Return sum
        End If

        For i = 0 To values.Length - 1
            sum += values(i)
        Next
        Return (sum / values.Length)
    End Function
#End Region

#Region "Optional arguments and named arguments"
    Sub EnterLogData(ByVal message As String, Optional ByVal owner As String = "Programmer")
        Console.Beep()
        Console.WriteLine("Error: {0}", message)
        Console.WriteLine("Owner of Error: {0}", owner)
    End Sub

    Private Sub DisplayFancyMessage(Optional ByVal textColor As ConsoleColor = ConsoleColor.Blue, Optional ByVal backgroundColor As ConsoleColor = ConsoleColor.White, Optional ByVal message As String = "Test Message")
        ' Store old colors to restore once message is printed. 
        Dim oldTextColor As ConsoleColor = Console.ForegroundColor
        Dim oldbackgroundColor As ConsoleColor = Console.BackgroundColor

        ' Set new colors and print message.
        Console.ForegroundColor = textColor
        Console.BackgroundColor = backgroundColor

        Console.WriteLine(message)

        ' Restore previous colors. 
        Console.ForegroundColor = oldTextColor
        Console.BackgroundColor = oldbackgroundColor
    End Sub

#End Region
End Module
