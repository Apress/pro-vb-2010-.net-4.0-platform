﻿Module Module1
    Sub Main()
        Console.WriteLine("***** Fun with Arrays *****")
        SimpleArrays()
        ArrayInitialization()
        DeclareImplicitArrays()
        ArrayOfObjects()
        RectMultidimensionalArray()
        JaggedMultidimensionalArray()
        PassAndReceiveArrays()
        SystemArrayFunctionality()
        Console.ReadLine()
    End Sub
    Sub SimpleArrays()
        Console.WriteLine("=> Simple Array Creation.")
        Dim myInts As Integer() = New Integer(2) {}
        myInts(0) = 100
        myInts(1) = 200
        myInts(2) = 300
        For Each i As Integer In myInts
            Console.WriteLine(i)
        Next
        Console.WriteLine()
    End Sub

    Sub ArrayInitialization()
        Console.WriteLine("=> Array Initialization.")
        Dim stringArray As String() = New String() {"one", "two", "three"}
        Console.WriteLine("stringArray has {0} elements", stringArray.Length)
        Dim boolArray As Boolean() = {False, False, True}
        Console.WriteLine("boolArray has {0} elements", boolArray.Length)
        Dim intArray As Integer() = New Integer(4) {20, 22, 23, 0, 25}
        Console.WriteLine("intArray has {0} elements", intArray.Length)
        Console.WriteLine()
    End Sub

    Sub DeclareImplicitArrays()
        Dim a = {1, 10, 100, 1000}
        Console.WriteLine("a is a: {0}", a.ToString())
        Dim b = {1, 1.5, 2, 2.5}
        Console.WriteLine("b is a: {0}", b.ToString())
        Dim c = {"hello", Nothing, "world"}
        Console.WriteLine("c is a: {0}", c.ToString())
        Console.WriteLine()
    End Sub

    Sub ArrayOfObjects()
        Console.WriteLine("=> Array of Objects.")
        Dim myObjects As Object() = New Object(3) {}
        myObjects(0) = 10
        myObjects(1) = False
        myObjects(2) = New DateTime(1969, 3, 24)
        myObjects(3) = "Form & Void"
        For Each obj As Object In myObjects
            Console.WriteLine("Type: {0}, Value: {1}", obj.GetType(), obj)
        Next
        Console.WriteLine()
    End Sub

    Sub RectMultidimensionalArray()
        Console.WriteLine("=> Rectangular multidimensional array.")
        Dim myMatrix As Integer(,)
        myMatrix = New Integer(5, 5) {}
        For i = 0 To 5
            For j = 0 To 5
                myMatrix(i, j) = i * j
            Next
        Next
        For k = 0 To 5
            For j = 0 To 5
                Console.Write(myMatrix(k, j) & vbTab)
            Next
            Console.WriteLine()
        Next
        Console.WriteLine()
    End Sub

    Sub JaggedMultidimensionalArray()
        Console.WriteLine("=> Jagged multidimensional array.")
        Dim myJagArray As Integer()() = New Integer(4)() {}
        For i = 0 To myJagArray.Length - 1
            myJagArray(i) = New Integer(i + 6) {}
        Next
        For k = 0 To 4
            For j = 0 To myJagArray(k).Length - 1
                Console.Write(myJagArray(k)(j) & " ")

            Next
            Console.WriteLine()
        Next
            Console.WriteLine()
    End Sub

    Sub PrintArray(ByVal myInts As Integer())
        For i = 0 To myInts.Length - 1
            Console.WriteLine("Item {0} is {1}", i, myInts(i))
        Next
    End Sub

    Function GetStringArray() As String()
        Dim theStrings As String() = {"Hello", "from", "GetStringArray"}
        Return theStrings
    End Function

    Sub PassAndReceiveArrays()
        Console.WriteLine("=> Arrays as params and return values.")
        Dim ages As Integer() = {20, 22, 23, 0}
        PrintArray(ages)
        Dim strs As String() = GetStringArray()
        For Each s In strs
            Console.WriteLine(s)
        Next
        Console.WriteLine()
    End Sub

    Sub SystemArrayFunctionality()
        Console.WriteLine("=> Working with System.Array.")
        Dim gothicBands As String() = {"Tones on Tail", "Bauhaus", "Sisters of Mercy"}
        Console.WriteLine(" -> Here is the array:")
        For i = 0 To gothicBands.Length - 1
            Console.Write(gothicBands(i) & ", ")

        Next
        Console.WriteLine(vbLf)
        Array.Reverse(gothicBands)
        Console.WriteLine(" -> The reversed array")
        For k = 0 To gothicBands.Length - 1
            Console.Write(gothicBands(k) & ", ")

        Next
        Console.WriteLine(vbLf)
        Console.WriteLine(" -> Cleared out all but one...")
        Array.Clear(gothicBands, 1, 2)
        For p = 0 To gothicBands.Length - 1
            Console.Write(gothicBands(p) & ", ")

        Next
        Console.WriteLine()
    End Sub
End Module
