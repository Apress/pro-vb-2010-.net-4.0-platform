﻿#Region "Simple Person class"
Public Class Person
    Public personName As String
    Public personAge As Integer

    ' Constructors.
    Public Sub New(ByVal name As String, ByVal age As Integer)
        personName = name
        personAge = age
    End Sub

    Public Sub New()
    End Sub

    Public Sub Display()
        Console.WriteLine("Name: {0}, Age: {1}", personName, personAge)
    End Sub
End Class
#End Region

Module Module1
    Sub Main()
        ' Passing ref-types by ref.
        Console.WriteLine(vbLf & "***** Passing Person object by reference *****")
        Dim mel As New Person("Mel", 23)
        Console.WriteLine("Before by ref call, Person is:")
        mel.Display()

        SendAPersonByReference(mel)
        Console.WriteLine("After by ref call, Person is:")
        mel.Display()
        Console.ReadLine()
    End Sub

    Sub SendAPersonByValue(ByVal p As Person)
        ' Change the age of "p"?
        p.personAge = 99

        ' Will the caller see this reassignment?
        p = New Person("Nikki", 99)
    End Sub

    Sub SendAPersonByReference(ByRef p As Person)
        ' Change some data of "p".
        p.personAge = 555

        ' "p" is now pointing to a new object on the heap!
        p = New Person("Nikki", 999)
    End Sub
End Module
