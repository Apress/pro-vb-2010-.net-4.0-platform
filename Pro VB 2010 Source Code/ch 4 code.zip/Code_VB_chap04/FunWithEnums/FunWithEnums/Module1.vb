﻿Enum EmpType As Byte
    Manager = 10
    Grunt = 1
    Contractor = 100
    VicePresident = 9
End Enum

Module Module1

    Sub Main()
        Console.WriteLine("**** Fun with Enums *****")
        Dim e2 As EmpType = EmpType.Contractor

        ' These types are Enums in the System namespace.
        Dim day As DayOfWeek = DayOfWeek.Monday
        Dim cc As ConsoleColor = ConsoleColor.Gray
        EvaluateEnum(e2)
        EvaluateEnum(day)
        EvaluateEnum(cc)
        Console.ReadLine()
    End Sub

#Region "Enum as parameter"
    ' Enums as parameters.
    Sub AskForBonus(ByVal e As EmpType)
        Select Case e
            Case EmpType.Manager
                Console.WriteLine("How about stock options instead?")

            Case EmpType.Grunt
                Console.WriteLine("You have got to be kidding...")

            Case EmpType.Contractor
                Console.WriteLine("You already get enough cash...")

            Case EmpType.VicePresident
                Console.WriteLine("VERY GOOD, Sir!")

        End Select
    End Sub
#End Region

#Region "Just a test.  Uncomment to verify."
    Sub ThisMethodWillNotCompile()
        'Error! SalesManager is not in the EmpType Enum!
        'Dim emp As EmpType = EmpType.SalesManager

        'Error! Forgot to scope Grunt value to EmpType Enum!
        'emp = Grunt
    End Sub
#End Region

#Region "Examine enum!"
    ' This method will print out the details of any enum.
    Sub EvaluateEnum(ByVal e As System.Enum)
        Console.WriteLine("=> Information about {0}", e.GetType().Name)

        Console.WriteLine("Underlying storage type: {0}", [Enum].GetUnderlyingType(e.GetType()))

        ' Get all name/value pairs for incoming parameter.
        Dim enumData As Array = [Enum].GetValues(e.GetType())
        Console.WriteLine("This enum has {0} members.", enumData.Length)

        ' Now show the string name and associated value.

        For i = 0 To enumData.Length - 1
            Console.WriteLine("Name: {0}, Value: {0:D}", enumData.GetValue(i))
        Next
        Console.WriteLine()
    End Sub
#End Region

End Module
