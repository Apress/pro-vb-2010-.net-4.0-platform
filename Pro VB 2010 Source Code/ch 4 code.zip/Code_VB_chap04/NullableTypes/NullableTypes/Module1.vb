﻿Public Class DatabaseReader
    ' Nullable data field.
    Public numericValue As Nullable(Of Integer) = Nothing
    Public boolValue As Nullable(Of Boolean) = True

    ' Note the nullable return type.
    Public Function GetIntFromDatabase() As Nullable(Of Integer)
        Return numericValue
    End Function

    ' Note the nullable return type.
    Public Function GetBoolFromDatabase() As Nullable(Of Boolean)
        Return boolValue
    End Function
End Class

Module Module1
    Sub Main()
        Console.WriteLine("***** Fun with Nullable Data *****" & vbLf)
        Dim dr As New DatabaseReader()

        ' Get Integer from "database".
        Dim i As Nullable(Of Integer) = dr.GetIntFromDatabase()
        If i.HasValue Then
            Console.WriteLine("Value of 'i' is: {0}", i.Value)
        Else
            Console.WriteLine("Value of 'i' is undefined.")
        End If

        ' Get Boolean from "database".
        Dim b As Nullable(Of Boolean) = dr.GetBoolFromDatabase()
        If b IsNot Nothing Then
            Console.WriteLine("Value of 'b' is: {0}", b.Value)
        Else
            Console.WriteLine("Value of 'b' is undefined.")
        End If

        ' If the value from GetIntFromDatabase() is Nothing,
        ' assign local variable to 100.
        Dim myData As Integer = If(dr.GetIntFromDatabase(), 100)
        Console.WriteLine("Value of myData: {0}", myData)

        Dim moreData As Nullable(Of Integer) = dr.GetIntFromDatabase()
        If Not moreData.HasValue Then
            moreData = 100
        End If
        Console.WriteLine("Value of moreData: {0}", moreData)

        Console.ReadLine()
    End Sub

#Region "Declaring nullable data types."
    Sub LocalNullableVariables()
        ' Define some local nullable types.
        Dim nullableInt As Nullable(Of Integer) = 10
        Dim nullableDouble As Nullable(Of Double) = 3.14
        Dim nullableBool As Nullable(Of Boolean) = Nothing
        Dim nullableChar As Nullable(Of Char) = "a"c
        Dim arrayOfNullableInts As Nullable(Of Integer)() = New Nullable(Of Integer)(10) {}

        'Error! Strings are reference types!
        'Dim s? As String = "oops"
    End Sub

#End Region
End Module
