﻿Module Module1

    Sub Main()
        Console.WriteLine("***** A First Look at Structures *****")
        ' Create an initial Point.
        Dim myPoint As Point
        myPoint.X = 349
        myPoint.Y = 76
        myPoint.Display()

        ' Adjust the X and Y values.
        myPoint.Increment()
        myPoint.Display()

        ' Set all fields to default values
        ' using the default constructor.
        Dim p1 As New Point()

        ' Prints X=0,Y=0
        p1.Display()

        ' Call custom constructor.
        Dim p2 As New Point(50, 60)

        ' Prints X=50,Y=60
        p2.Display()

        Console.ReadLine()
    End Sub
End Module

#Region "Simple structure"
Structure Point
    ' Fields of the structure.
    Public X As Integer
    Public Y As Integer

    ' Add 1 to the (X, Y) position.
    Public Sub Increment()
        X += 1
        Y += 1

    End Sub

    ' Subtract 1 from the (X, Y) position.
    Public Sub Decrement()
        X -= 1
        Y -= 1
    End Sub

    ' Display the current position.
    Public Sub Display()
        Console.WriteLine("X = {0}, Y = {1}", X, Y)
    End Sub

    ' A custom constructor.
    Public Sub New(ByVal XPos As Integer, ByVal YPos As Integer)
        X = XPos
        Y = YPos
    End Sub
End Structure
#End Region