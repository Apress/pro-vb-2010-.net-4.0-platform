﻿#Region "Simple structure"
Structure Point
    ' Fields of the structure.
    Public X As Integer
    Public Y As Integer

    ' Add 1 to the (X, Y) position.
    Public Sub Increment()
        X = X + 1
        Y = Y + 1
    End Sub

    ' Subtract 1 from the (X, Y) position.
    Public Sub Decrement()
        X = X - 1
        Y = Y - 1
    End Sub

    ' Display the current position.
    Public Sub Display()
        Console.WriteLine("X = {0}, Y = {1}", X, Y)
    End Sub

    ' A custom constructor.
    Public Sub New(ByVal XPos As Integer, ByVal YPos As Integer)
        X = XPos
        Y = YPos
    End Sub
End Structure
#End Region

#Region "Simple class"
Public Class PointRef
    ' Fields of the class.
    Public X As Integer
    Public Y As Integer

    ' Add 1 to the (X, Y) position.
    Public Sub Increment()
        X = X + 1
        Y = Y + 1
    End Sub

    ' Subtract 1 from the (X, Y) position.
    Public Sub Decrement()
        X = X - 1
        Y = Y - 1
    End Sub

    ' Display the current position.
    Public Sub Display()
        Console.WriteLine("X = {0}, Y = {1}", X, Y)
    End Sub

    ' A custom constructor.
    Public Sub New(ByVal XPos As Integer, ByVal YPos As Integer)
        X = XPos
        Y = YPos
    End Sub
End Class
#End Region

#Region "Struct containing class!"
Public Class ShapeInfo
    Public infoString As String
    Public Sub New(ByVal info As String)
        infoString = info
    End Sub
End Class

Structure Rectangle
    ' The Rectangle structure contains a reference type member.
    Public rectInfo As ShapeInfo

    Public rectTop As Integer, rectLeft As Integer, rectBottom As Integer, rectRight As Integer

    Public Sub New(ByVal info As String, ByVal top As Integer, ByVal left As Integer, ByVal bottom As Integer, ByVal right As Integer)
        rectInfo = New ShapeInfo(info)
        rectTop = top
        rectBottom = bottom
        rectLeft = left
        rectRight = right
    End Sub

    Public Sub Display()
        Console.WriteLine("String = {0}, Top = {1}, Bottom = {2}," + "Left = {3}, Right = {4}", rectInfo.infoString, rectTop, rectBottom, rectLeft, rectRight)
    End Sub
End Structure
#End Region

Module Module1
    Sub Main()
        Console.WriteLine("***** Values types / Reference types *****" & vbLf)
        'ValueTypeAssignment();
        'ReferenceTypeAssignment();
        ValueTypeContainingRefType()
        Console.ReadLine()
    End Sub

    Sub ValueTypeContainingRefType()
        ' Create the first Rectangle.
        Console.WriteLine("-> Creating r1")
        Dim r1 As New Rectangle("First Rect", 10, 10, 50, 50)

        ' Now assign a new Rectangle to r1.
        Console.WriteLine("-> Assigning r2 to r1")
        Dim r2 As Rectangle = r1

        ' Change some values of r2.
        Console.WriteLine("-> Changing values of r2")
        r2.rectInfo.infoString = "This is new info!"
        r2.rectBottom = 4444

        ' Print values of both rectangles.
        r1.Display()
        r2.Display()
    End Sub

#Region "Structures and assignment operator"
    ' Assigning two intrinsic value types results in
    ' two independent variables on the stack.
    Sub ValueTypeAssignment()
        Console.WriteLine("Assigning value types" & vbLf)

        Dim p1 As New Point(10, 10)
        Dim p2 As Point = p1

        ' Print both points.
        p1.Display()
        p2.Display()

        ' Change p1.X and print again. p2.X is not changed.
        p1.X = 100
        Console.WriteLine(vbLf & "=> Changed p1.X" & vbLf)
        p1.Display()
        p2.Display()
    End Sub
#End Region

#Region "Classes and assignment operator"
    Sub ReferenceTypeAssignment()
        Console.WriteLine("Assigning reference types" & vbLf)
        Dim p1 As New PointRef(10, 10)
        Dim p2 As PointRef = p1

        ' Print both point refs.
        p1.Display()
        p2.Display()

        ' Change p1.X and print again.
        p1.X = 100
        Console.WriteLine(vbLf & "=> Changed p1.X" & vbLf)
        p1.Display()
        p2.Display()
    End Sub
#End Region
End Module
