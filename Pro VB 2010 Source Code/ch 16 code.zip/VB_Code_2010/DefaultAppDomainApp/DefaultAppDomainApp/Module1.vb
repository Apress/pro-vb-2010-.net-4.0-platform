﻿Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with the default app domain *****" & vbLf)
        InitDAD()
        DisplayDADStats()
        Console.WriteLine()
        ListAllAssembliesInAppDomain()
        Console.ReadLine()
    End Sub
#Region "Init the default app domain"
    Sub InitDAD()
        'This logic will print out the name of any assembly
        'loaded into the applicaion domain, after it has been created. 
        Dim defaultAD As AppDomain = AppDomain.CurrentDomain
        AddHandler defaultAD.AssemblyLoad, Sub(s, e)
                                               Console.WriteLine("{0} has been loaded!", e.LoadedAssembly.GetName().Name)
                                           End Sub

    End Sub
#End Region
   
#Region "Display basic stats"
    Sub DisplayDADStats()
        'Get access to the app domain for the current thread.
        Dim defaultAD As AppDomain = AppDomain.CurrentDomain

        Console.WriteLine("Name of this domain: {0}", defaultAD.FriendlyName)
        Console.WriteLine("ID of domain in this process: {0}", defaultAD.Id)
        Console.WriteLine("Is this the default domain?: {0}", defaultAD.IsDefaultAppDomain())
        Console.WriteLine("Base directory of this domain: {0}", defaultAD.BaseDirectory)
    End Sub
#End Region

#Region "List loaded assemblies "
    Sub ListAllAssembliesInAppDomain()

        'Get access to the app domain for the current thread.
        Dim defaultAD As AppDomain = AppDomain.CurrentDomain

        'Now get all loaded assemblies in the default app domain. 
        Dim loadedAssemblies = From a In defaultAD.GetAssemblies() _
                               Order By a.GetName().Name _
                               Select a
        Console.WriteLine("***** Here are the assemblies loaded in {0} *****" & vbLf, defaultAD.FriendlyName)

        For Each a In loadedAssemblies
            Console.WriteLine("-> Name: {0}", a.GetName().Name)
            Console.WriteLine("-> Version: {0}" & vbLf, a.GetName().Version)
        Next
    End Sub
#End Region



End Module
