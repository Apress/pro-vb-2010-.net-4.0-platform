﻿'For Context type. 
Imports System.Runtime.Remoting.Contexts
'For Thread type.
Imports System.Threading

#Region "Classes for testing"
'SportsCar has no special contextual
' needs and will be loaded into the
' default context of the app domain.
Public Class SportsCar
    Public Sub New()
        'Get context information and print out context ID.
        Dim ctx As Context = Thread.CurrentContext
        Console.WriteLine("{0} object in context {1}", Me.ToString(), ctx.ContextID)
        For Each itfCtxProp As IContextProperty In ctx.ContextProperties
            Console.WriteLine("-> Ctx Prop: {0}", itfCtxProp.Name)
        Next
    End Sub
End Class
' SportsCarTS demands to be loaded in
' a synchronization context.
<Synchronization()> _
Public Class SportsCarTS
    Inherits ContextBoundObject
    Public Sub New()
        'Get context information and print out context ID.
        Dim ctx As Context = Thread.CurrentContext
        Console.WriteLine("{0} object in context {1}", Me.ToString(), ctx.ContextID)
        For Each itfCtxProp As IContextProperty In ctx.ContextProperties
            Console.WriteLine("-> Ctx Prop: {0}", itfCtxProp.Name)
        Next
    End Sub
End Class
#End Region