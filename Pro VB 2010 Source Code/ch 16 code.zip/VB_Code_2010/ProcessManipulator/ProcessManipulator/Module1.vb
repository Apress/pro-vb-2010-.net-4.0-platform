﻿Module Module1
    Sub Main()
        Console.WriteLine("***** Fun with Processes *****" & vbLf)
        ListAllRunningProcesses()

        'Prompt user for a PID and print out the set of active threads.
        Console.WriteLine("***** Enter PID of process to investigate *****")
        Console.Write("PID: ")

        Dim pID As String = Console.ReadLine()
        Dim theProcID As Integer = Integer.Parse(pID)
        EnumThreadsForPid(theProcID)
        EnumModsForPid(theProcID)
        StartAndKillProcess()
        Console.ReadLine()

    End Sub
#Region "List all running processes"
    Sub ListAllRunningProcesses()
        ' Get all the processes on the local machine, ordered by PID.
        Dim runningProcs = From proc In Process.GetProcesses(".") _
                           Order By proc.Id _
                           Select proc

        'Print out PID and name of each process.
        For Each p In runningProcs
            Dim info As String = String.Format("-> PID: {0}" & vbTab & "Name: {1}", p.Id, p.ProcessName)
            Console.WriteLine(info)
        Next
        Console.WriteLine("************************************" & vbLf)
    End Sub
#End Region
#Region "Get process by PID"
    'If there is no process with the PID of 987, a
    ' runtime exception will be thrown.
    Sub GetSpecificProcess()
        Dim theProc As Process = Nothing
        Try
            theProc = Process.GetProcessById(987)
        Catch ex As ArgumentException
            Console.WriteLine(ex.Message)
        End Try
    End Sub
#End Region

#Region "List threads used by process"
    Sub EnumThreadsForPid(ByVal pID As Integer)
        Dim theProc As Process = Nothing
        Try
            theProc = Process.GetProcessById(pID)
        Catch ex As ArgumentException
            Console.WriteLine(ex.Message)
            Return
        End Try

        'List out stats for each thread in the specified process.
        Console.WriteLine("Here are the threads used by: {0}", theProc.ProcessName)

        Dim theThreads As ProcessThreadCollection = theProc.Threads
        For Each pt As ProcessThread In theThreads
            Dim info As String = String.Format("-> Thread ID: {0}" & vbTab & "Start Time: {1}" & vbTab & "Priority: {2}", pt.Id, pt.StartTime.ToShortTimeString(), pt.PriorityLevel)
            Console.WriteLine(info)
        Next
        Console.WriteLine("************************************" & vbLf)
    End Sub
#End Region

#Region "List mods used by process"
    Sub EnumModsForPid(ByVal pID As Integer)
        Dim theProc As Process = Nothing
        Try
            theProc = Process.GetProcessById(pID)
        Catch ex As ArgumentException
            Console.WriteLine(ex.Message)
            Return
        End Try

        Console.WriteLine("Here are the loaded modules for: {0}", theProc.ProcessName)
        Dim theMods As ProcessModuleCollection = theProc.Modules

        For Each pm As ProcessModule In theMods
            Dim info As String = String.Format("-> Mod Name: {0}", pm.ModuleName)
            Console.WriteLine(info)
        Next
        Console.WriteLine("************************************" & vbLf)
    End Sub
#End Region

#Region "Launch IE and navigate to facebook.com"
    Sub StartAndKillProcess()
        Dim ieProc As Process = Nothing
        Try
            'Launch Internet Explorer, and go to facebook!
            Dim startInfo As New ProcessStartInfo("IExplore.exe", "www.facebook.com")
            startInfo.WindowStyle = ProcessWindowStyle.Maximized
            ieProc = Process.Start(startInfo)
        Catch ex As InvalidOperationException
            Console.WriteLine(ex.Message)
        End Try

        Console.Write("--> Hit enter to kill {0}...", ieProc.ProcessName)
        Console.ReadLine()

        'Kill the iexplore.exe process.
        Try
            ieProc.Kill()
        Catch ex As InvalidOperationException
            Console.WriteLine(ex.Message)
        End Try
    End Sub
#End Region
    
End Module

