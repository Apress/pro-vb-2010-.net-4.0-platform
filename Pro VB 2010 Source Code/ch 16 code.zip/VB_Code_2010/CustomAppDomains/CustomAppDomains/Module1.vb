﻿Imports System.IO

Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Custom App Domains *****" & vbLf)
        'Show all loaded assemblies in default app domain.
        Dim defaultAD As AppDomain = AppDomain.CurrentDomain
        AddHandler defaultAD.ProcessExit, Function(o, s)
                                              Console.WriteLine("Default AD unloaded!")
                                              Return o.ToString()
                                          End Function
        ListAllAssembliesInAppDomain(defaultAD)
        MakeNewAppDomain()
        Console.ReadLine()
    End Sub
#Region "Make new AD"
    Sub MakeNewAppDomain()
        'Make a new AppDomain in the current process.
        Dim newAD As AppDomain = AppDomain.CreateDomain("SecondAppDomain")
        AddHandler newAD.DomainUnload, Sub(o, s)
                                           Console.WriteLine("The second app domain has been unloaded!")
                                       End Sub
        Try
            'Now load CarLibrary.dll into this new domain.
            newAD.Load("CarLibrary")
        Catch ex As FileNotFoundException
            Console.WriteLine(ex.Message)
        End Try

        'List all assemblies. 
        ListAllAssembliesInAppDomain(newAD)

        'Now tear down this app domain.
        AppDomain.Unload(newAD)
    End Sub
#End Region

#Region "List all asms in AD method"
    Sub ListAllAssembliesInAppDomain(ByVal ad As AppDomain)

        ' Now get all loaded assemblies in the default app domain. 
        Dim loadedAssemblies = From a In ad.GetAssemblies() _
                               Order By a.GetName().Name _
                               Select a

        Console.WriteLine("***** Here are the assemblies loaded in {0} *****" & vbLf, ad.FriendlyName)
        For Each a In loadedAssemblies
            Console.WriteLine("-> Name: {0}", a.GetName().Name)
            Console.WriteLine("-> Version: {0}" & vbLf, a.GetName().Version)
        Next
    End Sub
#End Region

End Module
