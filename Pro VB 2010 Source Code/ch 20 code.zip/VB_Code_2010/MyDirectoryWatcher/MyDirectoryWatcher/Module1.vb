﻿Imports System.IO

Module Module1

    Sub Main()
        Console.WriteLine("***** The Amazing File Watcher App *****" & vbLf)

        ' Establish the path to the directory to watch.
        Dim watcher As New FileSystemWatcher()
        Try
            watcher.Path = "C:\MyFolder"
        Catch ex As ArgumentException
            Console.WriteLine(ex.Message)
            Return
        End Try

        ' Set up the things to be on the lookout for.
        watcher.NotifyFilter = NotifyFilters.LastAccess Or _
                               NotifyFilters.LastWrite Or _
                               NotifyFilters.FileName Or _
                               NotifyFilters.DirectoryName

        ' Only watch text files.
        watcher.Filter = "*.txt"

        ' Add event handlers.
        AddHandler watcher.Changed, AddressOf OnChanged
        AddHandler watcher.Created, AddressOf OnChanged
        AddHandler watcher.Deleted, AddressOf OnChanged
        AddHandler watcher.Renamed, AddressOf OnRenamed

        ' Begin watching the directory.
        watcher.EnableRaisingEvents = True

        ' Wait for the user to quit the program.
        Console.WriteLine("Press 'q' to quit app.")
        While Console.ReadLine() <> "q"
        End While

    End Sub
    Sub OnChanged(ByVal source As Object, ByVal e As FileSystemEventArgs)
        ' Specify what is done when a file is changed, created, or deleted.
        Console.WriteLine("File: {0} {1}!", e.FullPath, e.ChangeType)
    End Sub
    Sub OnRenamed(ByVal source As Object, ByVal e As RenamedEventArgs)
        ' Specify what is done when a file is renamed.
        Console.WriteLine("File: {0} renamed to" & vbLf & "{1}", e.OldFullPath, e.FullPath)
    End Sub


End Module
