﻿Imports System.IO

Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with StreamWriter / StreamReader *****" & vbLf)

        ' Get a StreamWriter and write string data.
        Using writer As StreamWriter = File.CreateText("reminders.txt")
            writer.WriteLine("Don't forget Mother's Day this year...")
            writer.WriteLine("Don't forget Father's Day this year...")
            writer.WriteLine("Don't forget these numbers:")
            For i As Integer = 0 To 9
                writer.Write(i & " ")
            Next i

            ' Insert a new line.
            writer.Write(writer.NewLine)
        End Using

        Console.WriteLine("Created file and wrote some thoughts..." & vbLf)

        ' Now read data from file.
        Console.WriteLine("Here are your thoughts:" & vbLf)
        Using sr As StreamReader = File.OpenText("reminders.txt")
            Dim input As String = Nothing
            input = sr.ReadLine()
            Do While input IsNot Nothing
                Console.WriteLine(input)
                input = sr.ReadLine()
            Loop
        End Using

        Console.ReadLine()

    End Sub

End Module
