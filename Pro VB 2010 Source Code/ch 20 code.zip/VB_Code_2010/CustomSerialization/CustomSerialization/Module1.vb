﻿Imports System.Runtime.Serialization
Imports System.IO
Imports System.Runtime.Serialization.Formatters.Soap

Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Custom Serialization *****")

        ' Recall that this type implements ISerializable.
        Dim myData As New StringData()

        ' Save to a local file in SOAP format.
        Dim soapFormat As New SoapFormatter()
        Using fStream As Stream = New FileStream("MyData.soap", FileMode.Create, FileAccess.Write, FileShare.None)
            soapFormat.Serialize(fStream, myData)
        End Using
        Console.WriteLine("All done!  Check bin\debug for output")
        Console.ReadLine()

    End Sub

End Module

#Region "sample test data."
<Serializable()>
Public Class StringData
    Implements ISerializable
    Private dataItemOne As String = "First data block"
    Private dataItemTwo As String = "More data"

    Public Sub New()
    End Sub
    Protected Sub New(ByVal si As SerializationInfo, ByVal ctx As StreamingContext)
        ' Rehydrate member variables from stream.
        dataItemOne = si.GetString("First_Item").ToLower()
        dataItemTwo = si.GetString("dataItemTwo").ToLower()
    End Sub

    Private Sub GetObjectData(ByVal info As SerializationInfo, ByVal ctx As StreamingContext) Implements ISerializable.GetObjectData
        ' Fill up the SerializationInfo object with the formatted data.
        info.AddValue("First_Item", dataItemOne.ToUpper())
        info.AddValue("dataItemTwo", dataItemTwo.ToUpper())
    End Sub
End Class

<Serializable()>
Public Class MoreData
    Public dataItemOne As String = "First data block"
    Public dataItemTwo As String = "More data"

    <OnSerializing()>
    Private Sub OnSerializing(ByVal context As StreamingContext)
        ' Called during the serialization process.
        dataItemOne = dataItemOne.ToUpper()
        dataItemTwo = dataItemTwo.ToUpper()
    End Sub

    <OnDeserialized()>
    Private Sub OnDeserialized(ByVal context As StreamingContext)
        ' Called once the deserialization process is complete.
        dataItemOne = dataItemOne.ToLower()
        dataItemTwo = dataItemTwo.ToLower()
    End Sub
End Class

#End Region

