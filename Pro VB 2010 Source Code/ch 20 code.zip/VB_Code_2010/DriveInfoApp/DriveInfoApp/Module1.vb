﻿Imports System.IO

Module Module1
    Sub Main()
        Console.WriteLine("***** Fun with DriveInfo *****" & vbLf)
        'Get info regarding all drives.
        Dim myDrives As DriveInfo() = DriveInfo.GetDrives()
        'Now print drive stats.
        For Each d As DriveInfo In myDrives
            Console.WriteLine("Name: {0}", d.Name)
            Console.WriteLine("Type: {0}", d.DriveType)
            'Check to see whether the drive is mounted.
            If d.IsReady Then
                Console.WriteLine("Free space: {0}", d.TotalFreeSpace)
                Console.WriteLine("Format: {0}", d.DriveFormat)
                Console.WriteLine("Label: {0}", d.VolumeLabel)
                Console.WriteLine()
            End If
        Next
        Console.ReadLine()
    End Sub
End Module
