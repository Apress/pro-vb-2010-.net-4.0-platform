﻿Imports System.IO

Module Module1
    Sub Main()

        Console.WriteLine("***** Fun with StringWriter / StringReader *****" & vbLf)

        ' Create a StringWriter and emit character data to memory.
        Using strWriter As New StringWriter()
            strWriter.WriteLine("Don't forget Mother's Day this year...")
            Console.WriteLine("Contents of StringWriter:" & vbLf & "{0}", strWriter)

            ' Read data from the StringWriter.
            Using strReader As New StringReader(strWriter.ToString())
                Dim input As String = Nothing
                input = strReader.ReadLine()
                Do While input IsNot Nothing
                    Console.WriteLine(input)
                    input = strReader.ReadLine()
                Loop
            End Using
        End Using
        Console.ReadLine()

    End Sub

End Module
