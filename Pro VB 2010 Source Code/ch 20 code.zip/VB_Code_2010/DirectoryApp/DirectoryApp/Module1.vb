﻿Imports System.IO
Module Module1
    Sub Main()
        Console.WriteLine("***** Fun with Directory(Info) *****" & vbLf)
        ShowWindowsDirectoryInfo()
        DisplayImageFiles()
        ModifyAppDirectory()
        FunWithDirectoryType()
        Console.ReadLine()
    End Sub

#Region "Show directory info"
    Sub ShowWindowsDirectoryInfo()
        'Dump directory information.
        Dim dir As New DirectoryInfo("C:\Windows")
        Console.WriteLine("***** Directory Info *****")
        Console.WriteLine("FullName: {0}", dir.FullName)
        Console.WriteLine("Name: {0}", dir.Name)
        Console.WriteLine("Parent: {0}", dir.Parent)
        Console.WriteLine("Creation: {0}", dir.CreationTime)
        Console.WriteLine("Attributes: {0}", dir.Attributes)
        Console.WriteLine("Root: {0}", dir.Root)
        Console.WriteLine("**************************" & vbLf)
    End Sub
#End Region

#Region "Display image files. "
    Sub DisplayImageFiles()
        Dim dir As New DirectoryInfo("C:\Windows\Web\Wallpaper\")
        'Get all files with a *.jpg extension.
        Dim imageFiles As FileInfo() = dir.GetFiles("*.jpg", SearchOption.AllDirectories)
        'How many were found?
        Console.WriteLine("Found {0} *.jpg files" & vbLf, imageFiles.Length)
        'Now print out info for each file.
        For Each f As FileInfo In imageFiles
            Console.WriteLine("***************************")
            Console.WriteLine("File name: {0}", f.Name)
            Console.WriteLine("File size: {0}", f.Length)
            Console.WriteLine("Creation: {0}", f.CreationTime)
            Console.WriteLine("Attributes: {0}", f.Attributes)
            Console.WriteLine("***************************" & vbLf)
        Next
    End Sub
#End Region

#Region "Make directories"
    Sub ModifyAppDirectory()
        Dim dir As New DirectoryInfo("c:\")
        'Create \MyFolder off initial directory.
        dir.CreateSubdirectory("MyFolder")
        'Capture returned DirectoryInfo object.
        Dim myDataFolder As DirectoryInfo = dir.CreateSubdirectory("MyFolder2\Data")
        'Prints path to ..\MyFolder2\Data.
        Console.WriteLine("New Folder is: {0}", myDataFolder)
    End Sub
#End Region

#Region "Use Directory to destroy directories."
    Sub FunWithDirectoryType()
        'List all drives on current computer.
        Dim drives As String() = Directory.GetLogicalDrives()
        Console.WriteLine("Here are your drives:")
        For Each s As String In drives
            Console.WriteLine("--> {0} ", s)
        Next
        'Delete what was created.
        Console.WriteLine("Press Enter to delete directories")
        Console.ReadLine()
        Try
            Directory.Delete("C:\MyFolder")
            'The second parameter specifies whether you
            'wish to destroy any subdirectories.
            Directory.Delete("C:\MyFolder2", True)
        Catch e As IOException
            Console.WriteLine(e.Message)
        End Try
    End Sub
#End Region
End Module
