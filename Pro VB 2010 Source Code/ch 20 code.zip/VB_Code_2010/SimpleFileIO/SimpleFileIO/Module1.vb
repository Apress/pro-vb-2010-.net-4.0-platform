﻿Imports System.IO

Module Module1
    Sub Main()
        Console.WriteLine("***** Simple IO with the File Type *****" & vbLf)
        Dim myTasks As String() = {"Fix bathroom sink", "Call Dave", "Call Mom and Dad", "Play Xbox 360"}
        'Write out all data to file on C drive.
        File.WriteAllLines("C:\tasks.txt", myTasks)
        ' Read it all back and print out.
        For Each task As String In File.ReadAllLines("C:\tasks.txt")
            Console.WriteLine("TODO: {0}", task)
        Next
        Console.ReadLine()
    End Sub
End Module


