﻿Imports System.Runtime.Serialization.Formatters.Binary
Imports System.Runtime.Serialization.Formatters.Soap
Imports System.Xml.Serialization
Imports System.IO

Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Object Serialization *****" & vbLf)

        ' Make a JamesBondCar and set state.
        Dim jbc As New JamesBondCar()
        jbc.canFly = True
        jbc.canSubmerge = False
        jbc.theRadio.stationPresets = New Double() {89.3, 105.1, 97.1}
        jbc.theRadio.hasTweeters = True

        ' Now save the car to a specific file in a binary format.
        SaveAsBinaryFormat(jbc, "CarData.dat")
        LoadFromBinaryFile("CarData.dat")
        SaveAsSoapFormat(jbc, "CarData.soap")
        SaveAsXmlFormat(jbc, "CarData.xml")
        SaveListOfCars()
        SaveListOfCarsAsBinary()
        Console.WriteLine("All done!")

        Console.ReadLine()

    End Sub
#Region "Save as binary"
    Sub SaveAsBinaryFormat(ByVal objGraph As Object, ByVal fileName As String)
        ' Save object to a file named CarData.dat in binary.
        Dim binFormat As New BinaryFormatter()

        Using fStream As Stream = New FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None)
            binFormat.Serialize(fStream, objGraph)
        End Using
        Console.WriteLine("=> Saved car in binary format!")
    End Sub
#End Region

#Region "Load from binary"
    Sub LoadFromBinaryFile(ByVal fileName As String)
        Dim binFormat As New BinaryFormatter()

        ' Read the JamesBondCar from the binary file.
        Using fStream As Stream = File.OpenRead(fileName)
            Dim carFromDisk As JamesBondCar = CType(binFormat.Deserialize(fStream), JamesBondCar)
            Console.WriteLine("Can this car fly? : {0}", carFromDisk.canFly)
        End Using
    End Sub
#End Region

#Region "Save as SOAP"
    Sub SaveAsSoapFormat(ByVal objGraph As Object, ByVal fileName As String)
        ' Save object to a file named CarData.soap in SOAP format.
        Dim soapFormat As New SoapFormatter()

        Using fStream As Stream = New FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None)
            soapFormat.Serialize(fStream, objGraph)
        End Using
        Console.WriteLine("=> Saved car in SOAP format!")
    End Sub
#End Region

#Region "Save as XML"
    Sub SaveAsXmlFormat(ByVal objGraph As Object, ByVal fileName As String)
        ' Save object to a file named CarData.xml in XML format.
        Dim xmlFormat As New XmlSerializer(GetType(JamesBondCar))

        Using fStream As Stream = New FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None)
            xmlFormat.Serialize(fStream, objGraph)
        End Using
        Console.WriteLine("=> Saved car in XML format!")
    End Sub
#End Region

#Region "Save list of objects as XML"
    Sub SaveListOfCars()
        ' Now persist a List(Of T) of JamesBondCars.
        Dim myCars As New List(Of JamesBondCar)()
        myCars.Add(New JamesBondCar(True, True))
        myCars.Add(New JamesBondCar(True, False))
        myCars.Add(New JamesBondCar(False, True))
        myCars.Add(New JamesBondCar(False, False))

        Using fStream As Stream = New FileStream("CarCollection.xml", FileMode.Create, FileAccess.Write, FileShare.None)
            Dim xmlFormat As New XmlSerializer(GetType(List(Of JamesBondCar)), New Type() {GetType(JamesBondCar), GetType(Car), GetType(Radio)})
            xmlFormat.Serialize(fStream, myCars)
        End Using
        Console.WriteLine("=> Saved list of cars!")
    End Sub
#End Region

#Region "Save list of objects in binary"
    Sub SaveListOfCarsAsBinary()
        ' Save ArrayList object (myCars) as binary.
        Dim myCars As New List(Of JamesBondCar)()

        Dim binFormat As New BinaryFormatter()
        Using fStream As Stream = New FileStream("AllMyCars.dat", FileMode.Create, FileAccess.Write, FileShare.None)
            binFormat.Serialize(fStream, myCars)
        End Using
        Console.WriteLine("=> Saved list of cars in binary!")
    End Sub
#End Region
End Module

#Region "Serializable data"
<Serializable()>
Public Class Radio
    Public hasTweeters As Boolean
    Public hasSubWoofers As Boolean
    Public stationPresets() As Double

    <NonSerialized()>
    Dim radioID As String = "XF-552RR6"
End Class

<Serializable()>
Public Class Car
    Public theRadio As New Radio()
    Public isHatchBack As Boolean
End Class

<Serializable(), XmlRoot(Namespace:="http://www.MyCompany.com")>
Public Class JamesBondCar
    Inherits Car
    Public canFly As Boolean
    Public canSubmerge As Boolean

    Public Sub New(ByVal skyWorthy As Boolean, ByVal seaWorthy As Boolean)
        canFly = skyWorthy
        canSubmerge = seaWorthy
    End Sub
    ' The XmlSerializer demands a default constructor!
    Public Sub New()
    End Sub

End Class
#End Region

