﻿Imports System.IO
Imports System.Text

Module Module1
    'Don't forget to import the System.Text and System.IO namespaces.
    Sub Main()
        Console.WriteLine("***** Fun with FileStreams *****" & vbLf)
        'Obtain a FileStream object.
        Using fStream As FileStream = File.Open("C:\myMessage.dat", FileMode.Create)
            'Encode a string as an array of Bytes.
            Dim msg As String = "Hello!"
            Dim msgAsByteArray As Byte() = Encoding.Default.GetBytes(msg)

            'Write Byte array to file.
            fStream.Write(msgAsByteArray, 0, msgAsByteArray.Length)

            'Reset internal position of stream.
            fStream.Position = 0

            'Read the types from file and display to console.
            Console.Write("Your message as an array of Bytes: ")
            Dim bytesFromFile As Byte() = New Byte(msgAsByteArray.Length) {}

            For i = 0 To msgAsByteArray.Length - 1
                bytesFromFile(i) = CByte(fStream.ReadByte())
                Console.Write(bytesFromFile(i))

            Next

            'Display decoded messages.
            Console.Write(vbLf & "Decoded Message: ")
            Console.WriteLine(Encoding.Default.GetString(bytesFromFile))
        End Using
        Console.ReadLine()
    End Sub

End Module
