﻿Imports System.Threading
Imports System.Windows.Forms

Module Module1

    Sub Main()
        Console.WriteLine("***** The Amazing Thread App *****" & vbLf)
        Console.Write("Do you want [1] or [2] threads? ")
        Dim threadCount As String = Console.ReadLine()

        ' Name the current thread.
        Dim primaryThread As Thread = Thread.CurrentThread
        primaryThread.Name = "Primary"

        ' Display Thread info.
        Console.WriteLine("-> {0} is executing Main()", Thread.CurrentThread.Name)

        ' Make worker class.
        Dim p As New Printer()

        Select Case threadCount
            Case "2"
                ' Now make the thread.
                Dim backgroundThread As New Thread(New ThreadStart(AddressOf p.PrintNumbers))
                backgroundThread.Name = "Secondary"
                backgroundThread.Start()
            Case "1"
CaseLabel1:
                p.PrintNumbers()
            Case Else
                Console.WriteLine("I don't know what you want...you get 1 thread.")
                GoTo CaseLabel1
        End Select

        ' Do some additional work.
        MessageBox.Show("I'm busy!", "Work on main thread...")
        Console.ReadLine()
    End Sub
End Module

#Region "The Printer class"
Public Class Printer
    Public Sub PrintNumbers()
        ' Display Thread info.
        Console.WriteLine("-> {0} is executing PrintNumbers()", Thread.CurrentThread.Name)

        ' Print out numbers.
        Console.Write("Your numbers: ")
        For i = 0 To 9
            Console.Write("{0}, ", i)
            Thread.Sleep(2000)
        Next
        Console.WriteLine()
    End Sub
End Class
#End Region

