﻿Imports System.Threading
Imports System.Threading.Tasks

Public Class MainForm
    Dim cancelToken As New CancellationTokenSource()
    Private Sub btnExecute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecute.Click
        ' Start a new "task" to process the files. 
        Task.Factory.StartNew(Sub() ProcessIntData())

    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        cancelToken.Cancel()
    End Sub

    Private Sub ProcessIntData()
        ' Get a very large array of Integers. 
        Dim source() As Integer = Enumerable.Range(1, 10000000).ToArray()

        ' Find the numbers where num Mod 3 = 0 is True, returned
        ' in descending order. 
        Dim modThreeIsZero() As Integer = Nothing
        Try
            modThreeIsZero = (
                From num In source.AsParallel().WithCancellation(cancelToken.Token)
                Where num Mod 3 = 0
                Order By num Descending
                Select num).ToArray()
        Catch ex As OperationCanceledException
            Me.Text = ex.Message
        End Try
        MessageBox.Show(String.Format("Found {0} numbers that match query!", modThreeIsZero.Count()))
    End Sub
End Class
