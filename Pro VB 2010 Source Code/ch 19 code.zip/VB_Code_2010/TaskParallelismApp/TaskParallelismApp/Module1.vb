﻿Imports System.Net
Imports System.Text
Imports System.Threading.Tasks

Module Module1

    Sub Main()
        ' Retrieve Darwin's "Origin of the Species" from Gutenberg.org.
        Dim words() As String = CreateWordArray("http://www.gutenberg.org/files/2009/2009.txt")
        System.IO.File.WriteAllLines("DarwinBook.txt", words)


        ' Perform three tasks in parallel on the source array
        Parallel.Invoke(Sub()
                            Console.WriteLine("Begin first task...")
                            GetLongestWord(words)
                        End Sub, Sub()
                                     Console.WriteLine("Begin second task...")
                                     GetMostCommonWords(words)
                                 End Sub, Sub()
                                              Console.WriteLine("Begin third task...")
                                              GetCountForWord(words, "species")
                                          End Sub)

        Console.WriteLine("Returned from Parallel.Invoke")
     
        Console.WriteLine("Press any key to exit")
        Console.ReadKey()

    End Sub

#Region "HelperMethods"
    Private Sub GetCountForWord(ByVal words() As String, ByVal term As String)
        Dim findWord = From word In words
                       Where word.ToUpper().Contains(term.ToUpper())
                       Select word

        Console.WriteLine("Task 3 -- The word ""{0}"" occurs {1} times.", term, findWord.Count())
    End Sub

    Private Sub GetMostCommonWords(ByVal words() As String)
        Dim frequencyOrder = From word In words
                             Where word.Length > 6
                             Group word By word Into g = Group
                             Order By g.Count() Descending
                             Select word

        Dim commonWords = frequencyOrder.Take(10)

        Dim sb As New StringBuilder()
        sb.AppendLine("Task 2 -- The most common words are:")
        For Each v In commonWords
            sb.AppendLine("  " & v)
        Next v
        Console.WriteLine(sb.ToString())
    End Sub

    Private Function GetLongestWord(ByVal words() As String) As String
        Dim longestWord = (
            From w In words
            Order By w.Length Descending
            Select w).First()

        Console.WriteLine("Task 1 -- The longest word is {0}", longestWord)
        Return longestWord
    End Function


    ' An http request performed synchronously for simplicity.
    Function CreateWordArray(ByVal uri As String) As String()
        Console.WriteLine("Retrieving from {0}", uri)

        ' Download a web page the easy way.
        Dim s As String = New WebClient().DownloadString(uri)
        System.IO.File.WriteAllText("Book.txt", s)

        ' Separate string into an array of words, removing some common punctuation.
        Return s.Split(New Char() {" "c, ControlChars.Lf, ","c, "."c, ";"c, ":"c, "-"c, "_"c, "/"c}, StringSplitOptions.RemoveEmptyEntries)
    End Function
#End Region
End Module
