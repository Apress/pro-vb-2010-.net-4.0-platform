﻿Imports System.Threading

Module Module1
    Sub Main()
        Console.WriteLine("***** Fun with the CLR Thread Pool *****" & vbLf)

        Console.WriteLine("Main thread started. ThreadID = {0}", Thread.CurrentThread.ManagedThreadId)

        Dim p As New Printer()

        Dim workItem As New WaitCallback(AddressOf PrintTheNumbers)

        ' Queue the method 10 times
        For i = 0 To 9
            ThreadPool.QueueUserWorkItem(workItem, p)
        Next

        Console.WriteLine("All tasks queued")
        Console.ReadLine()

    End Sub
    Private Sub PrintTheNumbers(ByVal state As Object)
        Dim task As Printer = CType(state, Printer)
        task.PrintNumbers()
    End Sub

End Module

#Region "Helper class"
Public Class Printer
    Private lockToken As New Object()

    Public Sub PrintNumbers()
        SyncLock lockToken
            ' Display Thread info.
            Console.WriteLine("-> {0} is executing PrintNumbers()", Thread.CurrentThread.Name)

            ' Print out numbers.
            Console.Write("Your numbers: ")
            For i = 0 To 9
                Console.Write("{0}, ", i)
                Thread.Sleep(1000)
            Next
            Console.WriteLine()
        End SyncLock
    End Sub
End Class
#End Region



