﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtBook = New System.Windows.Forms.TextBox()
        Me.btnDownload = New System.Windows.Forms.Button()
        Me.btnGetStats = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtBook
        '
        Me.txtBook.Location = New System.Drawing.Point(3, 12)
        Me.txtBook.Multiline = True
        Me.txtBook.Name = "txtBook"
        Me.txtBook.Size = New System.Drawing.Size(585, 282)
        Me.txtBook.TabIndex = 0
        '
        'btnDownload
        '
        Me.btnDownload.Location = New System.Drawing.Point(383, 311)
        Me.btnDownload.Name = "btnDownload"
        Me.btnDownload.Size = New System.Drawing.Size(75, 23)
        Me.btnDownload.TabIndex = 1
        Me.btnDownload.Text = "Download"
        Me.btnDownload.UseVisualStyleBackColor = True
        '
        'btnGetStats
        '
        Me.btnGetStats.Location = New System.Drawing.Point(479, 311)
        Me.btnGetStats.Name = "btnGetStats"
        Me.btnGetStats.Size = New System.Drawing.Size(90, 23)
        Me.btnGetStats.TabIndex = 2
        Me.btnGetStats.Text = "Get Book Stats"
        Me.btnGetStats.UseVisualStyleBackColor = True
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(596, 355)
        Me.Controls.Add(Me.btnGetStats)
        Me.Controls.Add(Me.btnDownload)
        Me.Controls.Add(Me.txtBook)
        Me.Name = "MainForm"
        Me.Text = "My EBook Reader"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtBook As System.Windows.Forms.TextBox
    Friend WithEvents btnDownload As System.Windows.Forms.Button
    Friend WithEvents btnGetStats As System.Windows.Forms.Button

End Class
