﻿Imports System.Net
Imports System.Text
Imports System.Threading.Tasks
Imports System.Windows.Forms

Public Class MainForm
    Dim theEBook As String = ""
    Private Sub btnDownload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDownload.Click
        ' The Project Gutenberg EBook of A Tale of Two Cities, by Charles Dickens
        Dim wc As New WebClient()
        AddHandler wc.DownloadStringCompleted, Sub(s, eArgs)
                                                   theEBook = eArgs.Result
                                                   txtBook.Text = theEBook
                                               End Sub
        wc.DownloadStringAsync(New Uri("http://www.gutenberg.org/files/98/98-8.txt"))
    End Sub

    Private Sub btnGetStats_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetStats.Click
        ' Get the words from the e-book.
        Dim words() As String = theEBook.Split(New Char() {" "c, ControlChars.Lf, ","c, "."c, ";"c, ":"c, "-"c, "?"c, "/"c}, StringSplitOptions.RemoveEmptyEntries)
        Dim tenMostCommon() As String = Nothing
        Dim longestWord As String = String.Empty

        ' Now, find the ten most common words.
        'Get the longest word. 
        Parallel.Invoke(
            Sub() tenMostCommon = FindTenMostCommon(words),
            Sub() longestWord = FindLongestWord(words)
                       )

    ' Now that all tasks are complete, build a string to show all
    ' stats in a message box.
    Dim bookStats As New StringBuilder("Ten Most Common Words are:" & vbLf)
		For Each s As String In tenMostCommon
			bookStats.AppendLine(s)
		Next
		bookStats.AppendFormat("Longest word is: {0}", longestWord)
		bookStats.AppendLine()
		MessageBox.Show(bookStats.ToString(), "Book info")
    End Sub

#Region "Task methods."
    Private Function FindTenMostCommon(ByVal words() As String) As String()
        Dim frequencyOrder = From word In words
                             Where word.Length > 6
                             Group word By word Into g = Group
                             Order By g.Count() Descending
                             Select word

        Dim commonWords() As String = (frequencyOrder.Take(10)).ToArray()
        Return commonWords
    End Function

    Private Function FindLongestWord(ByVal words() As String) As String
        Return (
            From w In words
            Order By w.Length Descending
            Select w).First()
    End Function
#End Region

End Class
