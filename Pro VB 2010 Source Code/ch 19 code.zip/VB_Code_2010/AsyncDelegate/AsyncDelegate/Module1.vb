﻿Imports System.Threading
Public Delegate Function BinaryOp(ByVal x As Integer, ByVal y As Integer) As Integer

Module Module1
    Sub main()

        Console.WriteLine("***** Async Delegate Invocation *****")

        ' Print out the ID of the executing thread.
        Console.WriteLine("Main() invoked on thread {0}.", Thread.CurrentThread.ManagedThreadId)

        Dim b As New BinaryOp(AddressOf Add)
        Dim iftAR As IAsyncResult = b.BeginInvoke(10, 10, Nothing, Nothing)

        ' This message will keep printing until
        ' the Add() method is finished.
        Do While Not iftAR.IsCompleted
            Console.WriteLine("Doing more work in Main()!")
            Thread.Sleep(1000)
        Loop

        ' Now we know the Add() method is complete.
        Dim answer As Integer = b.EndInvoke(iftAR)

        Console.WriteLine("10 + 10 is {0}.", answer)
        Console.ReadLine()
    End Sub

    Private Function Add(ByVal x As Integer, ByVal y As Integer) As Integer
        ' Print out the ID of the executing thread.
        Console.WriteLine("Add() invoked on thread {0}.", Thread.CurrentThread.ManagedThreadId)

        ' Pause to simulate a lengthy operation.
        Thread.Sleep(5000)
        Return x + y
    End Function
End Module



