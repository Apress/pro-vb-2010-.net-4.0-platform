﻿Imports System.Threading
Imports System.Threading.Tasks
Imports System.IO

Public Class MainForm
    Dim cancelToken As New CancellationTokenSource()

    Private Sub btnCancelTask_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelTask.Click
        'This will be used to tell all the worker threads to stop!
        cancelToken.Cancel()
    End Sub

    Private Sub btnProcessImages_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProcessImages.Click
        ' Start a new "task" to process the files. 
        Task.Factory.StartNew(Sub() ProcessFiles())

    End Sub

    Private Sub ProcessFiles()
        ' Use ParallelOptions instance to store the CancellationToken
        Dim parOpts As New ParallelOptions()
        parOpts.CancellationToken = cancelToken.Token
        parOpts.MaxDegreeOfParallelism = System.Environment.ProcessorCount

        ' Load up all *.jpg files, and make a new folder for the modified data.
        Dim files() As String = Directory.GetFiles("C:\Users\Public\Pictures\Sample Pictures", "*.jpg", SearchOption.AllDirectories)
        Dim newDir As String = "C:\ModifiedPictures"
        Directory.CreateDirectory(newDir)

        Try
            '  Process the image data in a parallel manner! 
            Parallel.ForEach(files, parOpts, Sub(currentFile)
                                                 parOpts.CancellationToken.ThrowIfCancellationRequested()
                                                 Dim filename As String = Path.GetFileName(currentFile)
                                                 Using bmp As New Bitmap(currentFile)
                                                     bmp.RotateFlip(RotateFlipType.Rotate180FlipNone)
                                                     bmp.Save(Path.Combine(newDir, filename))
                                                     Me.Text = String.Format("Processing {0} on thread {1}", filename, Thread.CurrentThread.ManagedThreadId)
                                                 End Using
                                             End Sub)
            Me.Text = "All done!"
        Catch ex As OperationCanceledException
            Me.Text = ex.Message
        End Try
    End Sub
End Class
