﻿Imports System.Threading

Module Module1

    Sub Main()
        Console.WriteLine("*****Synchronizing Threads *****" & vbLf)

        Dim p As New Printer()

        ' Make 10 threads that are all pointing to the same
        ' method on the same object.
        Dim threads(9) As Thread
        For i = 0 To 9
            threads(i) = New Thread(New ThreadStart(AddressOf p.PrintNumbers))
            threads(i).Name = String.Format("Worker thread #{0}", i)
        Next

        ' Now start each one.
        For Each t In threads
            t.Start()
        Next
        Console.ReadLine()

    End Sub

#Region "Printer helper class"
    Public Class Printer
        ' Lock token.
        Private threadLock As New Object()

        Public Sub PrintNumbers()
            SyncLock threadLock
                ' Display Thread info.
                Console.WriteLine("-> {0} is executing PrintNumbers()", Thread.CurrentThread.Name)

                ' Print out numbers.
                Console.Write("Your numbers: ")
                For i = 0 To 9
                    Dim r As New Random()
                    Thread.Sleep(100 * r.Next(5))
                    Console.Write("{0}, ", i)
                Next
                Console.WriteLine()
            End SyncLock
        End Sub
    End Class
#End Region


End Module
