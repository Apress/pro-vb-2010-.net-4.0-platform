﻿Imports System.Threading
Imports System.Runtime.Remoting.Messaging

Public Delegate Function BinaryOp(ByVal x As Integer, ByVal y As Integer) As Integer

Module Module1
    Private isDone As Boolean = False

    Sub Main()
        Console.WriteLine("*****  AsyncCallbackDelegate Example *****")
        Console.WriteLine("Main() invoked on thread {0}.", Thread.CurrentThread.ManagedThreadId)

        Dim b As New BinaryOp(AddressOf Add)
        Dim iftAR As IAsyncResult = b.BeginInvoke(10, 10, New AsyncCallback(AddressOf AddComplete), "Main() thanks you for adding these numbers.")

        ' Assume other work is performed here...
        Do While Not isDone
            Thread.Sleep(1000)
            Console.WriteLine("Working....")
        Loop

        Console.ReadLine()

    End Sub
#Region "Target for AsyncCallback delegate"
    ' Don't forget to add an Imports directive for 
    ' System.Runtime.Remoting.Messaging!
    Private Sub AddComplete(ByVal itfAR As IAsyncResult)
        Console.WriteLine("AddComplete() invoked on thread {0}.", Thread.CurrentThread.ManagedThreadId)
        Console.WriteLine("Your addition is complete")

        ' Now get the result.
        Dim ar As AsyncResult = CType(itfAR, AsyncResult)
        Dim b As BinaryOp = CType(ar.AsyncDelegate, BinaryOp)
        Console.WriteLine("10 + 10 is {0}.", b.EndInvoke(itfAR))

        ' Retrieve the informational object and cast it to string.
        Dim msg As String = CStr(itfAR.AsyncState)
        Console.WriteLine(msg)

        isDone = True
    End Sub

#End Region

#Region "Target for BinaryOp delegate"
    Private Function Add(ByVal x As Integer, ByVal y As Integer) As Integer
        Console.WriteLine("Add() invoked on thread {0}.", Thread.CurrentThread.ManagedThreadId)
        Thread.Sleep(5000)
        Return x + y
    End Function
#End Region

End Module

