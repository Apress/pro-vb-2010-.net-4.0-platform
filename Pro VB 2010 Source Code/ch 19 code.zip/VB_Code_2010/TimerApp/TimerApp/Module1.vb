﻿
Imports System.Threading

Module Module1

    Sub Main()
        Console.WriteLine("***** Working with Timer type *****" & vbLf)

        ' Create the delegate for the Timer type.
        Dim timeCB As New TimerCallback(AddressOf PrintTime)

        ' Establish timer settings,with these parameters.
        ' timeCB - The TimerCallBack delegate object.
        ' Nothing- Any info to pass into the called methos(Nothing for no info).
        ' 0      – Amount of the time to wait before starting (in millisec). 
        ' 1000   - Interval of time between calls (in millisecs).
        Dim t As New Timer(timeCB, Nothing, 0, 1000)

        Console.WriteLine("Hit key to terminate...")
        Console.ReadLine()
    End Sub

    Private Sub PrintTime(ByVal state As Object)
        Console.WriteLine("Time is: {0}", Date.Now.ToLongTimeString())
    End Sub
End Module
