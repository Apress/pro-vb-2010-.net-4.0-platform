﻿Module Module1

    Sub Main()
        Console.WriteLine("***** Issues with Non-Generic Collections *****" & vbLf)
        UsePersonCollection()
        Console.WriteLine()
        UseGenericList()
        Console.ReadLine()
    End Sub
#Region "Simple Box / Unbox"
    Sub SimpleBoxUnboxOperation()
        'Make a Integer value type.
        Dim myInt As Integer = 25

        'Box the Integer into an object reference.
        Dim boxedInt As Object = myInt

        ' Unbox in the wrong data type to trigger
        'runtime exception. 
        'Try
        Dim unboxedInt As Long = DirectCast(boxedInt, Long)
        'Catch ex As InvalidCastException
        'Console.WriteLine(ex.Message)
        'End Try
    End Sub
#End Region

#Region "ArrayList box / unbox"
    Sub WorkWithArrayList()
        ' Value types are automatically boxed when
        ' passed to a member requesting an object.
        Dim myInts As New ArrayList()
        myInts.Add(10)
        myInts.Add(20)
        myInts.Add(35)
        Console.ReadLine()
    End Sub
#End Region

#Region "ArrayList of random objects"
    Sub ArrayListOfRandomObjects()
        'The ArrayList can hold anything at all.
        Dim allMyObjects As New ArrayList()
        allMyObjects.Add(True)
        Dim osVer As New OperatingSystem(PlatformID.MacOSX, New Version(10, 0))
        allMyObjects.Add(osVer)
        allMyObjects.Add(66)
        allMyObjects.Add(3.14)
    End Sub
#End Region

#Region "Use custom generic class"
    Sub UsePersonCollection()
        Console.WriteLine("***** Custom Person Collection *****" & vbLf)
        Dim myPeople As New PersonCollection()
        myPeople.AddPerson(New Person("Homer", "Simpson", 40))
        myPeople.AddPerson(New Person("Marge", "Simpson", 38))
        myPeople.AddPerson(New Person("Lisa", "Simpson", 9))
        myPeople.AddPerson(New Person("Bart", "Simpson", 7))
        myPeople.AddPerson(New Person("Maggie", "Simpson", 2))

        ' This would be a compile-time error!
        'myPeople.AddPerson(New Car())
        For Each p As Person In myPeople
            Console.WriteLine(p)
        Next
    End Sub
#End Region

#Region "Use generic list"
    Sub UseGenericList()
        Console.WriteLine("***** Fun with Generics *****" & vbLf)
        'This List(Of T) can only hold Person objects.

        Dim morePeople As New List(Of Person)()
        morePeople.Add(New Person("Frank", "Black", 50))
        Console.WriteLine(morePeople(0))

        'This List(Of T) can only hold Integers?
        Dim moreInts As New List(Of Integer)()
        moreInts.Add(10)
        moreInts.Add(2)
        Dim sum As Integer = moreInts(0) + moreInts(1)

        'Compile-time error! Can't add Person object
        ' to a list of Integers!
        ' moreInts.Add(new Person());
    End Sub

#End Region

End Module
