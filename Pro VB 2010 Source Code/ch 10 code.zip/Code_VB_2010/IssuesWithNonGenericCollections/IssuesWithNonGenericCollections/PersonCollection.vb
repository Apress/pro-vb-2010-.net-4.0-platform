﻿Public Class PersonCollection
    Implements IEnumerable
    Private arPeople As New ArrayList()
    Public Function GetPerson(ByVal pos As Integer) As Person
        Return DirectCast(arPeople(pos), Person)
    End Function
    Public Sub AddPerson(ByVal p As Person)
        arPeople.Add(p)
    End Sub
    Public Sub ClearPeople()
        arPeople.Clear()
    End Sub
    Public ReadOnly Property Count() As Integer
        Get
            Return arPeople.Count
        End Get
    End Property
    Function GetEnumerator() As IEnumerator Implements IEnumerable.GetEnumerator
        Return arPeople.GetEnumerator()
    End Function

End Class


