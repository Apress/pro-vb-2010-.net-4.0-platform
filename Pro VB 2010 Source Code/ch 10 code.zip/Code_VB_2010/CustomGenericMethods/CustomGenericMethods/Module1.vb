﻿#Region "generic helper Module"
Public Module MyGenericMethods
    ' This method will swap any two items.
    ' as specified by the type parameter (Of T).
    Public Sub Swap(Of T)(ByRef a As T, ByRef b As T)
        Console.WriteLine("You sent the Swap() method a {0}", GetType(T))
        Dim temp As T
        temp = a
        a = b
        b = temp
    End Sub
    Public Sub DisplayBaseClass(Of T)()
        Console.WriteLine("Base class of {0} is: {1}.", GetType(T), GetType(T).BaseType)
    End Sub
End Module
#End Region
Module Module1
    Sub Main()
        Console.WriteLine("***** Fun with Custom Generic Methods *****" & vbLf)

        'Swap 2 Integers.
        Dim a As Integer = 10, b As Integer = 90
        Console.WriteLine("Before swap: {0}, {1}", a, b)
        Swap(Of Integer)(a, b)
        Console.WriteLine("After swap: {0}, {1}", a, b)
        Console.WriteLine()

        ' Swap 2 Strings.
        Dim s1 As String = "Hello", s2 As String = "There"
        Console.WriteLine("Before swap: {0} {1}!", s1, s2)
        Swap(Of String)(s1, s2)
        Console.WriteLine("After swap: {0} {1}!", s1, s2)
        Console.WriteLine()

        ' Compiler will infer System.Boolean.
        Dim b1 As Boolean = True, b2 As Boolean = False
        Console.WriteLine("Before swap: {0}, {1}", b1, b2)
        Swap(b1, b2)
        Console.WriteLine("After swap: {0}, {1}", b1, b2)
        Console.WriteLine()

        'Must supply type parameter if
        'the method does not take params.
        DisplayBaseClass(Of Integer)()
        DisplayBaseClass(Of String)()
        'Compiler error! No params? Must supply placeholder!
        'DisplayBaseClass()

        Console.ReadLine()

    End Sub
#Region "Generic methods"
    'This method will swap any two items.
    'as specified by the type parameter (Of T).
    Sub Swap(Of T)(ByRef a As T, ByRef b As T)
        Console.WriteLine("You sent the Swap() method a {0}", GetType(T))
        Dim temp As T
        temp = a
        a = b
        b = temp
    End Sub

    Sub DisplayBaseClass(Of T)()
        ' BaseType is a method used in reflection, 
        ' which will be examined in Chapter 15
        Console.WriteLine("Base class of {0} is: {1}.", GetType(T), GetType(T).BaseType)
    End Sub
#End Region

End Module