﻿
#Region "Person class for testing"
Public Class Person
    Public Property Age() As Integer
    Public Property FirstName() As String
    Public Property LastName() As String

    Public Sub New()
    End Sub

    Public Sub New(ByVal firstName As String, ByVal lastName As String, ByVal age As Integer)
        Me.Age = age
        Me.FirstName = firstName
        Me.LastName = lastName
    End Sub

    Public Overrides Function ToString() As String
        Return String.Format("Name: {0} {1}, Age: {2}", FirstName, LastName, Age)
    End Function
End Class
#End Region

#Region "SortPeopleByAge class"
Public Class SortPeopleByAge
    Implements IComparer(Of Person)
    Public Function Compare(ByVal firstPerson As Person, ByVal secondPerson As Person) _
        As Integer Implements Generic.IComparer(Of FunWithGenericCollections.Person).Compare
        If firstPerson.Age > secondPerson.Age Then
            Return 1
        End If
        If firstPerson.Age < secondPerson.Age Then
            Return -1
        Else
            Return 0
        End If
    End Function
End Class
#End Region

Module Module1
    Sub Main()
        Console.WriteLine("***** Fun with Generic Collections *****" & vbLf)
        UseSortedSet()
        Console.ReadLine()
    End Sub


#Region " Use List(Of T)"
    Public Sub UseGenericList()
        ' Make a List of Person objects, filled with 
        ' collection / object init syntax.
        Dim p1 As New Person() With {.FirstName = "Homer", .LastName = "Simpson", .Age = 47}
        Dim p2 As New Person() With {.FirstName = "Marge", .LastName = "Simpson", .Age = 45}
        Dim p3 As New Person() With {.FirstName = "Lisa", .LastName = "Simpson", .Age = 9}
        Dim p4 As New Person() With {.FirstName = "Bart", .LastName = "Simpson", .Age = 8}

        Dim people As New List(Of Person)
        people.AddRange(p1)
        people.AddRange(p2)
        people.AddRange(p3)
        people.AddRange(p4)

        ' Print out # of items in List.
        Console.WriteLine("Items in list: {0}", people.Count)

        ' Enumerate over list.
        For Each p As Person In people
            Console.WriteLine(p)
        Next

        ' Insert a new person.
        Console.WriteLine(vbLf & "->Inserting new person.")
        people.Insert(2, New Person() With { _
         .FirstName = "Maggie", _
         .LastName = "Simpson", _
         .Age = 2 _
        })
        Console.WriteLine("Items in list: {0}", people.Count)

        ' Copy data into a new array.
        Dim arrayOfPeople As Person() = people.ToArray()
        For i As Integer = 0 To arrayOfPeople.Length - 1
            Console.WriteLine("First Names: {0}", arrayOfPeople(i).FirstName)
        Next
    End Sub


#End Region


#Region "Use Queue(Of T)"
    Sub GetCoffee(ByVal p As Person)
        Console.WriteLine("{0} got coffee!", p.FirstName)
    End Sub

    Sub UseGenericQueue()
        'Make a Q with three people.
        Dim peopleQ As New Queue(Of Person)()
        peopleQ.Enqueue(New Person With {.FirstName = "Homer", .LastName = "Simpson", .Age = 47})
        peopleQ.Enqueue(New Person With {.FirstName = "Marge", .LastName = "Simpson", .Age = 45})
        peopleQ.Enqueue(New Person With {.FirstName = "Lisa", .LastName = "Simpson", .Age = 9})

        'Peek at first person in Q.
        Console.WriteLine("{0} is first in line!", peopleQ.Peek().FirstName)
        GetCoffee(peopleQ.Dequeue())
        GetCoffee(peopleQ.Dequeue())
        GetCoffee(peopleQ.Dequeue())

        'Try to de-Q again?
        Try
            GetCoffee(peopleQ.Dequeue())
        Catch e As InvalidOperationException
            Console.WriteLine("Error! {0}", e.Message)
        End Try
    End Sub
#End Region

#Region "Use Stack(Of T)"
    Sub UseGenericStack()
        Dim stackOfPeople As New Stack(Of Person)()
        stackOfPeople.Push(New Person With {.FirstName = "Homer", .LastName = "Simpson", .Age = 47})
        stackOfPeople.Push(New Person With {.FirstName = "Marge", .LastName = "Simpson", .Age = 45})
        stackOfPeople.Push(New Person With {.FirstName = "Lisa", .LastName = "Simpson", .Age = 9})

        'Now look at the top item, pop it, and look again.
        Console.WriteLine("First person is: {0}", stackOfPeople.Peek())
        Console.WriteLine("Popped off {0}", stackOfPeople.Pop())
        Console.WriteLine(vbLf & "First person is: {0}", stackOfPeople.Peek())
        Console.WriteLine("Popped off {0}", stackOfPeople.Pop())
        Console.WriteLine(vbLf & "First person item is: {0}", stackOfPeople.Peek())
        Console.WriteLine("Popped off {0}", stackOfPeople.Pop())
        Try
            Console.WriteLine(vbLf & "nFirst person is: {0}", stackOfPeople.Peek())
            Console.WriteLine("Popped off {0}", stackOfPeople.Pop())
        Catch ex As InvalidOperationException
            Console.WriteLine(vbLf & "Error! {0}", ex.Message)
        End Try
    End Sub
#End Region

#Region "Use SortedSet (Of T)"
    Sub UseSortedSet()
        ' Make some people with different ages.
        Dim p1 As New Person() With {.FirstName = "Homer", .LastName = "Simpson", .Age = 47}
        Dim p2 As New Person() With {.FirstName = "Marge", .LastName = "Simpson", .Age = 45}
        Dim p3 As New Person() With {.FirstName = "Lisa", .LastName = "Simpson", .Age = 9}
        Dim p4 As New Person() With {.FirstName = "Bart", .LastName = "Simpson", .Age = 8}

        Dim setOfPeople As New SortedSet(Of Person)(New SortPeopleByAge())

        setOfPeople.Add(p1)
        setOfPeople.Add(p2)
        setOfPeople.Add(p3)
        setOfPeople.Add(p4)

        ' Note the items are sorted by age!
        For Each p As Person In setOfPeople
            Console.WriteLine(p)
        Next
        Console.WriteLine()

        ' Add a few new people, with various ages. 
        setOfPeople.Add(New Person() With { _
         .FirstName = "Saku", _
         .LastName = "Jones", _
         .Age = 1 _
        })
        setOfPeople.Add(New Person() With { _
         .FirstName = "Mikko", _
         .LastName = "Jones", _
         .Age = 32 _
        })

        For Each p As Person In setOfPeople
            Console.WriteLine(p)
        Next

    End Sub

#End Region
End Module
