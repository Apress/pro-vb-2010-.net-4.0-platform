﻿'A generic Point structure.
Public Structure Point(Of T)
    Private xPos As T
    Private yPos As T

    Public Sub New(ByVal xVal As T, ByVal yVal As T)
        xPos = xVal
        yPos = yVal
    End Sub

    Public Property X() As T
        Get
            Return xPos
        End Get
        Set(ByVal value As T)
            xPos = value
        End Set
    End Property

    Public Property Y() As T
        Get
            Return yPos
        End Get
        Set(ByVal value As T)
            yPos = value
        End Set
    End Property

    Public Overrides Function ToString() As String
        Return String.Format("[{0}, {1}]", xPos, yPos)
    End Function

    Public Sub ResetPoint()
        xPos = Nothing
        yPos = Nothing
    End Sub
End Structure

Module Module1
    Sub Main()

        Console.WriteLine("***** Fun with Generic Structures *****" & vbLf)
        Dim p As New Point(Of Integer)(10, 10)
        Console.WriteLine("p.ToString()={0}", p.ToString())
        p.ResetPoint()
        Console.WriteLine("p.ToString()={0}", p.ToString())
        Console.WriteLine()
        Dim p2 As New Point(Of Double)(5.4, 3.3)
        Console.WriteLine("p2.ToString()={0}", p2.ToString())
        p2.ResetPoint()
        Console.WriteLine("p2.ToString()={0}", p2.ToString())
        Console.ReadLine()
    End Sub
End Module






