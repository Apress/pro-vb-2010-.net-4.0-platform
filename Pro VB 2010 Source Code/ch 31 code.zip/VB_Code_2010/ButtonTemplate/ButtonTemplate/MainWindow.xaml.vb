﻿Public Class MainWindow

    Private Sub myButton_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles myButton.Click
        MessageBox.Show("You clicked the button")
    End Sub
End Class
