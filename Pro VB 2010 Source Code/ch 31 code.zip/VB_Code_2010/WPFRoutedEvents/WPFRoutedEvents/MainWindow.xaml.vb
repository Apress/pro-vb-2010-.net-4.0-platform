﻿''' <summary>
''' Interaction logic for MainWindow.xaml
''' </summary>

Class MainWindow

    Private mouseActivity As String = String.Empty

    Private Sub btnClickMe_Clicked(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnClickMe.Click
        AddEventInfo(sender, e)

        ' Do something when button is clicked.
        MessageBox.Show(mouseActivity, "Your Event Info")

        ' Clear string for next round.
        mouseActivity = ""

    End Sub

    Private Sub AddEventInfo(ByVal sender As Object, ByVal e As RoutedEventArgs)
        mouseActivity &= String.Format("{0} sent a {1} event named {2}." & vbLf, sender, e.RoutedEvent.RoutingStrategy, e.RoutedEvent.Name)
    End Sub

    Private Sub outerEllipse_MouseDown(ByVal sender As Object, ByVal e As MouseButtonEventArgs) Handles outerEllipse.MouseDown, btnClickMe.MouseDown
        AddEventInfo(sender, e)
    End Sub

    Private Sub outerEllipse_PreviewMouseDown(ByVal sender As Object, ByVal e As MouseButtonEventArgs) Handles outerEllipse.PreviewMouseDown, btnClickMe.PreviewMouseDown
        AddEventInfo(sender, e)
    End Sub

End Class
