﻿Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Data
Imports System.Windows.Documents
Imports System.Windows.Input
Imports System.Windows.Media
Imports System.Windows.Media.Imaging
Imports System.Windows.Navigation
Imports System.Windows.Shapes

	Partial Public Class StarButton
		Inherits UserControl
		Public Sub New()
			Me.InitializeComponent()
		End Sub

		Private Sub StarControl_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Input.MouseButtonEventArgs)
			' Parameter 1 : Which control we are working with.
			' Parameter 2 : Which state to transition to.
			' Parameter 3 : Do we want to use transition times? 
			VisualStateManager.GoToState(Me, "MouseDownStar", True)
		End Sub

		Private Sub StarControl_MouseEnter(ByVal sender As Object, ByVal e As System.Windows.Input.MouseEventArgs)
			VisualStateManager.GoToState(Me, "MouseEnterStar", True)
		End Sub

		Private Sub StarControl_MouseLeave(ByVal sender As Object, ByVal e As System.Windows.Input.MouseEventArgs)
			VisualStateManager.GoToState(Me, "MouseExitStar", True)
		End Sub
	End Class
