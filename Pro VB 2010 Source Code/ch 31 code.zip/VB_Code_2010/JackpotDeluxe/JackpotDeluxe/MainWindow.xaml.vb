﻿Public Class MainWindow
        Private totalPoints As Integer = 0
		Private totalAttempts As Integer = 0
		Private MaxAttempts As Integer = 20
    Private Sub btnSpin_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Input.MouseButtonEventArgs) Handles btnSpin.MouseDown
        ' Add 1 to number of tries. 
        totalAttempts += 1
        Me.txtAttempts.Text = String.Format("Attempts: {0}", (totalAttempts).ToString())

        ' Last attempt??
        If totalAttempts >= MaxAttempts Then
            DoLosingCondition()
        End If

        ' Spin each control.
        Dim randomOne As Integer = Me.imgFirst.Spin()
        Dim randomTwo As Integer = Me.imgSecond.Spin()
        Dim randomThree As Integer = Me.imgThird.Spin()

        ' Caluculate the new score. To make things simple, players only get 
        ' points if all three images are identical. 
        If randomOne = randomTwo AndAlso randomTwo = randomThree Then
            ' Adjust points. 
            totalPoints += 10
            Me.txtScore.Text = String.Format("Score: {0}", totalPoints.ToString())

            ' Did we get 100 or more points?
            If totalPoints >= 100 Then
                DoWinningCondition()
            End If
        End If
    End Sub

		Private Sub DoLosingCondition()
			' Change text.
			Me.txtInstructions.Text = "YOU LOSE!"
			Me.txtInstructions.FontSize = 80
			Me.txtInstructions.Foreground = New SolidColorBrush(Colors.Gray)

			' Disable button, game over dude!
			Me.btnSpin.IsEnabled = False
		End Sub

		Private Sub DoWinningCondition()
			' Change text.
			Me.txtInstructions.Text = "YOU WIN!"
			Me.txtInstructions.FontSize = 80
			Me.txtInstructions.Foreground = New SolidColorBrush(Colors.Orange)

			' Disable button, game over dude!
			Me.btnSpin.IsEnabled = False
		End Sub

End Class