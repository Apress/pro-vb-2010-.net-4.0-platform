﻿Public Class ShowNumberControl

#Region "The CurrentNumber dependency property."
    Public Property CurrentNumber() As Integer
        Get
            Return CInt(GetValue(CurrentNumberProperty))
        End Get
        Set(ByVal value As Integer)
            SetValue(CurrentNumberProperty, value)
            MessageBox.Show("In SET")
        End Set
    End Property

    ' Note the second param of UIPropertyMetadata.
    Public Shared ReadOnly CurrentNumberProperty As DependencyProperty =
                   DependencyProperty.Register(
                                        "CurrentNumber", GetType(Integer),
                                        GetType(ShowNumberControl),
                                        New UIPropertyMetadata(100,
                                        New PropertyChangedCallback(AddressOf CurrentNumberChanged)),
                                        New ValidateValueCallback(AddressOf ValidateCurrentNumber))

    Public Shared Function ValidateCurrentNumber(ByVal value As Object) As Boolean
        ' Just a simple business rule.  Value must be between 0 and 500.
        If Convert.ToInt32(value) >= 0 AndAlso Convert.ToInt32(value) <= 500 Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Shared Sub CurrentNumberChanged(ByVal depObj As DependencyObject, ByVal args As DependencyPropertyChangedEventArgs)
        ' Cast the DependencyObject into ShowNumberControl
        Dim c As ShowNumberControl = CType(depObj, ShowNumberControl)

        ' Get the Label control in the ShowNumberControl.
        Dim theLabel As Label = c.numberDisplay

        ' Set the label with the new value.
        theLabel.Content = args.NewValue.ToString()

    End Sub
#End Region

End Class


