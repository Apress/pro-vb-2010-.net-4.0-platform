﻿
Imports System.Windows.Media.Animation

Class SpinControl

    ' An array of BitmapImage objects.
    Private images(2) As BitmapImage
    Private Sub SpinControl_Loaded(ByVal sender As Object, ByVal e As System.Windows.RoutedEventArgs)
        ' Fill the ImageSource array with each image.
        images(0) = New BitmapImage(New Uri("Cherries.png", UriKind.Relative))
        images(1) = New BitmapImage(New Uri("Jackpot.jpg", UriKind.Relative))
        images(2) = New BitmapImage(New Uri("Limes.jpg", UriKind.Relative))
    End Sub

    Public Function Spin() As Integer
        ' Randomly put of the images into the Image control.
        Dim r As New Random(Date.Now.Millisecond)
        Dim randomNumber As Integer = r.Next(3)
        Me.imgDisplay.Source = images(randomNumber)

        ' Start our storyboard animation!
        CType(Resources("SpinImageStoryboard"), Storyboard).Begin()
        Return randomNumber
    End Function

End Class
