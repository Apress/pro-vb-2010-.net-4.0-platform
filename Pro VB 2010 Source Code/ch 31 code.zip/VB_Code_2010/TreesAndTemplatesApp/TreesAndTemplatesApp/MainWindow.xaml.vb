﻿Imports System.Text
Imports System.Xml
Imports System.Reflection
Imports System.Windows.Markup


Public Class MainWindow

    Private dataToShow As String = String.Empty
    Private ctrlToExamine As Control = Nothing

#Region "Logical tree helpers"
    Private Sub btnShowLogicalTree_Click(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles btnShowLogicalTree.Click
        dataToShow = ""
        BuildLogicalTree(0, Me)
        Me.txtDisplayArea.Text = dataToShow
    End Sub

    Private Sub BuildLogicalTree(ByVal depth As Integer, ByVal obj As Object)
        ' Add the type name to the dataToShow member variable.
        dataToShow &= New String(" "c, depth) & obj.GetType().Name & vbLf

        ' If an item is not a DependencyObject, skip it. 
        If Not (TypeOf obj Is DependencyObject) Then
            Return
        End If

        ' Make a recursive call for each logical child
        For Each child As Object In LogicalTreeHelper.GetChildren(TryCast(obj, DependencyObject))
            BuildLogicalTree(depth + 5, child)
        Next
    End Sub
#End Region

#Region "Visual tree helpers"
    Private Sub btnShowVisualTree_Click(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles btnShowVisualTree.Click
        dataToShow = ""
        BuildVisualTree(0, Me)
        Me.txtDisplayArea.Text = dataToShow
    End Sub

    Private Sub BuildVisualTree(ByVal depth As Integer, ByVal obj As DependencyObject)
        ' Add the type name to the dataToShow member variable.
        dataToShow &= New String(" "c, depth) & obj.GetType().Name & vbLf

        ' Make a recursive call for each visual child
        For i As Integer = 0 To VisualTreeHelper.GetChildrenCount(obj) - 1
            BuildVisualTree(depth + 1, VisualTreeHelper.GetChild(obj, i))
        Next i
    End Sub
#End Region

#Region "Show template helpers"
    Private Sub btnTemplate_Click(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles btnTemplate.Click
        dataToShow = ""
        ShowTemplate()
        Me.txtDisplayArea.Text = dataToShow
    End Sub

    Private Sub ShowTemplate()
        ' Remove the control which is currently in the preview area. 
        If ctrlToExamine IsNot Nothing Then
            stackTemplatePanel.Children.Remove(ctrlToExamine)
        End If
        Try
            ' Load PresentationFramework, and create an instance of the
            ' specified control.  Give it a size for display purposes, then add to the 
            ' empty StackPanel. 
            Dim asm As Assembly = Assembly.Load("PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35")
            ctrlToExamine = CType(asm.CreateInstance(txtFullName.Text), Control)
            ctrlToExamine.Height = 200
            ctrlToExamine.Width = 200
            ctrlToExamine.Margin = New Thickness(5)
            stackTemplatePanel.Children.Add(ctrlToExamine)

            ' Define some XML settings to preserve indentation.
            Dim xmlSettings As New XmlWriterSettings()
            xmlSettings.Indent = True

            ' Create a StringBuilder to hold the XAML.
            Dim strBuilder As New StringBuilder()

            ' Create an XmlWriter based on our settings.
            Dim xWriter As XmlWriter = XmlWriter.Create(strBuilder, xmlSettings)

            ' Now save the XAML into the XmlWriter object based on the ControlTemplate.
            XamlWriter.Save(ctrlToExamine.Template, xWriter)

            ' Display XAML in the text box
            dataToShow = strBuilder.ToString()
        Catch ex As Exception
            dataToShow = ex.Message
        End Try
    End Sub
#End Region
End Class
