﻿
Module Module1

    Sub Main()
        'This array will be the basis of our testing...
        Console.WriteLine("***** Fun with Query Expressions *****" & vbLf)

        Dim itemsInStock() As ProductInfo =
          {
            New ProductInfo() With {.Name = "Mac's Coffee", .Description = "Coffee with TEETH", .NumberInStock = 24},
            New ProductInfo() With {.Name = "Milk Maid Milk", .Description = "Milk cow's love", .NumberInStock = 100},
            New ProductInfo() With {.Name = "Pure Silk Tofu", .Description = "Bland as Possible", .NumberInStock = 120},
            New ProductInfo() With {.Name = "Cruchy Pops", .Description = "Cheezy, peppery goodness", .NumberInStock = 2},
            New ProductInfo() With {.Name = "RipOff Water", .Description = "From the tap to your wallet", .NumberInStock = 100},
            New ProductInfo() With {.Name = "Classic Valpo Pizza", .Description = "Everyone loves pizza!", .NumberInStock = 73}
          }

        'We will call various methods here!
        SelectEverything(itemsInStock)
        Console.WriteLine()

        ListProductNames(itemsInStock)
        Console.WriteLine()

        GetOverstock(itemsInStock)
        Console.WriteLine()

        GetNamesAndDescriptions(itemsInStock)
        Console.WriteLine()

        Dim objs As Array = GetProjectedSubset()

        ' Calls ToString() on each anonymous object.
        For Each o As Object In objs
            'Calls ToString() on each anonymous object.
            Console.WriteLine(o)
        Next
        Console.WriteLine()
        Console.WriteLine()

        AlphabetizeProductNames(itemsInStock)
        Console.WriteLine()

        GetCountFromQuery()
        Console.WriteLine()

        DisplayConcat()
        Console.WriteLine()

        DisplayConcatNoDups()
        Console.WriteLine()

        DisplayDiff()
        Console.WriteLine()

        DisplayIntersection()
        Console.WriteLine()

        DisplayUnion()
        Console.WriteLine()

        AggregateOps()
        Console.WriteLine()
        Console.ReadLine()

    End Sub

#Region "Basic selections"
    Sub SelectEverything(ByVal products As ProductInfo())

        'Get everything.
        Console.WriteLine("All product details:")

        Dim allProducts = From p In products _
                          Select p

        For Each prod In allProducts
            Console.WriteLine(prod.ToString())
        Next

    End Sub

    Sub ListProductNames(ByVal products As ProductInfo())

        'Now get only the names of the products.
        Console.WriteLine("Only product names:")
        Dim names = From p In products _
                    Select p.Name

        For Each n In names
            Console.WriteLine("Name: {0}", n)
        Next
    End Sub
#End Region

#Region "Order By"
    Sub AlphabetizeProductNames(ByVal products As ProductInfo())

        'Get names of products, alphabetized.
        Dim subset = From p In products _
                     Order By p.Name Descending _
                     Select p

        Console.WriteLine("Ordered by Name:")
        For Each p In subset
            Console.WriteLine(p.ToString())
        Next
    End Sub
#End Region

#Region "Subsets with Where"
    Sub GetOverstock(ByVal products As ProductInfo())

        'Get only the items where we have more than
        '25 in stock.
        Console.WriteLine("The overstock items!")
        Dim overstock = From p In products _
                        Where p.NumberInStock > 25 _
                        Select p

        For Each c As ProductInfo In overstock
            Console.WriteLine(c.ToString())
        Next
    End Sub
#End Region

#Region "Projections"
    Sub GetNamesAndDescriptions(ByVal products As ProductInfo())

        Console.WriteLine("Names and Descriptions:")
        Dim nameDesc = From p In products _
                       Select p.Name, p.Description

        For Each item In nameDesc
            'Could also use Name and Description properties directly.
            Console.WriteLine(item.ToString())
        Next
    End Sub

    'Return value is now an Array.
    Function GetProjectedSubset()

        Dim products() As ProductInfo =
            {
                New ProductInfo With {.Name = "Mac's Coffee", .Description = "Coffee with TEETH", .NumberInStock = 24},
                New ProductInfo With {.Name = "Milk Maid Milk", .Description = "Milk cow's love", .NumberInStock = 100},
                New ProductInfo With {.Name = "Pure Silk Tofu", .Description = "Bland as Possible", .NumberInStock = 120},
                New ProductInfo With {.Name = "Cruchy Pops", .Description = "Cheezy, peppery goodness", .NumberInStock = 2},
                New ProductInfo With {.Name = "RipOff Water", .Description = "From the tap to your wallet", .NumberInStock = 100},
                New ProductInfo With {.Name = "Classic Valpo Pizza", .Description = "Everyone loves pizza!", .NumberInStock = 73}
            }
        Dim nameDesc = From p In products _
                       Select p.Name, p.Description

        Return nameDesc.ToArray()
    End Function
#End Region

#Region "Get the Count"
    Sub GetCountFromQuery()

        Dim currentVideoGames As String() = {"Morrowind", "BioShock", "Half Life 2: Episode 1", "The Darkness", "Daxter", "System Shock 2"}
        'Get count from the query.
        Dim numb As Integer = (From g In currentVideoGames _
                               Where g.Length > 6 _
                               Order By g _
                               Select g).Count()
        'numb is the value 5.
        Console.WriteLine("{0} items honor the LINQ query.", numb)
    End Sub
#End Region

#Region "Reversing"
    Sub ReverseEverything(ByVal products As ProductInfo())

        'Get everything.
        Console.WriteLine("Product in reverse:")
        Dim allProducts = From p In products _
                          Select p
        For Each prod In allProducts.Reverse()
            Console.WriteLine(prod.ToString())
        Next
    End Sub
#End Region

#Region "Venn diagram type extension methods"
    Sub DisplayDiff()

        Dim myCars As New List(Of String)({"Yugo", "Aztec", "BMW"})
        Dim yourCars As New List(Of String)({"BMW", "Saab", "Aztec"})
        Dim carDiff = (From c In myCars _
                       Select c).Except(From c2 In yourCars _
                       Select c2)
        Console.WriteLine("Here is what you don't have, but I do:")
        For Each s As String In carDiff
            Console.WriteLine(s)
        Next
    End Sub

    Sub DisplayIntersection()

        Dim myCars As New List(Of String)({"Yugo", "Aztec", "BMW"})
        Dim yourCars As New List(Of String)({"BMW", "Saab", "Aztec"})
        'Get the common members.
        Dim carIntersect = (From c In myCars _
                            Select c).Intersect(From c2 In yourCars _
                            Select c2)
        Console.WriteLine("Here is what we have in common:")
        For Each s As String In carIntersect
            Console.WriteLine(s)
        Next
    End Sub

    Sub DisplayUnion()

        Dim myCars As New List(Of String)({"Yugo", "Aztec", "BMW"})
        Dim yourCars As New List(Of String)({"BMW", "Saab", "Aztec"})
        'Get the union of these containers. 
        Dim carUnion = (From c In myCars _
                        Select c).Union(From c2 In yourCars _
                        Select c2)
        Console.WriteLine("Here is everything:")
        For Each s As String In carUnion
            Console.WriteLine(s)
        Next
    End Sub

    Sub DisplayConcat()

        Dim myCars As New List(Of String)({"Yugo", "Aztec", "BMW"})
        Dim yourCars As New List(Of String)({"BMW", "Saab", "Aztec"})
        ' Prints:
        'Yugo, Aztec, BMW, BMW, Saab, Aztec.
        Dim carConcat = (From c In myCars _
                         Select c).Concat(From c2 In yourCars _
                         Select c2)
        For Each s As String In carConcat
            Console.WriteLine(s)
        Next
    End Sub

    Sub DisplayConcatNoDups()

        Dim myCars As New List(Of String)({"Yugo", "Aztec", "BMW"})
        Dim yourCars As New List(Of String)({"BMW", "Saab", "Aztec"})
        'Prints:
        'Yugo Aztec BMW Saab Aztec.
        Dim carConcat = (From c In myCars _
                         Select c).Concat(From c2 In yourCars _
                         Select c2)
        For Each s As String In carConcat.Distinct()
            Console.WriteLine(s)
        Next
    End Sub
#End Region

#Region "Aggregation Examples"
    Sub AggregateOps()

        'Various aggregation examples. 
        Dim winterTemps As Double() = {2, -21.3, 8, -4, 0, 8.2}
        Console.WriteLine("Max temp: {0}", (From t In winterTemps Select t).Max())
        Console.WriteLine("Min temp: {0}", (From t In winterTemps Select t).Min())
        Console.WriteLine("Average temp: {0}", (From t In winterTemps Select t).Average())
        Console.WriteLine("Sum of all temps: {0}", (From t In winterTemps Select t).Sum())
    End Sub
#End Region

End Module


Public Class ProductInfo

    Public Property Name() As String
    Public Property Description() As String
    Public Property NumberInStock() As Integer

    Public Overrides Function ToString() As String
        Return String.Format("Name={0}, Description={1}, Number in Stock={2}", Name, Description, NumberInStock)
    End Function

End Class
