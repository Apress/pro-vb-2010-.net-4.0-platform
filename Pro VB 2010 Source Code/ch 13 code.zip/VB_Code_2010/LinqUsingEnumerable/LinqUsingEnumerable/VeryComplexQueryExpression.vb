﻿Public Class VeryComplexQueryExpression

    Public Shared Sub QueryStringsWithRawDelegates()

        Console.WriteLine("***** Using Raw Delegates *****")
        Dim currentVideoGames As String() = {"Morrowind", "Uncharted 2", "Fallout 3", "Daxter", "System Shock 2"}

        'Build the necessary Func(Of T) delegates.
        Dim searchFilter As New Func(Of String, Boolean)(AddressOf Filter)
        Dim itemToProcess As New Func(Of String, String)(AddressOf ProcessItem)

        'Pass the delegates into the methods of Enumerable.
        Dim subset = currentVideoGames.Where(searchFilter).OrderBy(itemToProcess).Select(itemToProcess)

        'Print out the results.
        For Each game In subset
            Console.WriteLine("Item: {0}", game)
        Next
        Console.WriteLine()
    End Sub

    ' Delegate targets.
    Public Shared Function Filter(ByVal game As String) As Boolean
        Return game.Contains(" ")
    End Function

    Public Shared Function ProcessItem(ByVal game As String) As String
        Return game
    End Function
End Class
