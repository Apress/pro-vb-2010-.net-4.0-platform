﻿Module Module1

    Sub Main()

        Console.WriteLine("**** The Many Faces of LINQ! *****")
        Console.WriteLine()

        QueryStringWithOperators()
        Console.WriteLine()

        QueryStringsWithEnumerableAndLambdas()
        Console.WriteLine()

        QueryStringsWithEnumerableAndLambdas2()
        Console.WriteLine()

        QueryStringsWithAnonymousMethods()
        Console.WriteLine()

        VeryComplexQueryExpression.QueryStringsWithRawDelegates()
        Console.ReadLine()
    End Sub

#Region "LINQ with VB 2010 operators"
    Sub QueryStringWithOperators()

        Console.WriteLine("***** Using Query Operators *****")
        Dim currentVideoGames As String() = {"Morrowind", "Uncharted 2", "Fallout 3", "Daxter", "System Shock 2"}

        Dim subset = From game In currentVideoGames _
                     Where game.Contains(" ") _
                     Order By game _
                     Select game
        For Each s As String In subset
            Console.WriteLine("Item: {0}", s)
        Next
    End Sub
#End Region

#Region "LINQ with Enumerable and lambda expressions"
    Sub QueryStringsWithEnumerableAndLambdas()

        Console.WriteLine("***** Using Enumerable / Lambda Expressions *****")
        Dim currentVideoGames As String() = {"Morrowind", "Uncharted 2", "Fallout 3", "Daxter", "System Shock 2"}

        'Build a query expression using extension methods
        'granted to the Array via the Enumerable type.
        Dim subset = currentVideoGames.Where(Function(game) game.Contains(" ")).OrderBy(Function(game) game).Select(Function(game) game)

        'Print out the results.
        For Each game In subset
            Console.WriteLine("Item: {0}", game)
        Next
        Console.WriteLine()
    End Sub

    Sub QueryStringsWithEnumerableAndLambdas2()

        Console.WriteLine("***** Using Enumerable / Lambda Expressions *****")
        Dim currentVideoGames As String() = {"Morrowind", "Uncharted 2", "Fallout 3", "Daxter", "System Shock 2"}

        'Build a query expression using extension methods
        'granted to the Array via the Enumerable type.
        Dim gamesWithSpaces = currentVideoGames.Where(Function(game) game.Contains(" "))
        Dim orderedGames = gamesWithSpaces.OrderBy(Function(game) game)
        Dim subset = orderedGames.Select(Function(game) game)

        'Print out the results.
        For Each game In subset
            Console.WriteLine("Item: {0}", game)
        Next
        Console.WriteLine()
    End Sub
#End Region

#Region "LINQ with anonymous methods"
    Sub QueryStringsWithAnonymousMethods()

        Console.WriteLine("***** Using Anonymous Methods *****")
        Dim currentVideoGames As String() = {"Morrowind", "Uncharted 2", "Fallout 3", "Daxter", "System Shock 2"}

        'Build the necessary Func() delegates using anonymous methods.
        Dim searchFilter As Func(Of String, Boolean) = Function(game As String)
                                                           Return game.Contains(" ")
                                                       End Function

        Dim itemToProcess As Func(Of String, String) = Function(s As String)
                                                           Return s
                                                       End Function
        'Pass the delegates into the methods of Enumerable.
        Dim subset = currentVideoGames.Where(searchFilter).OrderBy(itemToProcess).Select(itemToProcess)

        'Print out the results.
        For Each game In subset
            Console.WriteLine("Item: {0}", game)
        Next
        Console.WriteLine()
    End Sub
#End Region

End Module
