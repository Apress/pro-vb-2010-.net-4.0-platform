﻿Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with LINQ to Objects *****" & vbLf)

        QueryOverStrings()
        Console.WriteLine()

        QueryOverStringsLongHand()
        Console.WriteLine()

        QueryOverInts()
        Console.WriteLine()

        ImmediateExecution()
        Console.WriteLine()
        Console.ReadLine()

    End Sub

    Sub QueryOverStrings()
        'Assume we have an array of Strings.
        Dim currentVideoGames As String() = {"Morrowind", "Uncharted 2", "Fallout 3", "Daxter", "System Shock 2"}

        'Build a query expression to find the items in the array
        'that have an embedded space.
        Dim subset As IEnumerable(Of String) = From g In currentVideoGames _
                                               Where g.Contains(" ") _
                                               Order By g _
                                               Select g

        'Print out the results.
        For Each s As String In subset
            Console.WriteLine("Item: {0}", s)
        Next
        Console.WriteLine()
        ReflectOverQueryResults(subset)

    End Sub

    Sub QueryOverStringsLongHand()
        'Assume we have an array of Strings.
        Dim currentVideoGames As String() = {"Morrowind", "Uncharted 2", "Fallout 3", "Daxter", "System Shock 2"}
        Dim gamesWithSpaces As String() = New String(4) {}

        For i = 0 To currentVideoGames.Length - 1
            If currentVideoGames(i).Contains(" ") Then
                gamesWithSpaces(i) = currentVideoGames(i)
            End If
        Next

        'Now sort them.
        Array.Sort(gamesWithSpaces)

        'Print out the results.
        For Each s As String In gamesWithSpaces
            If s IsNot Nothing Then
                Console.WriteLine("Item: {0}", s)
            End If
        Next
        Console.WriteLine()
    End Sub

    Sub QueryOverInts()
        Dim numbers As Integer() = {10, 20, 30, 40, 1, 2, 3, 8}

        'Get numbers less than ten.
        Dim subset = From i In numbers Where i < 10 Select i

        'LINQ statement evaluated here!
        For Each i In subset
            Console.WriteLine("{0} < 10", i)
        Next
        Console.WriteLine()

        'Change some data in the array.
        numbers(0) = 4

        'Evaluated again!
        For Each j In subset
            Console.WriteLine("{0} < 10", j)
        Next
        Console.WriteLine()
        ReflectOverQueryResults(subset)
    End Sub

    Sub ReflectOverQueryResults(ByVal resultSet As Object)
        Console.WriteLine("***** Info about your query *****")
        Console.WriteLine("resultSet is of type: {0}", resultSet.GetType().Name)
        Console.WriteLine("resultSet location: {0}", resultSet.GetType().Assembly.GetName().Name)
    End Sub

    Sub ImmediateExecution()
        Dim numbers As Integer() = {10, 20, 30, 40, 1, 2, 3, 8}

        'Get data RIGHT NOW as Integer().
        Dim subsetAsIntArray As Integer() = (From i In numbers _
                                   Where i < 10 Select i).ToArray()

        'Get data RIGHT NOW as List(Of Integer).
        Dim subsetAsListOfInts As List(Of Integer) = (From i In numbers _
                                   Where i < 10 Select i).ToList()
    End Sub

End Module
