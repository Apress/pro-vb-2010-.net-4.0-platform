﻿Module Module1

    Sub Main()
        Console.WriteLine("***** LINQ over Collections *****" & vbLf)

        'Make a List(Of T) of Car objects.
        Dim myCars As New List(Of Car) From _
        {
            New Car With {.PetName = "Henry", .Color = "Silver", .Speed = 100, .Make = "BMW"},
            New Car With {.PetName = "Daisy", .Color = "Tan", .Speed = 90, .Make = "BMW"},
            New Car With {.PetName = "Mary", .Color = "Black", .Speed = 55, .Make = "VW"},
            New Car With {.PetName = "Clunker", .Color = "Rust", .Speed = 5, .Make = "Yugo"},
            New Car With {.PetName = "Melvin", .Color = "White", .Speed = 43, .Make = "Ford"}
        }

        GetFastCars(myCars)
        Console.WriteLine()

        GetFastBMWs(myCars)
        Console.WriteLine()

        LINQOverArrayList()
        Console.WriteLine()

        OfTypeAsFilter()
        Console.ReadLine()

    End Sub

#Region "LINQ over generic collections of custom objects"
    Sub GetFastCars(ByVal myCars As List(Of Car))

        'Find all Car objects in the List(), where the Speed is 
        'greater than 55.
        Dim fastCars = From c In myCars _
                       Where c.Speed > 55 _
                       Select c
        For Each car In fastCars
            Console.WriteLine("{0} is going too fast!", car.PetName)
        Next
    End Sub

    Sub GetFastBMWs(ByVal myCars As List(Of Car))

        'Find the fast BMWs!
        Dim fastCars = From c In myCars _
                       Where c.Speed > 90 AndAlso c.Make = "BMW" _
                       Select c
        For Each car In fastCars
            Console.WriteLine("{0} is going too fast!", car.PetName)
        Next
    End Sub
#End Region

#Region "LINQ over non-generic collections of custom objects"
    Sub LINQOverArrayList()

        Console.WriteLine("***** LINQ over ArrayList *****")
        'Here is a nongeneric collection of cars.
        Dim myCars As New ArrayList() From
            {
                New Car With {.PetName = "Henry", .Color = "Silver", .Speed = 100, .Make = "BMW"},
                New Car With {.PetName = "Daisy", .Color = "Tan", .Speed = 90, .Make = "BMW"},
                New Car With {.PetName = "Mary", .Color = "Black", .Speed = 55, .Make = "VW"},
                New Car With {.PetName = "Clunker", .Color = "Rust", .Speed = 5, .Make = "Yugo"},
                New Car With {.PetName = "Melvin", .Color = "White", .Speed = 43, .Make = "Ford"}
            }
        'Transform ArrayList into an IEnumerable(Of T)-compatible type.
        Dim myCarsEnum = myCars.OfType(Of Car)()

        'Create a query expression.
        Dim fastCars = From c In myCarsEnum _
                       Where c.Speed > 55 _
                       Select c
        For Each car In fastCars
            Console.WriteLine("{0} is going too fast!", car.PetName)
        Next
    End Sub
#End Region

#Region "OfType() as a filter"
    Sub OfTypeAsFilter()

        'Extract the Integers from the ArrayList.
        Dim myStuff As New ArrayList()
        myStuff.AddRange(New Object() {10, 400, 8, False, New Car(), "string data"})
        Dim myInts As IEnumerable(Of Integer) = myStuff.OfType(Of Integer)()

        'Prints out 10, 400, and 8.
        For Each i As Integer In myInts
            Console.WriteLine("Integer value: {0}", i)
        Next
    End Sub
#End Region

End Module

#Region "Simple Car class"
Class Car
    Public Property PetName() As String
    Public Property Color() As String
    Public Property Speed() As Integer
    Public Property Make() As String

End Class
#End Region
