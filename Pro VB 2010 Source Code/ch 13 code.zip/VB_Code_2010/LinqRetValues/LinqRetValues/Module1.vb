﻿Module Module1

    Sub Main()

        Console.WriteLine("***** LINQ Transformations *****" & vbLf)

        Dim subset As IEnumerable(Of String) = GetStringSubset()
        For Each item As String In subset
            Console.WriteLine(item)
        Next
        Console.WriteLine()

        For Each item As String In GetStringSubsetAsArray()
            Console.WriteLine(item)
        Next
        Console.ReadLine()

    End Sub

#Region "LINQ 'return values'"
    Function GetStringSubset() As IEnumerable(Of String)

        Dim colors As String() = {"Light Red", "Green", "Yellow", "Dark Red", "Red", "Purple"}

        'Note subset is an IEnumerable(Of String) compatible object.
        Dim theRedColors As IEnumerable(Of String) = From c In colors _
                                                     Where c.Contains("Red") _
                                                     Select c
        Return theRedColors
    End Function

    Function GetStringSubsetAsArray() As String()

        Dim colors As String() = {"Light Red", "Green", "Yellow", "Dark Red", "Red", "Purple"}
        Dim theRedColors = From c In colors _
                           Where c.Contains("Red") _
                           Select c
        'Map results into an array.
        Return theRedColors.ToArray()
    End Function
#End Region

End Module
