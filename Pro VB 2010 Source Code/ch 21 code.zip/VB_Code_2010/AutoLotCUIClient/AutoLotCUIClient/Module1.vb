﻿Imports System.Configuration
Imports System.Data
Imports AutoLotConnectedLayer

Module Module1

    Sub Main()
        Console.WriteLine("***** The AutoLot Console UI *****" & vbLf)

        ' Get connection string from App.config.
        Dim cnStr As String = ConfigurationManager.ConnectionStrings("AutoLotSqlProvider").ConnectionString
        Dim userDone As Boolean = False
        Dim userCommand As String = ""

        ' Create our InventoryDAL object.
        Dim invDAL As New InventoryDAL()
        invDAL.OpenConnection(cnStr)

        ' Keep asking for input until user presses the Q key.
        Try
            ShowInstructions()
            Do
                Console.Write(vbLf & "Please enter your command: ")
                userCommand = Console.ReadLine()
                Console.WriteLine()
                Select Case userCommand.ToUpper()
                    Case "I"
                        InsertNewCar(invDAL)
                    Case "U"
                        UpdateCarPetName(invDAL)
                    Case "D"
                        DeleteCar(invDAL)
                    Case "L"
                        ' ListInventory(invDAL);
                        ListInventoryViaList(invDAL)
                    Case "S"
                        ShowInstructions()
                    Case "P"
                        LookUpPetName(invDAL)
                    Case "Q"
                        userDone = True
                    Case Else
                        Console.WriteLine("Bad data!  Try again")
                End Select
            Loop While Not userDone
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        Finally
            invDAL.CloseConnection()
        End Try

    End Sub
#Region "Show instructions"
    Private Sub ShowInstructions()
        Console.WriteLine("I: Inserts a new car.")
        Console.WriteLine("U: Updates an existing car.")
        Console.WriteLine("D: Deletes an existing car.")
        Console.WriteLine("L: Lists current inventory.")
        Console.WriteLine("S: Shows these instructions.")
        Console.WriteLine("P: Looks up pet name.")
        Console.WriteLine("Q: Quits program.")
    End Sub

#End Region

#Region "List inventory"
    Private Sub ListInventory(ByVal invDAL As InventoryDAL)
        ' Get the list of inventory.
        Dim dt As DataTable = invDAL.GetAllInventoryAsDataTable()
        DisplayTable(dt)
    End Sub

    Private Sub ListInventoryViaList(ByVal invDAL As InventoryDAL)
        ' Get the list of inventory.
        Dim record As List(Of NewCar) = invDAL.GetAllInventoryAsList()

        For Each c As NewCar In record
            Console.WriteLine("CarID: {0}, Make: {1}, Color: {2}, PetName: {3}", c.CarID, c.Make, c.Color, c.PetName)
        Next
    End Sub

    Private Sub DisplayTable(ByVal dt As DataTable)
        ' Print out the column names.
        For curCol As Integer = 0 To dt.Columns.Count - 1
            Console.Write(dt.Columns(curCol).ColumnName & vbTab)
        Next
        Console.WriteLine(vbLf & "----------------------------------")

        ' Print the DataTable.
        For curRow As Integer = 0 To dt.Rows.Count - 1
            For curCol As Integer = 0 To dt.Columns.Count - 1
                Console.Write(dt.Rows(curRow)(curCol).ToString() & vbTab)
            Next
            Console.WriteLine()
        Next curRow
    End Sub

#End Region

#Region "Delete car"
    Private Sub DeleteCar(ByVal invDAL As InventoryDAL)
        ' Get ID of car to delete.
        Console.Write("Enter ID of Car to delete: ")
        Dim id As Integer = Integer.Parse(Console.ReadLine())

        ' Just in case we have a primary key
        ' violation!
        Try
            invDAL.DeleteCar(id)
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try
    End Sub
#End Region

#Region "Insert car"
    Private Sub InsertNewCar(ByVal invDAL As InventoryDAL)
        ' First get the user data.
        Dim newCarID As Integer
        Dim newCarColor, newCarMake, newCarPetName As String

        Console.Write("Enter Car ID: ")
        newCarID = Integer.Parse(Console.ReadLine())
        Console.Write("Enter Car Color: ")
        newCarColor = Console.ReadLine()
        Console.Write("Enter Car Make: ")
        newCarMake = Console.ReadLine()
        Console.Write("Enter Pet Name: ")
        newCarPetName = Console.ReadLine()

        ' Now pass to data access library.
        ' invDAL.InsertAuto(newCarID, newCarColor, newCarMake, newCarPetName);
        Dim c As NewCar = New NewCar With {.CarID = newCarID, .Color = newCarColor, .Make = newCarMake, .PetName = newCarPetName}
        invDAL.InsertAuto(c)
    End Sub
#End Region

#Region "Update pet name"
    Private Sub UpdateCarPetName(ByVal invDAL As InventoryDAL)
        ' First get the user data.
        Dim carID As Integer
        Dim newCarPetName As String

        Console.Write("Enter Car ID: ")
        carID = Integer.Parse(Console.ReadLine())
        Console.Write("Enter New Pet Name: ")
        newCarPetName = Console.ReadLine()

        ' Now pass to data access library.
        invDAL.UpdateCarPetName(carID, newCarPetName)
    End Sub

#End Region

#Region "Look up name"
    Private Sub LookUpPetName(ByVal invDAL As InventoryDAL)
        ' Get ID of car to look up.
        Console.Write("Enter ID of Car to look up: ")
        Dim id As Integer = Integer.Parse(Console.ReadLine())
        Console.WriteLine("Petname of {0} is {1}.", id, invDAL.LookUpPetName(id))
    End Sub
#End Region
End Module
