﻿Imports System.Configuration

Imports System.Data
Imports System.Data.Common
Imports System.Data.SqlClient
Module Module1

    Sub Main()
        ' Get Connection string/provider from *.config.
        Console.WriteLine("***** Fun with Data Provider Factories *****" & vbLf)
        Dim dp As String = ConfigurationManager.AppSettings("provider")
        Dim cnStr As String = ConfigurationManager.ConnectionStrings("AutoLotSqlProvider").ConnectionString

        ' Get the factory provider.
        Dim df As DbProviderFactory = DbProviderFactories.GetFactory(dp)

        '			#Region "Use the factory!"
        ' Now make connection object.
        Using cn As DbConnection = df.CreateConnection()
            Console.WriteLine("Your connection object is a: {0}", cn.GetType().Name)
            cn.ConnectionString = cnStr
            cn.Open()
            If TypeOf cn Is SqlConnection Then
                ' Print out which version of SQL Server is used.
                Console.WriteLine((CType(cn, SqlConnection)).ServerVersion)
            End If

            ' Make command object.
            Dim cmd As DbCommand = df.CreateCommand()
            Console.WriteLine("Your command object is a: {0}", cmd.GetType().Name)
            cmd.Connection = cn
            cmd.CommandText = "Select * From Inventory"

            ' Print out data with data reader.              
            Using dr As DbDataReader = cmd.ExecuteReader()
                Console.WriteLine("Your data reader object is a: {0}", dr.GetType().Name)

                Console.WriteLine(vbLf & "***** Current Inventory *****")
                Do While dr.Read()
                    Console.WriteLine("-> Car #{0} is a {1}.", dr("CarID"), dr("Make").ToString())
                Loop
            End Using
        End Using
        '			#End Region

        Console.ReadLine()

    End Sub

End Module
