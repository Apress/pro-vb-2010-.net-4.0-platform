﻿Imports System.Data
Imports System.Data.SqlClient

Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Data Readers *****" & vbLf)

        ' Create a connection string via the builder object.
        Dim cnStrBuilder As New SqlConnectionStringBuilder()
        cnStrBuilder.InitialCatalog = "AutoLot"
        cnStrBuilder.DataSource = "(local)\SQLEXPRESS"
        cnStrBuilder.ConnectTimeout = 30
        cnStrBuilder.IntegratedSecurity = True

        ' Create an open a connection.
        Using cn As New SqlConnection()
            cn.ConnectionString = cnStrBuilder.ConnectionString
            cn.Open()
            ShowConnectionStatus(cn)

            ' Create a SQL command object.
            Dim strSQL As String = "Select * From Inventory;Select * from Customers"

            Using myCommand As New SqlCommand(strSQL, cn)

                ' Obtain a data reader a la ExecuteReader().
                Using myDataReader As SqlDataReader = myCommand.ExecuteReader()
                    Do
                        Do While myDataReader.Read()
                            Console.WriteLine("***** Record *****")
                            For i As Integer = 0 To myDataReader.FieldCount - 1
                                Console.WriteLine("{0} = {1}", myDataReader.GetName(i), myDataReader.GetValue(i).ToString())
                            Next
                            Console.WriteLine()
                        Loop
                    Loop While myDataReader.NextResult()
                End Using

            End Using
        End Using
        Console.ReadLine()

    End Sub
#Region "Helper function"
    Private Sub ShowConnectionStatus(ByVal cn As SqlConnection)
        ' Show various stats about current connection object.
        Console.WriteLine("***** Info about your connection *****")
        Console.WriteLine("Database location: {0}", cn.DataSource)
        Console.WriteLine("Database name: {0}", cn.Database)
        Console.WriteLine("Timeout: {0}", cn.ConnectionTimeout)
        Console.WriteLine("Connection state: {0}" & vbLf, cn.State.ToString())
    End Sub
#End Region

End Module
