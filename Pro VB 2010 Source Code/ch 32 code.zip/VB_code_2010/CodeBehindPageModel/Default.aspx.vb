﻿Imports AutoLotConnectedLayer

Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub btnFillData_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnFillData.Click
        Trace.Write("CodeFileTraceInfo!", "Filling the grid!")

        Dim dal As New InventoryDAL()
        dal.OpenConnection("Data Source=(local)\SQLEXPRESS;" & "Initial Catalog=AutoLot;Integrated Security=True")
        carsGridView.DataSource = dal.GetAllInventoryAsList()
        carsGridView.DataBind()
        dal.CloseConnection()
    End Sub
End Class
