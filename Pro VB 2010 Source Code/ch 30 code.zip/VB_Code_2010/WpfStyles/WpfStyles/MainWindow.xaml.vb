﻿Public Class MainWindow

    Public Sub New()
        InitializeComponent()

        ' Fill the list box with all the Button
        ' styles.
        lstStyles.Items.Add("GrowingButtonStyle")
        lstStyles.Items.Add("TiltButton")
        lstStyles.Items.Add("BigGreenButton")
        lstStyles.Items.Add("BasicControlStyle")
    End Sub

    Private Sub comboStyles_Changed(ByVal sender As Object, ByVal e As SelectionChangedEventArgs) Handles lstStyles.SelectionChanged
        ' Get the selected style name from the list box.     
        Dim currStyle As Style = CType(TryFindResource(lstStyles.SelectedValue), Style)

        If currStyle IsNot Nothing Then
            ' Set the style of the button type.
            Me.btnStyle.Style = currStyle
        End If
    End Sub

End Class
