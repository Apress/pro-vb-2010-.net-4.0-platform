﻿Public Class MainWindow

    ' An List of BitmapImage files.
    Private images As New List(Of BitmapImage)()

    ' Current position in the list.
    Private currImage As Integer = 0
    Private Const MAX_IMAGES As Integer = 2

    Private Sub btnNextImage_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnNextImage.Click
        currImage += 1
        If currImage > MAX_IMAGES Then
            currImage = 0
        End If
        imageHolder.Source = images(currImage)

    End Sub

    Private Sub btnPreviousImage_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnPreviousImage.Click
        currImage -= 1
        If currImage < 0 Then
            currImage = MAX_IMAGES
        End If
        imageHolder.Source = images(currImage)

    End Sub

    Private Sub Window_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles MyBase.Loaded
        Try
            'Dim path As String = Environment.CurrentDirectory

            'Load these images when the window loads. 
            'images.Add(New BitmapImage(New Uri(string.Format(@"{0}\Images\Deer.jpg", path))))
            'images.Add(New BitmapImage(New Uri(string.Format(@"{0}\Images\Dogs.jpg", path))))
            'images.Add(New BitmapImage(New Uri(string.Format(@"{0}\Images\Welcome.jpg", path))))

            images.Add(New BitmapImage(New Uri("/Images/Deer.jpg", UriKind.Relative)))
            images.Add(New BitmapImage(New Uri("/Images/Dogs.jpg", UriKind.Relative)))
            images.Add(New BitmapImage(New Uri("/Images/Welcome.jpg", UriKind.Relative)))

            imageHolder.Source = images(currImage)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

End Class
