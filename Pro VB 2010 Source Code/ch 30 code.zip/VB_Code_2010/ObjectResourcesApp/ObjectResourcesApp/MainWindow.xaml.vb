﻿Public Class MainWindow

    Private Sub btnOK_Click(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles btnOK.Click
        Resources("myBrush") = New SolidColorBrush(Colors.Red)
    End Sub

    Private Sub btnCancel_Click(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles btnCancel.Click
        Dim w As New TestWindow()
        w.Owner = Me
        w.WindowStartupLocation = WindowStartupLocation.CenterOwner
        w.ShowDialog()
    End Sub

End Class
