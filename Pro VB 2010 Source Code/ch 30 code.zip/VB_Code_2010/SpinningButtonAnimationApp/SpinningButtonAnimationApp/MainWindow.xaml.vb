﻿Imports System.Windows.Media.Animation

Public Class MainWindow
    Private isSpinning As Boolean = False

#Region "MouseEnter handler"
    Private Sub btnSpinner_MouseEnter(ByVal sender As Object, ByVal e As MouseEventArgs) Handles btnSpinner.MouseEnter
        If Not isSpinning Then
            isSpinning = True

            ' Make a double animation object, and register
            ' with the Completed event. 
            Dim dblAnim As New DoubleAnimation()
            AddHandler dblAnim.Completed, Sub(o, s) isSpinning = False

            ' Button has 4 seconds to finish the spin!
            dblAnim.Duration = New Duration(TimeSpan.FromSeconds(4))

            ' Set the start value and end value. 
            dblAnim.From = 0
            dblAnim.To = 360

            ' Now, create a RotateTransform object, and set 
            ' it to the RenderTransform property of our
            ' button
            Dim rt As New RotateTransform()
            btnSpinner.RenderTransform = rt

            ' Now, animation the RotateTransform object. 
            rt.BeginAnimation(RotateTransform.AngleProperty, dblAnim)
        End If
    End Sub
#End Region

#Region "Click handler"
    Private Sub btnSpinner_Click(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles btnSpinner.Click
        Dim dblAnim As New DoubleAnimation()
        dblAnim.From = 1.0
        dblAnim.To = 0.0

        ' Reverse when done.
        dblAnim.AutoReverse = True

        ' Loop forever.
        dblAnim.RepeatBehavior = RepeatBehavior.Forever
        btnSpinner.BeginAnimation(Button.OpacityProperty, dblAnim)
    End Sub
#End Region

End Class
