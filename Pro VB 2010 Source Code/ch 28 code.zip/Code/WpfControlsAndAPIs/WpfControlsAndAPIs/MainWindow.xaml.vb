﻿Imports System.Windows.Ink
Imports System.IO
Imports System.Windows.Annotations
Imports System.Windows.Annotations.Storage
Imports System.Windows.Markup
Imports AutoLotDAL.AutoLotDataSet
Imports WpfControlsAndAPIs.WpfControlsAndAPIs

''' <summary>
''' Interaction logic for MainWindow.xaml
''' </summary>
Public Class MainWindow
    Public Sub New()
        Me.InitializeComponent()

        ' Be in Ink mode by default.
        Me.myInkCanvas.EditingMode = InkCanvasEditingMode.Ink
        Me.inkRadio.IsChecked = True
        Me.comboColors.SelectedIndex = 0

        ' Populate document data.
        PopulateDocument()

        ' Enable annotation services.
        EnableAnnotations()

        ' Rig up some Click handlers for the save / load of the flow doc.
        AddHandler btnSaveDoc.Click, AddressOf SaveFlowDoc
        AddHandler btnLoadDoc.Click, AddressOf LoadFlowDoc
        SetBindings()
        ConfigureGrid()
    End Sub

#Region "Save and Load FlowDocument"
    Private Sub SaveFlowDoc()
        Using fStream As FileStream = File.Open("documentData.xaml", FileMode.Create)
            XamlWriter.Save(Me.myDocumentReader.Document, fStream)
        End Using
    End Sub

    Private Sub LoadFlowDoc()
        Using fStream As FileStream = File.Open("documentData.xaml", FileMode.Open)
            Try
                Dim doc As FlowDocument = TryCast(XamlReader.Load(fStream), FlowDocument)
                Me.myDocumentReader.Document = doc
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error Loading Doc!")
            End Try
        End Using
    End Sub
#End Region

    Private Sub ConfigureGrid()
        Using Dcontext As New AutoLotEntities()
            ' Build a LINQ query that gets back some data from the Inventory table. 
            Dim dataToShow = From c In context.Inventories _
             Select New With { _
              c.CarID, _
              c.Make, _
              c.Color, _
              c.PetName _
             }
            Me.gridInventory.ItemsSource = dataToShow
        End Using
    End Sub

    Private Sub SetBindings()
        ' Create a Binding object.
        Dim b As New Binding()

        ' Register the converter, source and path.
        b.Converter = New MyDoubleConverter()
        b.Source = Me.mySB
        b.Path = New PropertyPath("Value")

        ' Call the SetBinding method on the Label.
        Me.labelSBThumb.SetBinding(Label.ContentProperty, b)
    End Sub

#Region "Populate the doc!"
    Private Sub PopulateDocument()
        ' Add some data to the List item.
        Me.listOfFunFacts.FontSize = 14
        Me.listOfFunFacts.MarkerStyle = TextMarkerStyle.Circle
        Me.listOfFunFacts.ListItems.Add(New ListItem(New Paragraph(New Run("Fixed documents are for WYSIWYG print ready docs!"))))
        Me.listOfFunFacts.ListItems.Add(New ListItem(New Paragraph(New Run("The API supports tables and embedded figures!"))))
        Me.listOfFunFacts.ListItems.Add(New ListItem(New Paragraph(New Run("Flow documents are read only!"))))
        Me.listOfFunFacts.ListItems.Add(New ListItem(New Paragraph(New Run("BlockUIContainer allows you to embed WPF controls in the document!"))))

        ' Now add some data to the Paragraph.
        ' First part of sentence.
        Dim prefix As New Run("This paragraph was generated ")

        ' Middle of paragraph.
        Dim b As New Bold()
        Dim infix As New Run("dynamically")
        infix.Foreground = Brushes.Red
        infix.FontSize = 30
        b.Inlines.Add(infix)

        ' Last part of paragraph. 
        Dim suffix As New Run(" at runtime!")

        ' Now add each piece to the collection of inline elements
        ' of the Paragraph. 
        Me.paraBodyText.Inlines.Add(prefix)
        Me.paraBodyText.Inlines.Add(infix)
        Me.paraBodyText.Inlines.Add(suffix)
    End Sub
#End Region

    Private Sub EnableAnnotations()
        ' Create the AnnotationService object that works
        ' with our FlowDocumentReader.
        Dim anoService As New AnnotationService(myDocumentReader)

        ' Create a MemoryStream which will hold the annotations. 
        Dim anoStream As New MemoryStream()

        ' Now, create a XML-based store based on the MemoryStream.
        ' You could use this object to programmatically add, delete
        ' or find annotations. 
        Dim store As AnnotationStore = New XmlStreamStore(anoStream)

        ' Enable the annotation services.
        anoService.Enable(store)
    End Sub

    Private Sub RadioButtonClicked(ByVal sender As Object, ByVal e As System.Windows.RoutedEventArgs)
        ' Based on which button sent the event, place the InkCanvas in a unique
        ' mode of operation.
        Select Case TryCast(sender, RadioButton).Content.ToString()
            Case "Ink Mode!"
                Me.myInkCanvas.EditingMode = InkCanvasEditingMode.Ink
                Exit Select
            Case "Erase Mode!"
                Me.myInkCanvas.EditingMode = InkCanvasEditingMode.EraseByStroke
                Exit Select

            Case "Select Mode!"
                Me.myInkCanvas.EditingMode = InkCanvasEditingMode.[Select]
                Exit Select
        End Select
    End Sub

    Private Sub ColorChanged(ByVal sender As Object, ByVal e As System.Windows.Controls.SelectionChangedEventArgs)
        ' Get the Tag of the selected StackPanel.
        Dim colorToUse As String = TryCast(Me.comboColors.SelectedItem, ComboBoxItem).Content.ToString()

        ' Change the color used to render the strokes.
        Me.myInkCanvas.DefaultDrawingAttributes.Color = DirectCast(ColorConverter.ConvertFromString(colorToUse), Color)
    End Sub

#Region "Save, load and clear canvas data"
    Private Sub SaveData(ByVal sender As Object, ByVal e As System.Windows.RoutedEventArgs)
        ' Save all data on the InkCanvas to a local file.
        Using fs As New FileStream("StrokeData.bin", FileMode.Create)
            Me.myInkCanvas.Strokes.Save(fs)
            fs.Close()
        End Using
    End Sub

    Private Sub LoadData(ByVal sender As Object, ByVal e As System.Windows.RoutedEventArgs)
        ' Fill StrokeCollection from file.
        Using fs As New FileStream("StrokeData.bin", FileMode.Open, FileAccess.Read)
            Dim strokes As New StrokeCollection(fs)
            Me.myInkCanvas.Strokes = strokes
        End Using
    End Sub

    Private Sub Clear(ByVal sender As Object, ByVal e As System.Windows.RoutedEventArgs)
        ' Clear all strokes.
        Me.myInkCanvas.Strokes.Clear()
    End Sub
#End Region
End Class