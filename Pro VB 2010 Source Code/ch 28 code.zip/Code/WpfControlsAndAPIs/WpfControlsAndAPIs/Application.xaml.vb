﻿Imports System
Imports System.Collections.Generic
Imports System.Configuration
Imports System.Data
Imports System.Linq
Imports System.Windows

''' <summary>
''' Interaction logic for Application.xaml
''' </summary>
''' <remarks></remarks>
Class Application

End Class