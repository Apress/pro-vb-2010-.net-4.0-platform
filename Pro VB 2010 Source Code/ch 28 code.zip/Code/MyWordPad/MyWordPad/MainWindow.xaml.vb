﻿Imports Microsoft.Win32
Imports System.IO

''' <summary>
''' Interaction logic for Window1.xaml
''' </summary>
Public Class MainWindow
#Region "Menu Handlers"
    Protected Sub FileExit_Click(ByVal sender As Object, ByVal args As RoutedEventArgs)
        ' Close this window.
        Me.Close()
    End Sub

    Protected Sub ToolsSpellingHints_Click(ByVal sender As Object, ByVal args As RoutedEventArgs)
        Dim spellingHints As String = String.Empty

        ' Try to get a spelling error at the current caret location.
        Dim err As SpellingError = txtData.GetSpellingError(txtData.CaretIndex)
        If err IsNot Nothing Then
            ' Build a string of spelling suggestions.
            For Each s As String In err.Suggestions
                spellingHints &= String.Format("{0}" & vbLf, s)
            Next

            ' Show suggestions and expand the expander.
            lblSpellingHints.Content = spellingHints
            expanderSpelling.IsExpanded = True
        End If
    End Sub

    Protected Sub MouseEnterExitArea(ByVal sender As Object, ByVal args As RoutedEventArgs)
        statBarText.Text = "Exit the Application"
    End Sub

    Protected Sub MouseEnterToolsHintsArea(ByVal sender As Object, ByVal args As RoutedEventArgs)
        statBarText.Text = "Show Spelling Suggestions"
    End Sub

    Protected Sub MouseLeaveArea(ByVal sender As Object, ByVal args As RoutedEventArgs)
        statBarText.Text = "Ready"
    End Sub
#End Region

#Region "Logic for rigging up F1 help for the window"
    Private Sub SetF1CommandBinding()
        Dim helpBinding As New CommandBinding(ApplicationCommands.Help)
        AddHandler helpBinding.CanExecute, AddressOf CanHelpExecute
        AddHandler helpBinding.Executed, AddressOf HelpExecuted
        CommandBindings.Add(helpBinding)
    End Sub

    Private Sub CanHelpExecute(ByVal sender As Object, ByVal e As CanExecuteRoutedEventArgs)
        ' Here, you can set CanExecute to False if you wish to prevent the
        ' command from executing.
        e.CanExecute = True
    End Sub

    Private Sub HelpExecuted(ByVal sender As Object, ByVal e As ExecutedRoutedEventArgs)
        MessageBox.Show("Look, it is not that difficult.  Just type something!", "Help!")
    End Sub
#End Region

#Region "Logic for open / save"
    Private Sub OpenCmdCanExecute(ByVal sender As Object, ByVal e As CanExecuteRoutedEventArgs)
        e.CanExecute = True
    End Sub

    Private Sub SaveCmdCanExecute(ByVal sender As Object, ByVal e As CanExecuteRoutedEventArgs)
        e.CanExecute = True
    End Sub

    Private Sub OpenCmdExecuted(ByVal sender As Object, ByVal e As ExecutedRoutedEventArgs)
        ' Create an open file dialog box and only show XAML files. 
        Dim openDlg As New OpenFileDialog()
        openDlg.Filter = "Text Files |*.txt"

        ' Did they click on the OK button?
        If True = openDlg.ShowDialog() Then
            ' Load all text of selected file into a StringBuilder.
            Dim dataFromFile As String = File.ReadAllText(openDlg.FileName)

            ' Show modified string in TextBox.
            txtData.Text = dataFromFile
        End If
    End Sub

    Private Sub SaveCmdExecuted(ByVal sender As Object, ByVal e As ExecutedRoutedEventArgs)
        Dim saveDlg As New SaveFileDialog()
        saveDlg.Filter = "Text Files |*.txt"

        ' Did they click on the OK button?
        If True = saveDlg.ShowDialog() Then
            ' Save data in the TextBox to the named file.
            File.WriteAllText(saveDlg.FileName, txtData.Text)
        End If
    End Sub
#End Region
End Class
