﻿Imports System.ServiceModel
Imports MagicEightBallServiceLib

Module Module1

    Sub Main()
        Console.WriteLine("***** Console Based WCF Host *****")

        Using serviceHost_Renamed As New ServiceHost(GetType(MagicEightBallService))

            ' Open the host and start listening for incoming messages.
            serviceHost_Renamed.Open()
            DisplayHostInfo(serviceHost_Renamed)

            ' Keep the service running until Enter key is pressed.
            Console.WriteLine("The service is ready.")
            Console.WriteLine("Press the Enter key to terminate service.")
            Console.ReadLine()
        End Using
    End Sub

#Region "Show all the ABCs exposed from the host."
    Private Sub DisplayHostInfo(ByVal host As ServiceHost)
        Console.WriteLine()
        Console.WriteLine("***** Host Info *****")

        For Each se In host.Description.Endpoints
            Console.WriteLine("Address: {0}", se.Address)
            Console.WriteLine("Binding: {0}", se.Binding.Name)
            Console.WriteLine("Contract: {0}", se.Contract.Name)
            Console.WriteLine()
        Next
        Console.WriteLine("**********************")
    End Sub
#End Region

End Module

