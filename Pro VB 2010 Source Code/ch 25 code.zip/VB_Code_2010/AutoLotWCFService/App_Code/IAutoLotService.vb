﻿<ServiceContract>
Public Interface IAutoLotService
    <OperationContract()>
    Sub InsertCar(ByVal id As Integer, ByVal make As String, ByVal color As String, ByVal petname As String)

    <OperationContract(Name:="InsertCarWithDetails")>
    Sub InsertCar(ByVal car As InventoryRecord)

    <OperationContract()>
    Function GetInventory() As InventoryRecord()
End Interface

<DataContract()>
Public Class InventoryRecord
    <DataMember()>
    Public ID As Integer
    <DataMember()>
    Public Make As String
    <DataMember()>
    Public Color As String
    <DataMember()>
    Public PetName As String
End Class