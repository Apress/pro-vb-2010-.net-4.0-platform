﻿Imports MagicEightBallServiceClient.ServiceReference1

Module Module1

    Sub Main()
        Console.WriteLine("***** Ask the Magic 8 Ball *****" & vbLf)

        Using ball As New EightBallClient()
            Console.Write("Your question: ")
            Dim question As String = Console.ReadLine()
            Dim answer As String = ball.ObtainAnswerToQuestion(question)
            Console.WriteLine("8-Ball says: {0}", answer)
        End Using
        Console.ReadLine()

    End Sub

End Module
