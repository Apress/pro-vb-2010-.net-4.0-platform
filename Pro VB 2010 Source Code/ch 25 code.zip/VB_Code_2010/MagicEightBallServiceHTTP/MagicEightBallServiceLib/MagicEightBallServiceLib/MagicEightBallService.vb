﻿Public Class MagicEightBallService
    Implements IEightBall

    Public Sub New()
        Console.WriteLine("The 8-Ball awaits your question...")
    End Sub

    Public Function ObtainAnswerToQuestion(ByVal userQuestion As String) As String Implements IEightBall.ObtainAnswerToQuestion
        Dim answers() As String = {"Future Uncertain", "Yes", "No", "Hazy", "Ask again later", "Definitely"}

        ' Return a random response.
        Dim r As New Random()
        Return answers(r.Next(answers.Length))
    End Function
End Class
