﻿<ServiceContract(Namespace:="http://MyCompany.com")>
Public Interface IEightBall

    ' Ask a question, receive an answer!
    <OperationContract()>
    Function ObtainAnswerToQuestion(ByVal userQuestion As String) As String
End Interface

