﻿Imports System.ServiceModel
Imports MagicEightBallServiceLib

Module Module1

    Sub Main()
        Console.WriteLine("***** Console Based WCF Host *****")

        Using svcHost As New ServiceHost(GetType(MagicEightBallService))

            ' Open the host and start listening for incoming messages.
            svcHost.Open()
            DisplayHostInfo(svcHost)

            ' Keep the service running until Enter key is pressed.
            Console.WriteLine("The service is ready.")
            Console.WriteLine("Press the Enter key to terminate service.")
            Console.ReadLine()
        End Using
    End Sub

#Region "Show all the ABCs exposed from the host."
    Private Sub DisplayHostInfo(ByVal svcHost As ServiceHost)
        Console.WriteLine()
        Console.WriteLine("***** Host Info *****")

        For Each se In svcHost.Description.Endpoints
            Console.WriteLine("Address: {0}", se.Address)
            Console.WriteLine("Binding: {0}", se.Binding.Name)
            Console.WriteLine("Contract: {0}", se.Contract.Name)
            Console.WriteLine()
        Next
        Console.WriteLine("**********************")
    End Sub
#End Region

End Module

