﻿Imports MathClient.ServiceReference1
Imports System.Threading

Module Module1

    Sub Main()
        Console.WriteLine("***** The Async Math Client *****" & vbLf)

        Using proxy As New BasicMathClient()
            proxy.Open()

            ' Add numbers in an async manner, using lambda expression
            Dim result As IAsyncResult = proxy.BeginAdd(2, 3, Sub(ar) Console.WriteLine("2 + 3 = {0}", proxy.EndAdd(ar)), Nothing)

            While Not result.IsCompleted
                Thread.Sleep(200)
                Console.WriteLine("Client working...")
            End While
        End Using
        Console.ReadLine()
    End Sub

End Module
