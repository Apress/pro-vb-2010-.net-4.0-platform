﻿Public Class MathService
    Implements IBasicMath

    Public Function Add(ByVal x As Integer, ByVal y As Integer) As Integer Implements IBasicMath.Add
        ' To simulate a lengthy request. 
        System.Threading.Thread.Sleep(5000)
        Return x + y
    End Function


End Class
