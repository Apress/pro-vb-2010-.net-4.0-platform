﻿' Be sure to import these namespaces:
Imports MathServiceLibrary
Imports System.ServiceModel

Public Class MathWinService

    ' A member variable of type ServiceHost.
    Private myHost As ServiceHost

    Protected Overrides Sub OnStart(ByVal args() As String)
        If myHost IsNot Nothing Then
            myHost.Close()
        End If

        ' Create the host and specify a URL for an HTTP binding.
        myHost = New ServiceHost(GetType(MathService), New Uri("http://localhost:8080/MathServiceLibrary"))
        myHost.AddDefaultEndpoints()

        ' Open the host.
        myHost.Open()
    End Sub

    Protected Overrides Sub OnStop()
        ' Shut down the host.
        If myHost IsNot Nothing Then
            myHost.Close()
        End If
    End Sub

End Class
