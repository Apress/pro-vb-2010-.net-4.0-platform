﻿Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with System.GC *****")

        'Print out estimated number of bytes on heap.
        Console.WriteLine("Estimated bytes on heap: {0}", GC.GetTotalMemory(False))

        'MaxGeneration is zero based.
        Console.WriteLine("This OS has {0} object generations." & vbLf, (GC.MaxGeneration + 1))
        Dim refToMyCar As New Car("Zippy", 100)
        Console.WriteLine(refToMyCar.ToString())

        'Print out generation of refToMyCar.
        Console.WriteLine(vbLf & "Generation of refToMyCar is: {0}", GC.GetGeneration(refToMyCar))

        'Make a ton of objects for testing purposes.
        Dim tonsOfObjects As Object() = New Object(49999) {}

        For i = 0 To 49999
            tonsOfObjects(i) = New Object()
        Next

        'Collect only gen 0 objects.
        GC.Collect(0, GCCollectionMode.Forced)
        GC.WaitForPendingFinalizers()

        'Print out generation of refToMyCar.
        Console.WriteLine("Generation of refToMyCar is: {0}", GC.GetGeneration(refToMyCar))

        'See if tonsOfObjects[9000] is still alive.
        If tonsOfObjects(9000).ToString() <> Nothing Then
            Console.WriteLine("Generation of tonsOfObjects[9000] is: {0}", GC.GetGeneration(tonsOfObjects(9000)))
        Else
            Console.WriteLine("tonsOfObjects[9000] is no longer alive.")
        End If

        'Print out how many times a generation has been swept.
        Console.WriteLine(vbLf & "Gen 0 has been swept {0} times", GC.CollectionCount(0))
        Console.WriteLine("Gen 1 has been swept {0} times", GC.CollectionCount(1))
        Console.WriteLine("Gen 2 has been swept {0} times", GC.CollectionCount(2))
        Console.ReadLine()
    End Sub

    Sub MakeACar()
        'If myCar is the only reference to the Car object,
        ' it *may* be destroyed when this method returns.
        Dim myCar As New Car()
        myCar = Nothing
    End Sub

End Module
