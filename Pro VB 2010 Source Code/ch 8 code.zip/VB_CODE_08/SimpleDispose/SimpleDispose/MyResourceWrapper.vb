﻿'Implementing IDisposable.
Public Class MyResourceWrapper
    Implements IDisposable
    'The object user should call this method
    'when they finish with the Object.

    Public Sub Dispose() Implements IDisposable.Dispose
        'Clean up unmanaged resources...
        'Dispose other contained disposable objects...
        'Just for a test.
        Console.WriteLine("***** In Dispose! *****")
    End Sub
End Class

