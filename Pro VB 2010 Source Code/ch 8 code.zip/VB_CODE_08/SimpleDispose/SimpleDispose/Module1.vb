﻿Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Dispose *****")
        ' Use a comma-delimited list to declare multiple objects to dispose.
        Using rw As New MyResourceWrapper(), rw2 As New MyResourceWrapper()
            'Use rw and rw2 objects.
        End Using
       
    End Sub

End Module
