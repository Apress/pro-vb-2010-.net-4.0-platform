﻿Module Module1
#Region "classes to represent a song and all songs."
    'Represents a single song. 
    Public Class Song
        Public Property Artist() As String
        Public Property TrackName() As String
        Public Property TrackLength() As Double
    End Class

    'Represents all songs on a player.
    Public Class AllTracks
        'Our media player can have a maximum
        'of 10,000 songs.
        Private allSongs As Song() = New Song(10000) {}

        Public Sub New()
            'Assume we fill up the array
            'of Song objects here.
            Console.WriteLine("Filling up the songs!")
        End Sub

    End Class
#End Region

#Region "Media player class"
    'The MediaPlayer has-a AllTracks object.
    Public Class MediaPlayer
        'Assume these methods do something useful.
        Public Sub Play()
            ' Play a song 
        End Sub

        Public Sub Pause()
            'Pause the song 
        End Sub

        Public Sub [Stop]()
            'Stop playback
        End Sub

        'Use a Lambda expression to add additional code
        'when the AllTracks Object is made.
        Private allSongs As New Lazy(Of AllTracks)(Function()
                                                       Console.WriteLine("Creating AllTracks object!")
                                                       Return New AllTracks()
                                                   End Function)
        Public Function GetAllTracks() As AllTracks
            'Return all of the songs.
            Return allSongs.Value
        End Function
    End Class
#End Region

    Sub Main()
        Console.WriteLine("***** Fun with Lazy Instantiation *****")
        Dim myPlayer As New MediaPlayer()
        myPlayer.Play()
        Dim yourPlayer As New MediaPlayer()
        Dim yourMusic As AllTracks = yourPlayer.GetAllTracks()
        Console.ReadLine()
    End Sub

End Module
