﻿Module Module1

    Sub Main()
        Console.WriteLine("***** Dispose()  Platter *****")

        '// Call Dispose() manually, this will not call the finalizer.
        Dim rw As New MyResourceWrapper()
        rw.Dispose()

        'Don't call Dispose(), this will trigger the finalizer
        'and cause a beep.
        Dim rw2 As New MyResourceWrapper()
        Console.ReadLine()
    End Sub

End Module
