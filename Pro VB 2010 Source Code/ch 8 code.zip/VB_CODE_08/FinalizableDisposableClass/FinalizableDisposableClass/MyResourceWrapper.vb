﻿Public Class MyResourceWrapper
    Implements IDisposable
    'Used to determine if Dispose()
    'has already been called.
    Private disposed As Boolean = False

    Public Sub Dispose() Implements IDisposable.Dispose
        'Call our helper method.
        'Specifying "True" signifies that
        ' the object user triggered the cleanup.
        CleanUp(True)
        'Now suppress finalization.
        GC.SuppressFinalize(Me)
    End Sub

    Private Sub CleanUp(ByVal disposing As Boolean)
        'Be sure we have not already been disposed!
        If Not Me.disposed Then
            'If disposing equals True, dispose all
            'managed resources.
            If disposing Then
                'Dispose managed resources.
            End If
            'Clean up unmanaged resources here.
        End If
        disposed = True
    End Sub

    Protected Overrides Sub Finalize()
        Try
            Console.Beep()
            'Call our helper method.
            'Specifying "False" signifies that
            'the GC triggered the cleanup.
            CleanUp(False)
        Finally
            MyBase.Finalize()
        End Try
    End Sub
End Class
