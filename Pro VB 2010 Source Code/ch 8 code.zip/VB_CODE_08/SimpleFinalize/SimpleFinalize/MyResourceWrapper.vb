﻿Public Class MyResourceWrapper
    Protected Overrides Sub Finalize()
        Try
            'Clean up unmanaged resources here.
            ' Beep when destroyed (testing purposes only!)
            Console.Beep()
        Finally
            MyBase.Finalize()
        End Try
    End Sub
End Class
