﻿Partial Class AutoLotDataSet
End Class
