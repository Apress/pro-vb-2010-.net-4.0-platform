﻿Partial Class InventoryDataSet
    Partial Class InventoryDataTable

    End Class

End Class
