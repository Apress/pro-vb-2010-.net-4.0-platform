﻿Public Class MainForm

    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'InventoryDataSet.Inventory' table. You can move, or remove it, as needed.
        Me.InventoryTableAdapter.Fill(Me.InventoryDataSet.Inventory)

    End Sub

    Private Sub btnUpdateInventory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateInventory.Click
        Try
            ' Save changes with the Inventory table back to the database.    
            Me.InventoryTableAdapter.Update(Me.InventoryDataSet.Inventory)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        ' Get fresh copy for grid.
        Me.InventoryTableAdapter.Fill(Me.InventoryDataSet.Inventory)

    End Sub
End Class
