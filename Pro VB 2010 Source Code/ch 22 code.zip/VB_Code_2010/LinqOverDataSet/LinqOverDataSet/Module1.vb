﻿' Location of strongly typed data containers.
Imports AutoLotDataSetTableAdapters

Module Module1

    Sub Main()
        Console.WriteLine("***** LINQ over DataSet *****" & vbLf)

        ' Get a strongly typed DataTable containing the current Inventory
        ' of the AutoLot database.
        Dim dal As New AutoLotDataSet()
        Dim da As New InventoryTableAdapter()
        Dim data As AutoLotDataSet.InventoryDataTable = da.GetData()

        ' Print all car ids.
        PrintAllCarIDs(data)
        Console.WriteLine()

        ' Show all red cars.
        ShowRedCars(data)
        Console.WriteLine()

        BuildDataTableFromQuery(data)
        Console.WriteLine()
        Console.ReadLine()
    End Sub

#Region "Print all Car IDs."
    Private Sub PrintAllCarIDs(ByVal data As DataTable)
        ' Get enumerable version of DataTable.
        Dim enumData As EnumerableRowCollection = data.AsEnumerable()

        ' Print the car ID values.
        For Each r As DataRow In enumData
            Console.WriteLine("Car ID = {0}", r("CarID"))
        Next
    End Sub
#End Region

#Region "Show red cars"
    Private Sub ShowRedCars(ByVal data As DataTable)
        ' Project a new result set containing
        ' the ID/Make for rows where Color = Red.        
        Dim cars = From car In data.AsEnumerable()
                   Where car.Field(Of String)("Color").Trim() = "Red"
                   Select New With {
                       .ID = car.Field(Of Integer)("CarID"),
                       .Make = car.Field(Of String)("Make")}


        Console.WriteLine("Here are the red cars we have in stock:")
        For Each item In cars
            Console.WriteLine("-> CarID = {0} is {1}", item.ID, item.Make)
        Next
    End Sub
#End Region

#Region "DataTable from Query"
    Private Sub BuildDataTableFromQuery(ByVal data As DataTable)
        Dim cars = From car In data.AsEnumerable()
                   Where car.Field(Of Integer)("CarID") > 5
                   Select car

        ' Use this result set to build a new DataTable.
        Dim newTable As DataTable = cars.CopyToDataTable()

        ' Print the DataTable.
        For curRow As Integer = 0 To newTable.Rows.Count - 1
            For curCol As Integer = 0 To newTable.Columns.Count - 1
                Console.Write(newTable.Rows(curRow)(curCol).ToString().Trim() & vbTab)
            Next
            Console.WriteLine()
        Next curRow
    End Sub
#End Region

End Module
