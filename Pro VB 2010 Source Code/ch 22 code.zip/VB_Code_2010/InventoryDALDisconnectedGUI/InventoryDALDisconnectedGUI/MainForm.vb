﻿Imports AutoLotDisconnectedLayer

Public Class MainForm
    Dim dal As InventoryDALDisLayer = Nothing

    Public Sub New()
        InitializeComponent()

        Dim cnStr As String = "Data Source=(local)\SQLEXPRESS;Initial Catalog=AutoLot;" & "Integrated Security=True;Pooling=False"

        ' Create our data access object.
        dal = New InventoryDALDisLayer(cnStr)

        ' Fill up our grid!
        inventoryGrid.DataSource = dal.GetAllInventory()
    End Sub
#Region "Update click logic"
    Private Sub btnUpdateInventory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateInventory.Click
        ' Get modified data from the grid.
        Dim changedDT As DataTable = CType(inventoryGrid.DataSource, DataTable)

        Try
            ' Commit our changes. 
            dal.UpdateInventory(changedDT)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub
#End Region
End Class
