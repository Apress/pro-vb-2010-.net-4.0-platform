﻿Imports System.Data.SqlClient
Imports System.Data.Common

Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Data Adapters *****" & vbLf)

        ' Hard-coded connection string.
        Dim cnStr As String = "Integrated Security = SSPI;Initial Catalog=AutoLot;" & "Data Source=(local)\SQLEXPRESS"

        ' Caller creates the DataSet object.
        Dim ds As New DataSet("AutoLot")

        ' Inform adapter of the Select command text and connection.
        Dim dAdapt As New SqlDataAdapter("Select * From Inventory", cnStr)

        ' Now map DB column names to user-friendly names. 
        Dim custMap As DataTableMapping = dAdapt.TableMappings.Add("Inventory", "Current Inventory")
        custMap.ColumnMappings.Add("CarID", "Car ID")
        custMap.ColumnMappings.Add("PetName", "Name of Car")
        dAdapt.Fill(ds, "Inventory")

        ' Display contents of DataSet.
        PrintDataSet(ds)
        Console.ReadLine()

    End Sub
#Region "Print out data "
    Private Sub PrintDataSet(ByVal ds As DataSet)
        ' Print out any name and extended properties. 
        Console.WriteLine("DataSet is named: {0}", ds.DataSetName)
        For Each de As System.Collections.DictionaryEntry In ds.ExtendedProperties
            Console.WriteLine("Key = {0}, Value = {1}", de.Key, de.Value)
        Next
        Console.WriteLine()

        For Each dt As DataTable In ds.Tables
            Console.WriteLine("=> {0} Table:", dt.TableName)

            ' Print out the column names.
            For curCol As Integer = 0 To dt.Columns.Count - 1
                Console.Write(dt.Columns(curCol).ColumnName & vbTab)
            Next
            Console.WriteLine(vbLf & "----------------------------------")

            ' Print the DataTable.
            For curRow As Integer = 0 To dt.Rows.Count - 1
                For curCol As Integer = 0 To dt.Columns.Count - 1
                    Console.Write(dt.Rows(curRow)(curCol).ToString().Trim() & vbTab)
                Next
                Console.WriteLine()
            Next
        Next
    End Sub
#End Region

End Module
