﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.dataGridViewInventory = New System.Windows.Forms.DataGridView()
        Me.dataGridViewCustomers = New System.Windows.Forms.DataGridView()
        Me.dataGridViewOrders = New System.Windows.Forms.DataGridView()
        Me.btnUpdateDatabase = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnGetOrderInfo = New System.Windows.Forms.Button()
        Me.txtCustID = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        CType(Me.dataGridViewInventory, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dataGridViewCustomers, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dataGridViewOrders, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(27, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Current Inventory"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(27, 163)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(93, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Current Customers"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(27, 297)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(75, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Current Orders"
        '
        'dataGridViewInventory
        '
        Me.dataGridViewInventory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dataGridViewInventory.Location = New System.Drawing.Point(30, 29)
        Me.dataGridViewInventory.Name = "dataGridViewInventory"
        Me.dataGridViewInventory.Size = New System.Drawing.Size(451, 102)
        Me.dataGridViewInventory.TabIndex = 3
        '
        'dataGridViewCustomers
        '
        Me.dataGridViewCustomers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dataGridViewCustomers.Location = New System.Drawing.Point(30, 179)
        Me.dataGridViewCustomers.Name = "dataGridViewCustomers"
        Me.dataGridViewCustomers.Size = New System.Drawing.Size(451, 102)
        Me.dataGridViewCustomers.TabIndex = 4
        '
        'dataGridViewOrders
        '
        Me.dataGridViewOrders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dataGridViewOrders.Location = New System.Drawing.Point(30, 313)
        Me.dataGridViewOrders.Name = "dataGridViewOrders"
        Me.dataGridViewOrders.Size = New System.Drawing.Size(451, 102)
        Me.dataGridViewOrders.TabIndex = 5
        '
        'btnUpdateDatabase
        '
        Me.btnUpdateDatabase.Location = New System.Drawing.Point(375, 440)
        Me.btnUpdateDatabase.Name = "btnUpdateDatabase"
        Me.btnUpdateDatabase.Size = New System.Drawing.Size(106, 23)
        Me.btnUpdateDatabase.TabIndex = 6
        Me.btnUpdateDatabase.Text = "Update Database"
        Me.btnUpdateDatabase.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnGetOrderInfo)
        Me.GroupBox1.Controls.Add(Me.txtCustID)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Location = New System.Drawing.Point(30, 440)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(241, 105)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Lookup Customer Order"
        '
        'btnGetOrderInfo
        '
        Me.btnGetOrderInfo.Location = New System.Drawing.Point(89, 76)
        Me.btnGetOrderInfo.Name = "btnGetOrderInfo"
        Me.btnGetOrderInfo.Size = New System.Drawing.Size(99, 23)
        Me.btnGetOrderInfo.TabIndex = 5
        Me.btnGetOrderInfo.Text = "Get Order Details"
        Me.btnGetOrderInfo.UseVisualStyleBackColor = True
        '
        'txtCustID
        '
        Me.txtCustID.Location = New System.Drawing.Point(89, 37)
        Me.txtCustID.Name = "txtCustID"
        Me.txtCustID.Size = New System.Drawing.Size(129, 20)
        Me.txtCustID.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 44)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Customer ID"
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(520, 550)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnUpdateDatabase)
        Me.Controls.Add(Me.dataGridViewOrders)
        Me.Controls.Add(Me.dataGridViewCustomers)
        Me.Controls.Add(Me.dataGridViewInventory)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "MainForm"
        Me.Text = "AutoLot Database Manipulator"
        CType(Me.dataGridViewInventory, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dataGridViewCustomers, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dataGridViewOrders, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents dataGridViewInventory As System.Windows.Forms.DataGridView
    Friend WithEvents dataGridViewCustomers As System.Windows.Forms.DataGridView
    Friend WithEvents dataGridViewOrders As System.Windows.Forms.DataGridView
    Friend WithEvents btnUpdateDatabase As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btnGetOrderInfo As System.Windows.Forms.Button
    Friend WithEvents txtCustID As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label

End Class
