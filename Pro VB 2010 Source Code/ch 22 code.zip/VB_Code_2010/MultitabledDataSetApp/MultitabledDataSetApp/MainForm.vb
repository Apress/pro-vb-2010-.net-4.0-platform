﻿Imports System.Data.SqlClient
Imports System.Configuration

Public Class MainForm
    ' Form wide DataSet.
    Dim autoLotDS As New DataSet("AutoLot")

    ' Make use of command builders to simplify data adapter configuration.
    Dim sqlCBInventory As SqlCommandBuilder
    Dim sqlCBCustomers As SqlCommandBuilder
    Dim sqlCBOrders As SqlCommandBuilder

    ' Our data adapters (for each table).
    Dim invTableAdapter As SqlDataAdapter
    Dim custTableAdapter As SqlDataAdapter
    Dim ordersTableAdapter As SqlDataAdapter

    ' Form wide connection string.
    Dim cnStr As String = String.Empty

#Region "Ctor logic"
    
    Public Sub New()
        InitializeComponent()

        ' Get connection string.
        cnStr = ConfigurationManager.ConnectionStrings("AutoLotSqlProvider").ConnectionString

        ' Create adapters.
        invTableAdapter = New SqlDataAdapter("Select * from Inventory", cnStr)
        custTableAdapter = New SqlDataAdapter("Select * from Customers", cnStr)
        ordersTableAdapter = New SqlDataAdapter("Select * from Orders", cnStr)

        ' Autogenerate commands.
        sqlCBInventory = New SqlCommandBuilder(invTableAdapter)
        sqlCBOrders = New SqlCommandBuilder(ordersTableAdapter)
        sqlCBCustomers = New SqlCommandBuilder(custTableAdapter)

        ' Add tables to DS.
        invTableAdapter.Fill(autoLotDS, "Inventory")
        custTableAdapter.Fill(autoLotDS, "Customers")
        ordersTableAdapter.Fill(autoLotDS, "Orders")

        ' Build relations between tables.
        BuildTableRelationship()

        ' Bind to grids
        dataGridViewInventory.DataSource = autoLotDS.Tables("Inventory")
        dataGridViewCustomers.DataSource = autoLotDS.Tables("Customers")
        dataGridViewOrders.DataSource = autoLotDS.Tables("Orders")
    End Sub
#End Region

#Region "Build table relationships"
    Private Sub BuildTableRelationship()
        ' Create CustomerOrder data relation object.
        Dim dr As New DataRelation("CustomerOrder", autoLotDS.Tables("Customers").Columns("CustID"), autoLotDS.Tables("Orders").Columns("CustID"))
        autoLotDS.Relations.Add(dr)

        ' Create InventoryOrder data relation object.
        dr = New DataRelation("InventoryOrder", autoLotDS.Tables("Inventory").Columns("CarID"), autoLotDS.Tables("Orders").Columns("CarID"))
        autoLotDS.Relations.Add(dr)
    End Sub
#End Region
#Region "Update Tables"
    Private Sub btnUpdateDatabase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateDatabase.Click
        Try
            invTableAdapter.Update(autoLotDS, "Inventory")
            custTableAdapter.Update(autoLotDS, "Customers")
            ordersTableAdapter.Update(autoLotDS, "Orders")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub
#End Region
#Region "Get Order Details"
    Private Sub btnGetOrderInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetOrderInfo.Click
        Dim strOrderInfo As String = String.Empty
        Dim drsCust() As DataRow = Nothing
        Dim drsOrder() As DataRow = Nothing

        ' Get the customer ID in the text box.
        Dim custID As Integer = Integer.Parse(Me.txtCustID.Text)

        ' Now based on custID, get the correct row in Customers table.
        drsCust = autoLotDS.Tables("Customers").Select(String.Format("CustID = {0}", custID))
        strOrderInfo &= String.Format("Customer {0}: {1} {2}" & vbLf, drsCust(0)("CustID").ToString(), drsCust(0)("FirstName").ToString().Trim(), drsCust(0)("LastName").ToString().Trim())

        ' Navigate from customer table to order table.
        drsOrder = drsCust(0).GetChildRows(autoLotDS.Relations("CustomerOrder"))

        ' Loop through all orders for this customer.
        For Each order As DataRow In drsOrder
            strOrderInfo &= String.Format("----" & vbLf & "Order Number: {0}" & vbLf, order("OrderID"))

            ' Get the car referenced by this order.
            Dim drsInv() As DataRow = order.GetParentRows(autoLotDS.Relations("InventoryOrder"))

            ' Get info for (SINGLE) car info for this order.
            Dim car As DataRow = drsInv(0)
            strOrderInfo &= String.Format("Make: {0}" & vbLf, car("Make"))
            strOrderInfo &= String.Format("Color: {0}" & vbLf, car("Color"))
            strOrderInfo &= String.Format("Pet Name: {0}" & vbLf, car("PetName"))
        Next order

        MessageBox.Show(strOrderInfo, "Order Details")

    End Sub
#End Region
End Class
