﻿Imports AutoLotDataSetTableAdapters
Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Strongly Typed DataSets *****" & vbLf)

        ' Caller creates the DataSet object.
        Dim table As New AutoLotDataSet.InventoryDataTable()

        ' Inform adapter of the Select command text and connection.
        Dim dAdapt As New InventoryTableAdapter()

        ' Fill our DataSet with a new table, named Inventory.
        dAdapt.Fill(table)
        PrintInventory(table)
        Console.WriteLine()

        ' Add rows, update and reprint. 
        AddRecords(table, dAdapt)
        table.Clear()
        dAdapt.Fill(table)
        PrintInventory(table)
        Console.WriteLine()

        ' Remove rows we just made and reprint.
        RemoveRecords(table, dAdapt)
        table.Clear()
        dAdapt.Fill(table)
        PrintInventory(table)
        Console.WriteLine()

        CallStoredProc()
        Console.ReadLine()

    End Sub
#Region "Remove records"
    Private Sub RemoveRecords(ByVal tb As AutoLotDataSet.InventoryDataTable, ByVal dAdapt As InventoryTableAdapter)
        Dim rowToDelete As AutoLotDataSet.InventoryRow = tb.FindByCarID(999)
        dAdapt.Delete(rowToDelete.CarID, rowToDelete.Make, rowToDelete.Color, rowToDelete.PetName)
        rowToDelete = tb.FindByCarID(888)
        dAdapt.Delete(rowToDelete.CarID, rowToDelete.Make, rowToDelete.Color, rowToDelete.PetName)
    End Sub
#End Region

#Region "Print the table data."
    Private Sub PrintInventory(ByVal dt As AutoLotDataSet.InventoryDataTable)
        ' Print out the column names.
        For curCol As Integer = 0 To dt.Columns.Count - 1
            Console.Write(dt.Columns(curCol).ColumnName & vbTab)
        Next
        Console.WriteLine(vbLf & "----------------------------------")

        ' Print the DataTable.
        For curRow As Integer = 0 To dt.Rows.Count - 1
            For curCol As Integer = 0 To dt.Columns.Count - 1
                Console.Write(dt.Rows(curRow)(curCol).ToString() & vbTab)
            Next
            Console.WriteLine()
        Next curRow
    End Sub
#End Region

#Region "Add records."
    Public Sub AddRecords(ByVal tb As AutoLotDataSet.InventoryDataTable, ByVal dAdapt As InventoryTableAdapter)
        ' Get a new strongly typed row from the table.
        Dim newRow As AutoLotDataSet.InventoryRow = tb.NewInventoryRow()

        ' Fill row with some sample data.
        newRow.CarID = 999
        newRow.Color = "Purple"
        newRow.Make = "BMW"
        newRow.PetName = "Saku"

        ' Insert the new row.
        tb.AddInventoryRow(newRow)

        ' Add one more row, using overloaded Add method.
        tb.AddInventoryRow(888, "Yugo", "Green", "Zippy")

        ' Update database.
        dAdapt.Update(tb)
    End Sub
#End Region

#Region "Call stored proc."
    Public Sub CallStoredProc()
        Dim q As New QueriesTableAdapter()
        Console.Write("Enter ID of car to look up: ")
        Dim carID As String = Console.ReadLine()
        Dim carName As String = ""
        q.GetPetName(Integer.Parse(carID), carName)
        Console.WriteLine("CarID {0} has the name of {1}", carID, carName)
    End Sub
#End Region

End Module
