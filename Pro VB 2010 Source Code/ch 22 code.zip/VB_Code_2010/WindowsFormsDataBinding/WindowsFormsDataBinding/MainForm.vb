﻿Public Class MainForm
    ' A collection of Car objects.
    Dim listCars As New List(Of Car)()

    ' Inventory information
    Dim inventoryTable As New DataTable()

    ' View of the DataTable.
    Dim yugosOnlyView As DataView

    Public Sub New()
        InitializeComponent()

        ' Fill the list with some cars.
        listCars = New List(Of Car) From {
         New Car With {.ID = 100, .PetName = "Chucky", .Make = "BMW", .Color = "Green"},
         New Car With {.ID = 101, .PetName = "Tiny", .Make = "Yugo", .Color = "White"},
         New Car With {.ID = 102, .PetName = "Ami", .Make = "Jeep", .Color = "Tan"},
         New Car With {.ID = 103, .PetName = "Pain Inducer", .Make = "Caravan", .Color = "Pink"},
         New Car With {.ID = 104, .PetName = "Fred", .Make = "BMW", .Color = "Green"},
         New Car With {.ID = 105, .PetName = "Sidd", .Make = "BMW", .Color = "Black"},
         New Car With {.ID = 106, .PetName = "Mel", .Make = "Firebird", .Color = "Red"},
         New Car With {.ID = 107, .PetName = "Sarah", .Make = "Colt", .Color = "Black"}}

        CreateDataTable()

        ' Make a view.
        CreateDataView()

    End Sub

#Region "Create the data table"
    Private Sub CreateDataTable()
        ' Create table schema.
        Dim carIDColumn As New DataColumn("ID", GetType(Integer))
        Dim carMakeColumn As New DataColumn("Make", GetType(String))
        Dim carColorColumn As New DataColumn("Color", GetType(String))
        Dim carPetNameColumn As New DataColumn("PetName", GetType(String))
        carPetNameColumn.Caption = "Pet Name"
        inventoryTable.Columns.AddRange(New DataColumn() {carIDColumn, carMakeColumn, carColorColumn, carPetNameColumn})

        ' Iterate over the array list to make rows.
        For Each c As Car In listCars
            Dim newRow As DataRow = inventoryTable.NewRow()
            newRow("ID") = c.ID
            newRow("Make") = c.Make
            newRow("Color") = c.Color
            newRow("PetName") = c.PetName
            inventoryTable.Rows.Add(newRow)
        Next

        ' Bind the DataTable to the carInventoryGridView.
        carInventoryGridView.DataSource = inventoryTable
    End Sub
#End Region

#Region "Delete row"
    Private Sub btnRemoveCar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemoveCar.Click

        Try
            ' Find the correct row to delete.
            Dim rowToDelete() As DataRow = inventoryTable.Select(String.Format("ID={0}", Integer.Parse(txtCarToRemove.Text)))

            ' Delete it!
            rowToDelete(0).Delete()
            inventoryTable.AcceptChanges()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
#End Region

#Region "Display petnames for makes"
    Private Sub btnDisplayMakes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisplayMakes.Click

        ' Build a filter based on user input.
        Dim filterStr As String = String.Format("Make= '{0}'", txtMakeToView.Text)

        ' Find all rows matching the filter.
        Dim makes() As DataRow = inventoryTable.Select(filterStr)

        ' Show what we got!
        If makes.Length = 0 Then
            MessageBox.Show("Sorry, no cars...", "Selection error!")
        Else
            Dim strMake As String = Nothing
            For i As Integer = 0 To makes.Length - 1
                strMake &= makes(i)("PetName") & vbLf
            Next
            ' Now show all matches in a message box.
            MessageBox.Show(strMake, String.Format("We have {0}s named:", txtMakeToView.Text))
        End If
    End Sub
#End Region

#Region "Change makes"
    ' Find the rows you want to edit with a filter.
    Private Sub btnChangeMakes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnChangeMakes.Click

        ' Make sure user has not lost his or her mind.
        If DialogResult.Yes = MessageBox.Show("Are you sure?? BMWs are much nicer than Yugos!", "Please Confirm!", MessageBoxButtons.YesNo) Then
            ' Build a filter.
            Dim filterStr As String = "Make='BMW'"
            Dim strMake As String = String.Empty

            ' Find all rows matching the filter.
            Dim makes() As DataRow = inventoryTable.Select(filterStr)

            ' Change all Beemers to Yugos!
            For i As Integer = 0 To makes.Length - 1
                makes(i)("Make") = "Yugo"
            Next
        End If
    End Sub
#End Region

#Region "Make a view"
    Private Sub CreateDataView()
        ' Set the table that is used to construct this view.
        yugosOnlyView = New DataView(inventoryTable)

        ' Now configure the views using a filter.
        yugosOnlyView.RowFilter = "Make = 'Yugo'"

        ' Bind to the new grid.
        dataGridYugosView.DataSource = yugosOnlyView
    End Sub
#End Region
End Class
