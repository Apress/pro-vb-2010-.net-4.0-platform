﻿Public Class Car
    Public Property ID() As Integer
    Public Property PetName() As String
    Public Property Make() As String
    Public Property Color() As String

End Class
