﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnChangeMakes = New System.Windows.Forms.Button()
        Me.carInventoryGridView = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnRemoveCar = New System.Windows.Forms.Button()
        Me.txtCarToRemove = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnDisplayMakes = New System.Windows.Forms.Button()
        Me.txtMakeToView = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dataGridYugosView = New System.Windows.Forms.DataGridView()
        CType(Me.carInventoryGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.dataGridYugosView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(37, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(233, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Here is what we have in stock"
        '
        'btnChangeMakes
        '
        Me.btnChangeMakes.Location = New System.Drawing.Point(384, 31)
        Me.btnChangeMakes.Name = "btnChangeMakes"
        Me.btnChangeMakes.Size = New System.Drawing.Size(138, 23)
        Me.btnChangeMakes.TabIndex = 1
        Me.btnChangeMakes.Text = "Change All BMWs to Yugos"
        Me.btnChangeMakes.UseVisualStyleBackColor = True
        '
        'carInventoryGridView
        '
        Me.carInventoryGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.carInventoryGridView.Location = New System.Drawing.Point(40, 72)
        Me.carInventoryGridView.Name = "carInventoryGridView"
        Me.carInventoryGridView.Size = New System.Drawing.Size(482, 162)
        Me.carInventoryGridView.TabIndex = 2
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnRemoveCar)
        Me.GroupBox1.Controls.Add(Me.txtCarToRemove)
        Me.GroupBox1.Location = New System.Drawing.Point(40, 253)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(217, 88)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Enter ID of Car to Delete"
        '
        'btnRemoveCar
        '
        Me.btnRemoveCar.Location = New System.Drawing.Point(130, 33)
        Me.btnRemoveCar.Name = "btnRemoveCar"
        Me.btnRemoveCar.Size = New System.Drawing.Size(75, 23)
        Me.btnRemoveCar.TabIndex = 1
        Me.btnRemoveCar.Text = "Delete!"
        Me.btnRemoveCar.UseVisualStyleBackColor = True
        '
        'txtCarToRemove
        '
        Me.txtCarToRemove.Location = New System.Drawing.Point(6, 35)
        Me.txtCarToRemove.Name = "txtCarToRemove"
        Me.txtCarToRemove.Size = New System.Drawing.Size(118, 20)
        Me.txtCarToRemove.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnDisplayMakes)
        Me.GroupBox2.Controls.Add(Me.txtMakeToView)
        Me.GroupBox2.Location = New System.Drawing.Point(277, 253)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(245, 88)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Make a View"
        '
        'btnDisplayMakes
        '
        Me.btnDisplayMakes.Location = New System.Drawing.Point(164, 35)
        Me.btnDisplayMakes.Name = "btnDisplayMakes"
        Me.btnDisplayMakes.Size = New System.Drawing.Size(75, 23)
        Me.btnDisplayMakes.TabIndex = 5
        Me.btnDisplayMakes.Text = "View!"
        Me.btnDisplayMakes.UseVisualStyleBackColor = True
        '
        'txtMakeToView
        '
        Me.txtMakeToView.Location = New System.Drawing.Point(18, 38)
        Me.txtMakeToView.Name = "txtMakeToView"
        Me.txtMakeToView.Size = New System.Drawing.Size(120, 20)
        Me.txtMakeToView.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(40, 359)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(94, 18)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Only Yugos"
        '
        'dataGridYugosView
        '
        Me.dataGridYugosView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dataGridYugosView.Location = New System.Drawing.Point(40, 380)
        Me.dataGridYugosView.Name = "dataGridYugosView"
        Me.dataGridYugosView.Size = New System.Drawing.Size(482, 97)
        Me.dataGridYugosView.TabIndex = 6
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(534, 486)
        Me.Controls.Add(Me.dataGridYugosView)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.carInventoryGridView)
        Me.Controls.Add(Me.btnChangeMakes)
        Me.Controls.Add(Me.Label1)
        Me.Name = "MainForm"
        Me.Text = "Windows Forms Data Binding"
        CType(Me.carInventoryGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.dataGridYugosView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnChangeMakes As System.Windows.Forms.Button
    Friend WithEvents carInventoryGridView As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btnRemoveCar As System.Windows.Forms.Button
    Friend WithEvents txtCarToRemove As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnDisplayMakes As System.Windows.Forms.Button
    Friend WithEvents txtMakeToView As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents dataGridYugosView As System.Windows.Forms.DataGridView

End Class
