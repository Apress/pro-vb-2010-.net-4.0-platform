﻿#Region "Shape base class"
'The MustInherit base class of the hierarchy.
Public MustInherit Class Shape

    Public Sub New()
        PetName = "NoName"
    End Sub
    Public Sub New(ByVal name As String)
        PetName = name
    End Sub
    'A single abstract method.
    Public MustOverride Sub Draw()
    Public Property PetName() As String
End Class
#End Region
#Region "Circle class"

' If we did not implement the MustOverride Draw() method, Circle would also be
' considered abstract, and would have to be marked MustInherit!
Public Class Circle
    Inherits Shape

    Public Sub New()
    End Sub

    Public Sub New(ByVal name As String)
        MyBase.New(name)
    End Sub

    Public Overrides Sub Draw()
        Console.WriteLine("Drawing {0} the Circle", PetName)
    End Sub
End Class
#End Region
#Region "Hexagon class"
'Hexagon DOES override Draw().
'Hexagon now implements IPointy and IDraw3D.

Public Class Hexagon
    Inherits Shape
    Implements IPointy
    Implements IDraw3D

    Public Sub New()
    End Sub

    Public Sub New(ByVal name As String)
        MyBase.New(name)
    End Sub

    Public Overrides Sub Draw()
        Console.WriteLine("Drawing {0} the Hexagon", PetName)
    End Sub

    ' IPointy Implementation.
    Public ReadOnly Property Points() As Byte Implements IPointy.Points
        Get
            Return 6
        End Get
    End Property

#Region "IDraw3D Members"
    Public Sub Draw3D() Implements IDraw3D.Draw3D
        Console.WriteLine("Drawing a 3D Hexagon")
    End Sub
#End Region
End Class
#End Region

#Region "ThreeDCircle class"
' This class extends Circle and hides the inherited Draw() method.
Public Class ThreeDCircle
    Inherits Circle
    Implements IDraw3D

    ' Hide any Draw() implementation above me.
    Public Shadows Sub Draw()
        Console.WriteLine("Drawing a 3D Circle")
    End Sub
    Public Shadows Property PetName() As String
#Region "IDraw3D Members"
    Public Sub Draw3D() Implements IDraw3D.Draw3D
        Console.WriteLine("Drawing Circle in 3D!")
    End Sub
#End Region
End Class
#End Region

#Region "Triangle"
'New Shape derived class named Triangle.
Public Class Triangle
    Inherits Shape
    Implements IPointy

    Public Sub New()
    End Sub

    Public Sub New(ByVal name As String)
        MyBase.New(name)
    End Sub

    Public Overrides Sub Draw()
        Console.WriteLine("Drawing {0} the Triangle", PetName)
    End Sub

    ' IPointy Implementation.
    Public ReadOnly Property Points() As Byte Implements IPointy.Points
        Get
            Return 3
        End Get
    End Property
End Class
#End Region