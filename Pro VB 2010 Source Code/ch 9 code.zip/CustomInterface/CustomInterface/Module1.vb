﻿Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Interfaces *****" & vbLf)
        'Make an array of Shapes.
        Dim myShapes As Shape() = {New Hexagon(), New Circle(), New Triangle("Joe"), New Circle("JoJo")}
        'Get first pointy item.
        Dim firstPointyItem As IPointy = FindFirstPointyShape(myShapes)
        Console.WriteLine("The item has {0} points", firstPointyItem.Points)

        For i = 0 To myShapes.Length - 1
            'Recall the Shape base class defines an MustOverride Draw()
            'member, so all shapes know how to draw themselves.
            myShapes(i).Draw()
            'Who's pointy?
            If TypeOf myShapes(i) Is IPointy Then
                Console.WriteLine("-> Points: {0}", (DirectCast(myShapes(i), IPointy)).Points)
            Else
                Console.WriteLine("-> {0}'s not pointy!", myShapes(i).PetName)
            End If
            'Can I draw you in 3D?
            If TypeOf myShapes(i) Is IDraw3D Then
                DrawIn3D(DirectCast(myShapes(i), IDraw3D))
            End If
            Console.WriteLine()

        Next
        ' This array can only contain types that
        ' implement the IPointy Interface.
        Dim myPointyObjects As IPointy() = {New Hexagon(), New Knife(), New Triangle(), New Fork(), New PitchFork()}
        For Each i As IPointy In myPointyObjects
            Console.WriteLine("Object has {0} points.", i.Points)
        Next
        Console.ReadLine()
    End Sub
    'I'll draw anyone supporting IDraw3D.
    Sub DrawIn3D(ByVal itf3d As IDraw3D)
        Console.WriteLine("-> Drawing IDraw3D compatible type")
        itf3d.Draw3D()
    End Sub
    'This method returns the first object in the
    'array that implements IPointy.

    Function FindFirstPointyShape(ByVal shapes As Shape()) As IPointy
        For Each s As Shape In shapes
            If TypeOf s Is IPointy Then
                Return TryCast(s, IPointy)
            End If
        Next
        Return Nothing
    End Function
End Module
