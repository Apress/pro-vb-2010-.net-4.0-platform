﻿Public Class PointyTestClass
    Implements IPointy


    Public ReadOnly Property Points() As Byte Implements IPointy.Points
        Get
            Throw New NotImplementedException()
        End Get
    End Property

End Class
