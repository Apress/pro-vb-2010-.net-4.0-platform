﻿' MyApp.xaml.vb
Imports System.Windows
Imports System.Windows.Controls

Namespace SimpleXamlApp

    Partial Public Class Application  

      Private Sub AppExit(ByVal sender As Object, ByVal e As ExitEventArgs)
            MessageBox.Show("App has exited")
      End Sub

    End Class

End Namespace

