﻿Class MainWindow 

    Private Sub btnExitApp_Clicked(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
        Me.Close()
    End Sub
End Class
