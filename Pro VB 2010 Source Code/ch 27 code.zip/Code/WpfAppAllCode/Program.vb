﻿' A simple WPF application, written without XAML.
Imports System
Imports System.Windows
Imports System.Windows.Controls

#Region "The Window"
Class MainWindow
    Inherits Window

    ' Our UI element.
    Private btnExitApp As New Button()

    Public Sub New(ByVal windowTitle As String, ByVal height As Integer, ByVal width As Integer)
        ' Configure button and set the child control.
        AddHandler btnExitApp.Click, AddressOf btnExitApp_Clicked
        btnExitApp.Content = "Exit Application"
        btnExitApp.Height = 25
        btnExitApp.Width = 100

        ' Set the content of this window to a single button.
        Content = btnExitApp

        ' Configure the window.
        Me.Title = windowTitle
        Me.WindowStartupLocation = WindowStartupLocation.CenterScreen
        Me.Height = height
        Me.Width = width

        AddHandler Me.Closing, AddressOf MainWindow_Closing
        AddHandler Me.Closed, AddressOf MainWindow_Closed
        AddHandler Me.MouseMove, AddressOf MainWindow_MouseMove
        AddHandler Me.KeyDown, AddressOf MainWindow_KeyDown
    End Sub

#Region "Event handlers"
    Private Sub btnExitApp_Clicked(ByVal sender As Object, ByVal e As RoutedEventArgs)
        ' Did user enable /godmode?
        If CBool(Application.Current.Properties("GodMode")) Then
            MessageBox.Show("Cheater!")
        End If

        Me.Close()
    End Sub

    Private Sub MainWindow_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs)
        ' See if the user really wants to shut down this window.
        Dim msg As String = "Do you want to close without saving?"
        Dim result As MessageBoxResult = MessageBox.Show(msg, "My App", MessageBoxButton.YesNo, MessageBoxImage.Warning)

        If result = MessageBoxResult.No Then
            ' If user doesn't want to close, cancel closure.
            e.Cancel = True
        End If
    End Sub

    Private Sub MainWindow_Closed(ByVal sender As Object, ByVal e As EventArgs)
        MessageBox.Show("See ya!")
    End Sub

    Private Sub MainWindow_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Input.MouseEventArgs)
        ' Set the title of the window to the current X,Y of the mouse.
        Me.Title = e.GetPosition(Me).ToString()
    End Sub

    Private Sub MainWindow_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Input.KeyEventArgs)
        ' Display key press on the button.
        btnExitApp.Content = e.Key.ToString()
    End Sub

#End Region
End Class
#End Region

Class Program
    Inherits Application

    <STAThread()> _
    Shared Sub Main(ByVal args As String())
        ' Handle the Startup and Exit events, and then run the application.
        Dim app As New Program()
        AddHandler app.Startup, AddressOf AppStartUp
        AddHandler app.Exit, AddressOf AppExit
        app.Run()
        ' Fires the Startup event.
    End Sub

#Region "Event Handlers"
    Shared Sub AppExit(ByVal sender As Object, ByVal e As ExitEventArgs)
        MessageBox.Show("App has exited")
    End Sub

    Shared Sub AppStartUp(ByVal sender As Object, ByVal e As StartupEventArgs)
        ' Check the incoming command-line arguments and see if they 
        ' specified a flag for /GODMODE.
        Application.Current.Properties("GodMode") = False
        For Each arg As String In e.Args
            If arg.ToLower() = "/godmode" Then
                Application.Current.Properties("GodMode") = True
                Exit For
            End If
        Next

        ' Create a MainWindow object. 
        Dim wnd As New MainWindow("My better WPF App!", 200, 300)
        wnd.Show()
    End Sub
#End Region
End Class