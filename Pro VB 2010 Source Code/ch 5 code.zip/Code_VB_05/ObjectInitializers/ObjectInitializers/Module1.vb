﻿Module Module1
    Sub Main()
        Console.WriteLine("***** Fun with Object Init Syntax *****" & vbLf)

        ' Make a Point by setting each property manually.
        Dim firstPoint As New Point()
        firstPoint.X = 10
        firstPoint.Y = 10
        firstPoint.DisplayStats()

        ' Or make a Point via a custom constructor.
        Dim anotherPoint As New Point(20, 20)
        anotherPoint.DisplayStats()

        ' Or make some Point types using the new object init syntax.
        Dim finalPoint As New Point With {.X = 30, .Y = 30}
        finalPoint.DisplayStats()

        ' Create and initialize a Rectangle.
        Dim myRect As New Rectangle With { _
        .TopLeft = New Point With {.X = 10, .Y = 10}, _
        .BottomRight = New Point With {.X = 200, .Y = 200}}

        myRect.DisplayStats()

        Console.ReadLine()
    End Sub
End Module
