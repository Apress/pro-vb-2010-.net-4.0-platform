﻿
Partial Class Rectangle

    Public Property TopLeft() As Point
    Public Property BottomRight() As Point


    Public Sub DisplayStats()
        Console.WriteLine("[TopLeft: {0}, {1}, {2} BottomRight: {3}, {4}, {5}]", TopLeft.X, TopLeft.Y, TopLeft.Color, BottomRight.X, BottomRight.Y, _
         BottomRight.Color)
    End Sub
End Class

