﻿Public Enum PointColor
    LightBlue
    BloodRed
    Gold
End Enum

Public Class Point
    Public Property X() As Integer
    Public Property Y() As Integer
    Public Property Color() As PointColor
        
    Public Sub New(ByVal xVal As Integer, ByVal yVal As Integer)
        X = xVal
        Y = yVal
        Color = PointColor.Gold
    End Sub
    Public Sub New(ByVal ptColor As PointColor)
        Color = ptColor
    End Sub
    Public Sub New()
        Color = PointColor.BloodRed
    End Sub

    Public Sub DisplayStats()
        Console.WriteLine("[{0}, {1}]", X, Y)
        Console.WriteLine("Point is {0}", Color)
    End Sub
End Class
