﻿Public Module TimeUtilModule
    Public Sub PrintTime()
        Console.WriteLine(DateTime.Now.ToShortTimeString())
    End Sub
    Public Sub PrintDate()
        Console.WriteLine(DateTime.Today.ToShortDateString())
    End Sub
End Module
Public Class TimeUtilClass2
    ' Redefine the default ctor as Private
    ' to prevent creation.
    Private Sub New()
    End Sub

    Public Shared Sub PrintTime()
        Console.WriteLine(DateTime.Now.ToShortTimeString())
    End Sub
    Public Shared Sub PrintDate()
        Console.WriteLine(DateTime.Today.ToShortDateString())
    End Sub
End Class

' Define type as MustInherit to prevent
' creation
MustInherit Class TimeUtilClass3
    Public Shared Sub PrintTime()
        Console.WriteLine(DateTime.Now.ToShortTimeString())
    End Sub
    Public Shared Sub PrintDate()
        Console.WriteLine(DateTime.Today.ToShortDateString())
    End Sub
End Class