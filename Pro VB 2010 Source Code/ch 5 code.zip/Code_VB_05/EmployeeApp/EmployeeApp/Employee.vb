﻿Public Class Employee
    ' Field data.
    Private empName As String
    Private empID As Integer
    Private currPay As Single
    Private empAge As Integer
    Private empSSN As String
    Private Shared companyName As String

#Region "Constructors"
    Public Sub New()
    End Sub
    Public Sub New(ByVal n As String, ByVal i As Integer, ByVal p As Single)
        Me.New(n, 0, i, p, "")
    End Sub
    Public Sub New(ByVal n As String, ByVal a As Integer, ByVal i As Integer, ByVal p As Single, ByVal s As String)
        ' Better!  Use properties when setting class data.
        ' This reduces the amount of duplicate error checks.
        Name = n
        Age = a
        ID = i
        Pay = p
        SocialSecurityNumber = s
    End Sub
    Shared Sub New()
        companyName = "Intertech Training"
    End Sub
#End Region

#Region "Methods"
    Public Sub GiveBonus(ByVal amount As Single)
        Pay += amount
    End Sub

    Public Sub DisplayStats()
        Console.WriteLine("Name: {0}", Name)
        Console.WriteLine("ID: {0}", ID)
        Console.WriteLine("Age: {0}", Age)
        Console.WriteLine("Pay: {0}", Pay)
        Console.WriteLine("SSN: {0}", SocialSecurityNumber)
    End Sub

    ' This would be a compiler error if you uncomment,
    ' as the SocialSecurityNumber property resolves to 
    ' these methods internally!
    'Public Function get_SocialSecurityNumber() As String
    '     Return empSSN
    ' End Function
    ' Public Sub set_SocialSecurityNumber(ByVal ssn As String)
    '     empSSN = ssn
    ' End Sub
#End Region

#Region "Properties"
    Public Shared Property Company() As String
        Get
            Return companyName
        End Get
        Set(ByVal value As String)
            companyName = value
        End Set
    End Property

    Public Property Name() As String
        Get
            Return empName
        End Get
        Set(ByVal value As String)
            ' Here, value is really a string.
            If value.Length > 15 Then
                Console.WriteLine("Error!  Name must be less than 15 characters!")
            Else
                empName = value
            End If
        End Set
    End Property

    Public Property ID() As Integer
        Get
            Return empID
        End Get
        Set(ByVal value As Integer)
            empID = value
        End Set
    End Property

    Public Property Pay() As Single
        Get
            Return currPay
        End Get
        Set(ByVal value As Single)
            currPay = value
        End Set
    End Property

    Public Property Age() As Integer
        Get
            Return empAge
        End Get
        Set(ByVal value As Integer)
            empAge = value
        End Set
    End Property

    Public Property SocialSecurityNumber() As String
        Get
            Return empSSN
        End Get
        Set(ByVal value As String)
            empSSN = value
        End Set
    End Property
#End Region
End Class

