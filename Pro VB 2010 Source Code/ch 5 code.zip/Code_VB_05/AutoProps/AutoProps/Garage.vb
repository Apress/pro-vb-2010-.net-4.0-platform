﻿Public Class Garage
    ' The hidden backing field is set to zero!
    Public Property NumberOfCars() As Integer
       
    ' The hidden backing field is set to Nothing!
    Public Property MyAuto() As Car
       
    ' Must use constructors to override default 
    ' values assigned to hidden backing fields.
    Public Sub New()
        MyAuto = New Car()
        NumberOfCars = 1
    End Sub

    Public Sub New(ByVal car As Car, ByVal number As Integer)
        MyAuto = car
        NumberOfCars = number
    End Sub
End Class
