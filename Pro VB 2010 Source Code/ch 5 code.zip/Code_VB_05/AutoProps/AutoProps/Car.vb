﻿Public Class Car
    ' Automatic properties!
    Public Property PetName() As String
    Public Property Speed() As Integer
    Public Property Color() As String
       

    Public Sub DisplayStats()
        Console.WriteLine("Car Name: {0}", PetName)
        Console.WriteLine("Speed: {0}", Speed)
        Console.WriteLine("Color: {0}", Color)
    End Sub
End Class
