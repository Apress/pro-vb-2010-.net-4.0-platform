﻿Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Automatic Properties *****" & vbLf)

        ' Make a car.
        Dim c As New Car()
        c.PetName = "Frank"
        c.Speed = 55
        c.Color = "Red"
        c.DisplayStats()

        ' Put car in the garage.
        Dim g As New Garage()
        g.MyAuto = c
        Console.WriteLine("Number of Cars in garage: {0}", g.NumberOfCars)
        Console.WriteLine("Your car is named: {0}", g.MyAuto.PetName)

        Console.ReadLine()
    End Sub

End Module
