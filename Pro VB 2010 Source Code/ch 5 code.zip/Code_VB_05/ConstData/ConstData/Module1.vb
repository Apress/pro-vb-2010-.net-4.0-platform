﻿Class MyMathClass
    Public Shared ReadOnly PI As Double

    Shared Sub New()
        PI = 3.14
    End Sub

End Class
Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Const *****" & vbLf)
        Console.WriteLine("The value of PI is: {0}", MyMathClass.PI)

        ' Error! Can't change a constant!
        ' MyMathClass.PI = 3.1444;

        Console.ReadLine()
    End Sub
    ' This is just for a test.
    Sub LocalConstStringVariable()
        ' A local constant data point can be directly accessed.
        Const fixedStr As String = "Fixed string Data"
        Console.WriteLine(fixedStr)

        ' Error!
        ' fixedStr = "This will not work!"
    End Sub
End Module
