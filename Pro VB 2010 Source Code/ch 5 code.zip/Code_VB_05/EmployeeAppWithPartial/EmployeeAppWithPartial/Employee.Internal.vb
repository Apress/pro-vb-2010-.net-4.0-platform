﻿Public Class Employee
    'Field Constructor
#Region "Constructors"
    Public Sub New()
    End Sub
    Public Sub New(ByVal n As String, ByVal i As Integer, ByVal p As Single)
        Me.New(n, 0, i, p, "")
    End Sub
    Public Sub New(ByVal n As String, ByVal a As Integer, ByVal i As Integer, ByVal p As Single, ByVal s As String)
        ' Better!  Use properties when setting class data.
        ' This reduces the amount of duplicate error checks.
        Name = n
        Age = a
        ID = i
        Pay = p
        SocialSecurityNumber = s
    End Sub
    Shared Sub New()
        companyName = "Intertech Training"
    End Sub
#End Region

#Region "Properties"
    Public Shared Property Company() As String

    Public Property Name() As String
        Get
            Return empName
        End Get
        Set(ByVal value As String)

            If value.Length > 15 Then
                Console.WriteLine("Error!  Name must be less than 15 characters!")
            Else
                empName = value
            End If
        End Set
    End Property

    Public Property ID() As Integer

    Public Property Pay() As Single
        
    Public Property Age() As Integer
      
    Public Property SocialSecurityNumber() As String
      
#End Region
End Class
