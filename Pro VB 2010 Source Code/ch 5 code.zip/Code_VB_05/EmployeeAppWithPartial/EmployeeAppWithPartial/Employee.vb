﻿Partial Class Employee
    ' Field data.
    Private empName As String
    Private empID As Integer
    Private currPay As Single
    Private empAge As Integer
    Private empSSN As String
    Private Shared companyName As String

#Region "Methods"
    Public Sub GiveBonus(ByVal amount As Single)
        Pay += amount
    End Sub

    Public Sub DisplayStats()
        Console.WriteLine("Name: {0}", Name)
        Console.WriteLine("ID: {0}", ID)
        Console.WriteLine("Age: {0}", Age)
        Console.WriteLine("Pay: {0}", Pay)
        Console.WriteLine("SSN: {0}", SocialSecurityNumber)
    End Sub
#End Region
End Class
