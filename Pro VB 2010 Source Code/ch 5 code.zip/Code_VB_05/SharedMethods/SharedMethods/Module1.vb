﻿Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Shared Methods *****" & vbLf)
        For i = 0 To 5
            Console.WriteLine(Teenager.Complain())
        Next
        Console.ReadLine()
    End Sub

End Module
