﻿Imports CarLibrary

Module Module1
    Sub Main()
        Console.WriteLine("***** Shared Assembly Client *****")
        Dim c As New SportsCar()
        c.TurboBoost()
        Console.ReadLine()
    End Sub
End Module
