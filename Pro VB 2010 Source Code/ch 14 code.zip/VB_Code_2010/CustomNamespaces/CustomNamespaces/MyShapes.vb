﻿Namespace MyShapes
    'Circle class
    Public Class Circle
        'Interesting methods...
    End Class
    'Hexagon class
    Public Class Hexagon
        'More interesting methods...
    End Class
    'Square class
    Public Class Square
        'Even more interesting methods...
    End Class
End Namespace
'Another shape-centric namespace.
Namespace My3DShapes
    '3D Circle class
    Public Class Circle
    End Class
    '3D Hexagon class
    Public Class Hexagon
    End Class
    '3D Square class
    Public Class Square
    End Class
End Namespace
