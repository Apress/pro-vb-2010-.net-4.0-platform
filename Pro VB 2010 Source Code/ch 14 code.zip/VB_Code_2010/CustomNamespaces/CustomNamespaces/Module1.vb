﻿Imports MyShapes
Imports My3DShapes

'Resolve the ambiguity using a custom alias.
Imports The3DHexagon = My3DShapes.Hexagon
Imports bfHome = System.Runtime.Serialization.Formatters.Binary

Namespace CustomNamespaces
    Module Module1

        Sub Main()
            Console.WriteLine("***** Custom Namespaces *****")
            Console.WriteLine("This program has no real output,")
            Console.WriteLine("but the code files illustrate how")
            Console.WriteLine("to work with custom namespaces.")
            'This is really creating a My3DShapes.Hexagon object.
            Dim h2 As New The3DHexagon()
            Dim b As New bfHome.BinaryFormatter()
            Console.ReadLine()
        End Sub

    End Module
End Namespace


