﻿Namespace AirVehicles
    Public Class Helicopter
        Public Sub TakeOff()
            Console.WriteLine("Helicopter taking off!")
        End Sub
    End Class
End Namespace
