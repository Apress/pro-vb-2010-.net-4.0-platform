﻿Imports AirVehicles

Module Client

    Sub Main()
        Console.WriteLine("***** Multifile Assembly Client *****")
        Dim h As New Helicopter()
        h.TakeOff()
        'This will load the *.netmodule on demand.
        Dim u As New Ufo()
        u.AbductHuman()
        Console.ReadLine()
    End Sub

End Module
