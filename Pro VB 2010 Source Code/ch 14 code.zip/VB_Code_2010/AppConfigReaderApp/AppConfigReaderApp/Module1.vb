﻿Imports System.Configuration

Module Module1

    Sub Main()
        Console.WriteLine("***** Reading <appSettings> Data *****" & vbLf)

        'Get our custom data from the *.config file. 
        Dim ar As New AppSettingsReader()
        Dim numbOfTimes As Integer = CInt(ar.GetValue("RepeatCount", GetType(Integer)))
        Dim textColor As String = CStr(ar.GetValue("TextColor", GetType(String)))
        Console.ForegroundColor = CInt([Enum].Parse(GetType(ConsoleColor), textColor))

        'Now print a message correctly. 
        For i = 0 To numbOfTimes - 1
            Console.WriteLine("Howdy!")
        Next
        Console.ReadLine()
    End Sub

End Module
