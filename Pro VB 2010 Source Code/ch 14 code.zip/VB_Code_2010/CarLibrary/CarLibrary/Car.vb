﻿
Imports System.Windows.Forms

'Which type of music player does this car have?
Public Enum MusicMedia
    musicCd
    musicTape
    musicRadio
    musicMp3
End Enum
'Represents the state of the engine.
Public Enum EngineState
    engineAlive
    engineDead
End Enum
'The MustInherit base class in the hierarchy.
Public MustInherit Class Car
    Public Property PetName() As String
    Public Property CurrentSpeed() As Integer
    Public Property MaxSpeed() As Integer

    Protected egnState As EngineState = EngineState.engineAlive
    Public ReadOnly Property EngineState() As EngineState
        Get
            Return egnState
        End Get
    End Property
    Public MustOverride Sub TurboBoost()
    Public Sub New()
        MessageBox.Show("CarLibrary Version 2.0!")
    End Sub
    Public Sub New(ByVal name As String, ByVal maxSp As Integer, ByVal currSp As Integer)
        MessageBox.Show("CarLibrary Version 2.0!")
        PetName = name
        MaxSpeed = maxSp
        CurrentSpeed = currSp
    End Sub
    Public Sub TurnOnRadio(ByVal musicOn As Boolean, ByVal mm As MusicMedia)
        If musicOn Then
            MessageBox.Show(String.Format("Jamming {0}", mm))
        Else
            MessageBox.Show("Quiet time....")
        End If
    End Sub
End Class

