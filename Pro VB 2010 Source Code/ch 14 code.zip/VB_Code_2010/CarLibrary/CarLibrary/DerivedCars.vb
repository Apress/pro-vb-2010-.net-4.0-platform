﻿Imports System.Windows.Forms

Public Class SportsCar
    Inherits Car
    Public Sub New()
    End Sub
    Public Sub New(ByVal name As String, ByVal maxSp As Integer, ByVal currSp As Integer)
        MyBase.New(name, maxSp, currSp)
    End Sub
    Public Overloads Overrides Sub TurboBoost()
        MessageBox.Show("Ramming speed!", "Faster is better...")
    End Sub
    Public Overloads Sub TurnOnRadio(ByVal turnOn As Boolean, ByVal volumn As Integer)
        MessageBox.Show("Cranking tunes!")
    End Sub
End Class
Public Class MiniVan
    Inherits Car
    Public Sub New()
    End Sub
    Public Sub New(ByVal name As String, ByVal maxSp As Integer, ByVal currSp As Integer)
        MyBase.New(name, maxSp, currSp)
    End Sub
    Public Overrides Sub TurboBoost()
        'Minivans have poor turbo capabilities!
        egnState = EngineState.engineDead
        MessageBox.Show("Eek!", "Your engine block exploded!")
    End Sub
End Class

