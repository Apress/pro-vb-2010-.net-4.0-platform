﻿Public Class UserShoppingCart
    Public desiredCar As String
    Public desiredCarColor As String
    Public downPayment As Single
    Public isLeasing As Boolean
    Public dateOfPickUp As Date

    Public Overrides Function ToString() As String
        Return String.Format("Car: {0}<br>Color: {1}<br>$ Down: {2}<br>Lease: {3}<br>Pick-up Date: {4}", desiredCar, desiredCarColor, downPayment, isLeasing, dateOfPickUp.ToShortDateString())
    End Function
End Class