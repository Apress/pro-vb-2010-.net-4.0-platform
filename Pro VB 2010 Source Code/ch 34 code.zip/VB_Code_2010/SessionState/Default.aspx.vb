﻿Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
      
        ' Set current user prefs.
        Dim u As UserShoppingCart = CType(Session("UserShoppingCartInfo"), UserShoppingCart)
        u.dateOfPickUp = myCalendar.SelectedDate
        u.desiredCar = txtCarMake.Text
        u.desiredCarColor = txtCarColor.Text
        u.downPayment = Single.Parse(txtDownPayment.Text)
        u.isLeasing = chkIsLeasing.Checked
        lblUserInfo.Text = u.ToString()
        Session("UserShoppingCartInfo") = u

        lblUserID.Text = String.Format("Here is your ID: {0}", Session.SessionID)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
End Class
