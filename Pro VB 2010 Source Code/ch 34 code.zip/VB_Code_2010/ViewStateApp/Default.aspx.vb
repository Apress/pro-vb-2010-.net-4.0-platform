﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            ' Fill ListBox dynamically!
            myListBox.Items.Add("Item One")
            myListBox.Items.Add("Item Two")
            myListBox.Items.Add("Item Three")
            myListBox.Items.Add("Item Four")
        End If

    End Sub

    Protected Sub btnPostback_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnPostback.Click
        ' No-op. This is just here to allow a post back.

    End Sub

    Protected Sub btnAddToVS_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAddToVS.Click
        ViewState("CustomViewStateItem") = "Some user data"
        lblVSValue.Text = CStr(ViewState("CustomViewStateItem"))

    End Sub
End Class
