﻿Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub btnShowAppVariables_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnShowAppVariables.Click
        Dim appVars As CarLotInfo = (CType(Application("CarSiteInfo"), CarLotInfo))
        Dim appState As String = String.Format("<li>Car on sale: {0}</li>", appVars.currentCarOnSale)
        appState &= String.Format("<li>Most popular color: {0}</li>", appVars.mostPopularColorOnLot)
        appState &= String.Format("<li>Big shot SalesPerson: {0}</li>", appVars.salesPersonOfTheMonth)
        lblAppVariables.Text = appState
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    End Sub

    Protected Sub btnSetNewSP_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSetNewSP.Click
        ' Set the new Salesperson.
        CType(Application("CarSiteInfo"), CarLotInfo).salesPersonOfTheMonth = txtNewSP.Text
    End Sub
End Class
