﻿Public Class CarLotInfo

    Public Sub New(ByVal s As String, ByVal c As String, ByVal m As String)
        salesPersonOfTheMonth = s
        currentCarOnSale = c
        mostPopularColorOnLot = m
    End Sub

    ' Public for easy access.
    Public salesPersonOfTheMonth As String
    Public currentCarOnSale As String
    Public mostPopularColorOnLot As String
End Class