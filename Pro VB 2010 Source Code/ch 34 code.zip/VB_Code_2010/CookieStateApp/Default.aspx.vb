﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub btnCookie_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCookie.Click
        ' Make a new (temp) cookie.
        Dim theCookie As New HttpCookie(txtCookieName.Text, txtCookieValue.Text)
        theCookie.Expires = Date.Parse("10/24/2010")
        Response.Cookies.Add(theCookie)

    End Sub

    Protected Sub btnShowCookie_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnShowCookie.Click
        Dim cookieData As String = ""
        For Each s In Request.Cookies
            cookieData &= String.Format("<li><b>Name</b>: {0}, <b>Value</b>: {1}</li>", s, Request.Cookies(s).Value)
        Next
        lblCookieData.Text = cookieData

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
End Class
