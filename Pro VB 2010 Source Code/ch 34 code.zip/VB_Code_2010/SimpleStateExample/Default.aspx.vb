﻿Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub btnSetCar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSetCar.Click
        ' Store fav car in member variable.
        ' userFavoriteCar = txtFavCar.Text
        Session("UserFavCar") = txtFavCar.Text

    End Sub

    Protected Sub btnGetCar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGetCar.Click
        ' Show value of member variable.
        ' lblFavCar.Text = userFavoriteCar
        lblFavCar.Text = CStr(Session("UserFavCar"))

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
End Class
