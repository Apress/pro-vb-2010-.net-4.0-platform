﻿<Serializable()>
Public Class UserAddress
    Public Street As String = String.Empty
    Public City As String = String.Empty
    Public State As String = String.Empty
End Class