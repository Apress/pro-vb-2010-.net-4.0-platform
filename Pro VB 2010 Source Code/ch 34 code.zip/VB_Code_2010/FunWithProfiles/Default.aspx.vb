﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' Database writes happening here!
        Profile.AddressInfo.City = txtCity.Text
        Profile.AddressInfo.Street = txtStreetAddress.Text
        Profile.AddressInfo.State = txtState.Text

        ' Get settings from database.
        GetUserAddress()
    End Sub

    Private Sub GetUserAddress()
        ' Database reads happening here!
        lblUserData.Text = String.Format("You live here: {0}, {1}, {2}", Profile.AddressInfo.Street, Profile.AddressInfo.City, Profile.AddressInfo.State)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        GetUserAddress()
    End Sub
End Class
