﻿Imports System.Windows.Forms

#Region "Our Window"
' This is our main window.
Public Class MainWindow
    Inherits Form
    '  Members for a simple menu system.
    Private mnuMainMenu As New MenuStrip()
    Private mnuFile As New ToolStripMenuItem()
    Private mnuFileExit As New ToolStripMenuItem()

    Public Sub New()
    End Sub
    Public Sub New(ByVal title As String, ByVal height As Integer, ByVal width As Integer)
        ' Set various properties from our parent classes.
        Text = title
        Me.Width = width
        Me.Height = height

        ' Inherited method to center the form on the screen.
        CenterToScreen()

        ' Method to create our menu system.
        BuildMenuSystem()

    End Sub

#Region "Build the menu system"
    Private Sub BuildMenuSystem()
        ' Add the File menu item to the main menu.
        mnuFile.Text = "&File"
        mnuMainMenu.Items.Add(mnuFile)

        ' Now add the Exit menu to the File menu.
        mnuFileExit.Text = "E&xit"
        mnuFile.DropDownItems.Add(mnuFileExit)
        AddHandler mnuFileExit.Click, Sub(o, s)
                                          MessageBox.Show(String.Format("{0} sent this event", o.ToString()))
                                          Application.Exit()
                                      End Sub

        ' Finally, set the menu for this Form.
        Controls.Add(Me.mnuMainMenu)
        MainMenuStrip = Me.mnuMainMenu
    End Sub
#End Region

    Private Sub InitializeComponent()
        Me.SuspendLayout()
        '
        'MainWindow
        '
        Me.ClientSize = New System.Drawing.Size(292, 273)
        Me.Name = "MainWindow"
        Me.Text = "From1"
        Me.ResumeLayout(False)

    End Sub
End Class
#End Region

Module Module1
    Sub Main()
        Application.Run(New MainWindow("My Window", 200, 300))
    End Sub
End Module
