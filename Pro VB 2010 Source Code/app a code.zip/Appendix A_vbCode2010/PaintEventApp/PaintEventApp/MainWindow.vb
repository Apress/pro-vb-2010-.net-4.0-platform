﻿Public Class MainWindow

    Private Sub MainWindow_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles MyBase.Paint
        ' Get the graphics object for this Form. 
        Dim g As Graphics = e.Graphics

        ' Draw a circle.
        g.FillEllipse(Brushes.Blue, 10, 20, 150, 80)

        ' Draw a string in a custom font.
        g.DrawString("Hello GDI+", New Font("Times New Roman", 30), Brushes.Red, 200, 200)

        ' Draw a line with a custom pen.
        Using p As New Pen(Color.YellowGreen, 10)
            g.DrawLine(p, 80, 4, 200, 200)
        End Using


    End Sub
End Class
