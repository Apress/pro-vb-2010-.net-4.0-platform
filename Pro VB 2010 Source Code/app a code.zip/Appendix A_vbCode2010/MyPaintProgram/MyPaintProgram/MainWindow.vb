﻿Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary

Public Class MainWindow

    ' Current shape / color to draw.
    Private currentShape As SelectedShape
    Private currentColor As Color = Color.DarkBlue

    ' This maintains each ShapeData.
    Private shapes As New List(Of ShapeData)()

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles SaveToolStripMenuItem.Click
        Using saveDlg As New SaveFileDialog()
            ' Configure the look and feel of the save dialog.
            saveDlg.InitialDirectory = "."
            saveDlg.Filter = "Shape files (*.shapes)|*.shapes"
            saveDlg.RestoreDirectory = True
            saveDlg.FileName = "MyShapes"

            ' If they click the OK button, open the new
            ' file and serialize the List().
            If saveDlg.ShowDialog() = DialogResult.OK Then
                Dim myStream As Stream = saveDlg.OpenFile()
                If (myStream IsNot Nothing) Then
                    ' Save the shapes!
                    Dim myBinaryFormat As New BinaryFormatter()
                    myBinaryFormat.Serialize(myStream, shapes)
                    myStream.Close()
                End If
            End If
        End Using

    End Sub

    Private Sub LoadToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles LoadToolStripMenuItem.Click
        Using openDlg As New OpenFileDialog()
            openDlg.InitialDirectory = "."
            openDlg.Filter = "Shape files (*.shapes)|*.shapes"
            openDlg.RestoreDirectory = True
            openDlg.FileName = "MyShapes"

            If openDlg.ShowDialog() = DialogResult.OK Then
                Dim myStream As Stream = openDlg.OpenFile()
                If (myStream IsNot Nothing) Then
                    ' Get the shapes!
                    Dim myBinaryFormat As New BinaryFormatter()
                    shapes = CType(myBinaryFormat.Deserialize(myStream), List(Of ShapeData))
                    myStream.Close()
                    Invalidate()
                End If
            End If
        End Using

    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ExitToolStripMenuItem.Click
        Close()
    End Sub

    Private Sub PickShapesToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles PickShapesToolStripMenuItem.Click
        Dim dlg As New ShapePickerDialog()
        If DialogResult.OK = dlg.ShowDialog() Then
            currentShape = dlg.SelectedShape
        End If

    End Sub

    Private Sub PickColorToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles PickColorToolStripMenuItem.Click
        Dim dlg As New ColorDialog()

        If dlg.ShowDialog() = DialogResult.OK Then
            currentColor = dlg.Color
        End If

    End Sub

    Private Sub ClearSurfaceToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ClearSurfaceToolStripMenuItem.Click
        shapes.Clear()

        ' This will fire the paint event.
        Invalidate()

    End Sub

#Region "Form events"


    Private Sub MainWindow_MouseClick(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseClick
        ' Make a ShapeData type based on current user
        ' selections.
        Dim sd As New ShapeData()
        sd.ShapeType = currentShape
        sd.Color = currentColor
        sd.UpperLeftPoint = New Point(e.X, e.Y)

        ' Add to the List(Of T) and forse the form to repaint itself. 
        shapes.Add(sd)
        Invalidate()

    End Sub

    Private Sub MainWindow_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles MyBase.Paint

        ' Get the Graphics type for this window.
        Dim g As Graphics = e.Graphics

        ' Render each shape in the selected color. 
        For Each s In shapes
            ' Render a rectangle or circle 20 x 20 pixels in size
            ' using the correct color. 
            If s.ShapeType = SelectedShape.Rectangle Then
                g.FillRectangle(New SolidBrush(s.Color), s.UpperLeftPoint.X, s.UpperLeftPoint.Y, 20, 20)
            Else
                g.FillEllipse(New SolidBrush(s.Color), s.UpperLeftPoint.X, s.UpperLeftPoint.Y, 20, 20)
            End If
        Next
    End Sub

#End Region

End Class
