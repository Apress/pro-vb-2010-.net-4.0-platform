﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ShapePickerDialog
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.radioButtonRect = New System.Windows.Forms.RadioButton()
        Me.groupBox1 = New System.Windows.Forms.GroupBox()
        Me.radioButtonCircle = New System.Windows.Forms.RadioButton()
        Me.groupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnOK
        '
        Me.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.btnOK.Location = New System.Drawing.Point(255, 50)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(75, 23)
        Me.btnOK.TabIndex = 4
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(336, 50)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 3
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'radioButtonRect
        '
        Me.radioButtonRect.AutoSize = True
        Me.radioButtonRect.Location = New System.Drawing.Point(146, 29)
        Me.radioButtonRect.Name = "radioButtonRect"
        Me.radioButtonRect.Size = New System.Drawing.Size(74, 17)
        Me.radioButtonRect.TabIndex = 1
        Me.radioButtonRect.TabStop = True
        Me.radioButtonRect.Text = "Rectangle"
        Me.radioButtonRect.UseVisualStyleBackColor = True
        '
        'groupBox1
        '
        Me.groupBox1.Controls.Add(Me.radioButtonRect)
        Me.groupBox1.Controls.Add(Me.radioButtonCircle)
        Me.groupBox1.Location = New System.Drawing.Point(11, 30)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(226, 64)
        Me.groupBox1.TabIndex = 5
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Select Shape"
        '
        'radioButtonCircle
        '
        Me.radioButtonCircle.AutoSize = True
        Me.radioButtonCircle.Location = New System.Drawing.Point(7, 29)
        Me.radioButtonCircle.Name = "radioButtonCircle"
        Me.radioButtonCircle.Size = New System.Drawing.Size(51, 17)
        Me.radioButtonCircle.TabIndex = 0
        Me.radioButtonCircle.TabStop = True
        Me.radioButtonCircle.Text = "Circle"
        Me.radioButtonCircle.UseVisualStyleBackColor = True
        '
        'ShapePickerDialog
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(419, 103)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.groupBox1)
        Me.Name = "ShapePickerDialog"
        Me.Text = "ShapePickerDialog"
        Me.groupBox1.ResumeLayout(False)
        Me.groupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents btnOK As System.Windows.Forms.Button
    Private WithEvents btnCancel As System.Windows.Forms.Button
    Private WithEvents radioButtonRect As System.Windows.Forms.RadioButton
    Private WithEvents groupBox1 As System.Windows.Forms.GroupBox
    Private WithEvents radioButtonCircle As System.Windows.Forms.RadioButton
End Class
