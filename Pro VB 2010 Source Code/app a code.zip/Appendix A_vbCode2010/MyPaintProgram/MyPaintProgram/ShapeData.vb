﻿<Serializable()>
Public Class ShapeData
    ' The upper left of the shape to be drawn.
    Public Property UpperLeftPoint() As Point

    ' The current color of the shape to be drawn.
    Public Property Color() As Color

    ' The type of shape.
    Public Property ShapeType() As SelectedShape
End Class