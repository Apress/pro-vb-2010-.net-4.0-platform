﻿' The two shapes which can be rendered by this 
' application.
Public Enum SelectedShape
    Circle
    Rectangle
End Enum

Public Class ShapePickerDialog
    Public Property SelectedShape() As SelectedShape

    Private Sub btnOK_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnOK.Click
        If radioButtonCircle.Checked Then
            SelectedShape = SelectedShape.Circle
        Else
            SelectedShape = SelectedShape.Rectangle
        End If

    End Sub
End Class