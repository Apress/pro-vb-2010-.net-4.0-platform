﻿Public Class MainWindow

    Private Sub MainWindow_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseDown
        ' Which mouse button was clicked?
        If e.Button = MouseButtons.Left Then
            MessageBox.Show("Left click!")
        End If
        If e.Button = MouseButtons.Right Then
            MessageBox.Show("Right click!")
        End If
        If e.Button = MouseButtons.Middle Then
            MessageBox.Show("Middle click!")
        End If

    End Sub

    Private Sub MainWindow_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles MyBase.KeyDown
        Text = String.Format("Key Pressed: {0} Modifiers: {1}", e.KeyCode.ToString(), e.Modifiers.ToString())

    End Sub

    Private Sub MainWindow_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseMove
        Text = String.Format("Mouse Position: {0}", e.Location)

    End Sub
End Class

