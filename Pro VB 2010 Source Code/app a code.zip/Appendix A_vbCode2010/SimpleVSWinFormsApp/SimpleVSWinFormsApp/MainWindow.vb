﻿Public Class MainWindow

    Private lifeTimeInfo As String = String.Empty

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ExitToolStripMenuItem.Click
        ' Application.Exit()
        Close()
    End Sub

    Private Sub MainWindow_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        lifeTimeInfo &= "Load event" & vbLf

    End Sub

    Private Sub MainWindow_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs) Handles MyBase.FormClosed
        lifeTimeInfo &= "Closed event" & vbLf
        MessageBox.Show(lifeTimeInfo)

    End Sub

    Private Sub MainWindow_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        lifeTimeInfo &= "Closing event" & vbLf

        ' Show a message box with Yes and No buttons.
        Dim dr As DialogResult = MessageBox.Show("Do you REALLY want to close this app?", "Closing event!", MessageBoxButtons.YesNo)

        ' Which button was clicked?
        If dr = System.Windows.Forms.DialogResult.No Then
            e.Cancel = True
        Else
            e.Cancel = False
        End If

    End Sub

    Private Sub MainWindow_Activated(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Activated
        lifeTimeInfo &= "Activate event" & vbLf

    End Sub

    Private Sub MainWindow_Deactivate(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Deactivate
        lifeTimeInfo &= "Deactivate event" & vbLf

    End Sub
End Class