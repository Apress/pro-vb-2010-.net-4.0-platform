﻿Public Class ImageOrderAutoDialog
    Inherits CarOrderApp.OrderAutoDialog

End Class