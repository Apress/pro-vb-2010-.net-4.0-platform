﻿Public Class OrderAutoDialog
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        Me.AcceptButton = btnOK
    End Sub
End Class