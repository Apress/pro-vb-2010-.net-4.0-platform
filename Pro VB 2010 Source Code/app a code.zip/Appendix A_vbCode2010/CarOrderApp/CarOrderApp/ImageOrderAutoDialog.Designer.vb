﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ImageOrderAutoDialog
    Inherits CarOrderApp.OrderAutoDialog

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtPrice
        '
        Me.txtPrice.TabIndex = 2
        '
        'txtColor
        '
        Me.txtColor.TabIndex = 1
        '
        'txtMake
        '
        Me.txtMake.TabIndex = 0
        '
        'pictureBox1
        '
        Me.pictureBox1.Image = Global.CarOrderApp.My.Resources.Resources.Lemon1
        Me.pictureBox1.Location = New System.Drawing.Point(255, 12)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(118, 86)
        Me.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox1.TabIndex = 8
        Me.pictureBox1.TabStop = False
        '
        'ImageOrderAutoDialog
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(385, 168)
        Me.Controls.Add(Me.pictureBox1)
        Me.Name = "ImageOrderAutoDialog"
        Me.Controls.SetChildIndex(Me.pictureBox1, 0)
        Me.Controls.SetChildIndex(Me.txtMake, 0)
        Me.Controls.SetChildIndex(Me.txtColor, 0)
        Me.Controls.SetChildIndex(Me.txtPrice, 0)
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private pictureBox1 As System.Windows.Forms.PictureBox
End Class
