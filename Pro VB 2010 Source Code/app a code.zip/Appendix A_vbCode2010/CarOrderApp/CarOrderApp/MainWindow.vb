﻿Public Class MainWindow

    
    Private Sub OrderAutomobileToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles OrderAutomobileToolStripMenuItem.Click
        ' Create your dialog object.
        Dim dlg As New ImageOrderAutoDialog()

        ' Show as modal dialog, and figure out which button 
        ' they clicked on using the DialogResult return value.
        If dlg.ShowDialog() = DialogResult.OK Then
            ' Get values in each text box?
            Dim orderInfo As String = String.Format("Make: {0}, Color: {1}, Cost: {2}", dlg.txtMake.Text, dlg.txtColor.Text, dlg.txtPrice.Text)
            MessageBox.Show(orderInfo, "Information about your order!")
        End If
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ExitToolStripMenuItem.Click
        Close()
    End Sub
End Class
