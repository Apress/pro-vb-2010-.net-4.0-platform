﻿Module Program

    Sub Main()
        Console.WriteLine("***** Fun with Polymorphism *****" & vbLf)
        'Make an array of Shape-compatible objects.
        Dim myShapes As Shape() = {New Hexagon(), New Circle(), New Hexagon("Mick"), New Circle("Beth"), New Hexagon("Linda")}
        'Loop over each item and interact with the
        ' polymorphic interface.
        For Each s As Shape In myShapes
            s.Draw()
        Next
        'This calls the Draw() method of the ThreeDCircle.
        Dim o As New ThreeDCircle()
        o.Draw()
        ' This calls the Draw() method of the parent!
        DirectCast(o, Circle).Draw()

        Console.ReadLine()
    End Sub

End Module
