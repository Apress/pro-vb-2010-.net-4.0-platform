﻿Public MustInherit Class Shape
    Public Sub New()
        PetName = "NoName"
    End Sub
    Public Sub New(ByVal name As String)
        PetName = name
    End Sub
    ' A single Overridable   method.
    Public Overridable Sub Draw()
        Console.WriteLine("Inside Shape.Draw()")
    End Sub
    Public Property PetName() As String
End Class

#Region "Circle class"
' If we did not implement the Overrides Draw() method, Circle would also be
' considered Overrides !
Public Class Circle
    Inherits Shape
    Public Sub New()
    End Sub
    Public Sub New(ByVal name As String)
        MyBase.New(name)
    End Sub
    'Public Overrides Sub Draw()
    '    Console.WriteLine("Drawing {0} the Circle", PetName)
    'End Sub
End Class
#End Region


#Region "Hexagon class"
' Hexagon DOES Overrides Draw().
Public Class Hexagon
    Inherits Shape
    Public Sub New()
    End Sub
    Public Sub New(ByVal name As String)
        MyBase.New(name)
    End Sub
    Public Overrides Sub Draw()
        Console.WriteLine("Drawing {0} the Hexagon", PetName)
    End Sub
End Class
#End Region


#Region "ThreeDCircle class"
' This class extends Circle and hides the inherited Draw() method.
Public Class ThreeDCircle
    Inherits Circle
    ' Hide any Draw() implementation above me.
    Public Shadows Sub Draw()
        Console.WriteLine("Drawing a 3D Circle")
    End Sub
    Public Shadows Property PetName() As String

End Class
#End Region
