﻿Partial Public MustInherit Class Employee
    ' Field data.
    Protected empName As String
    Protected empID As Integer
    Protected currPay As Single
    Protected empAge As Integer
    Protected empSSN As String
    Protected Shared companyName As String

    ' Contain a BenefitPackage object.
    Protected empBenefits As New BenefitPackage()

    ' Expose certain benefit behaviors of object.
    Public Function GetBenefitCost() As Double
        Return empBenefits.ComputePayDeduction()
    End Function

    ' Expose object through a custom property.
    Public Property Benefits() As BenefitPackage
        Get
            Return empBenefits
        End Get
        Set(ByVal value As BenefitPackage)
            empBenefits = value
        End Set
    End Property

#Region "Methods"
    Public Overridable Sub GiveBonus(ByVal amount As Single)
        Pay += amount
    End Sub

    Public Overridable Sub DisplayStats()
        Console.WriteLine("Name: {0}", Name)
        Console.WriteLine("ID: {0}", ID)
        Console.WriteLine("Age: {0}", Age)
        Console.WriteLine("Pay: {0}", Pay)
        Console.WriteLine("SSN: {0}", SocialSecurityNumber)
    End Sub

    ' This would be a compiler error if you uncomment,
    ' as the SocialSecurityNumber Property resolves to 
    ' these methods internally!
    'Public Function get_SocialSecurityNumber() As String
    '    Return empSSN
    'End Function
    'Public Sub set_SocialSecurityNumber(ByVal ssn As String)
    '    empSSN = ssn
    'End Sub
#End Region

    ' BenefitPackage nests BenefitPackageLevel.
    Public Class BenefitPackage
        Public Enum BenefitPackageLevel
            Standard
            Gold
            Platinum
        End Enum
        Public Function ComputePayDeduction() As Double
            Return 125
        End Function
    End Class
End Class