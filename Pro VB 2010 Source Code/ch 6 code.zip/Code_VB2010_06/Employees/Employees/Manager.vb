﻿Public Class Manager
    Inherits Employee

    Public Property StockOptions() As Integer

    Public Sub New(ByVal fullName As String, ByVal age As Integer, ByVal empID As Integer, ByVal currPay As Single, ByVal ssn As String, ByVal numbOfOpts As Integer)
        MyBase.New(fullName, age, empID, currPay, ssn)
        ' This field is defined by the Manager class.
        Me.StockOptions = numbOfOpts

        'Assign incoming parameters using the
        'Inherited properties of the Parent class.
        Me.ID = empID
        Me.Age = age
        Me.Name = fullName
        Me.Pay = currPay

        'OOPS! This would be a compiler error,
        'if the SSN property were read-only!
        Me.SocialSecurityNumber = ssn

    End Sub
    ' Add back the default ctor
    Public Sub New()
    End Sub

    Public Overrides Sub GiveBonus(ByVal amount As Single)
        MyBase.GiveBonus(amount)
        Dim r As New Random()
        StockOptions += r.Next(500)
    End Sub

    Public Overrides Sub DisplayStats()
        MyBase.DisplayStats()
        Console.WriteLine("Number of Stock Options: {0}", StockOptions)
    End Sub
End Class
