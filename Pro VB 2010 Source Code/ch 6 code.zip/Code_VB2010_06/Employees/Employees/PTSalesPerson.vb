﻿NotInheritable Class PTSalesPerson
    Inherits SalesPerson
    Public Sub New(ByVal fullName As String, ByVal age As Integer, ByVal empID As Integer, ByVal currPay As Single, ByVal ssn As String, ByVal numbOfSales As Integer)
        MyBase.New(fullName, age, empID, currPay, ssn, numbOfSales)
    End Sub

    ' No bonus for you! Error!
    'Public  Overrides Sub GiveBonus(ByVal amount As Single)
    '     ' Rats. Can't change this method any further.
    ' End Sub
End Class