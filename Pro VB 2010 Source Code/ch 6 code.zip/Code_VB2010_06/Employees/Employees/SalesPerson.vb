﻿Public Class SalesPerson
    Inherits Employee

    Public Property SalesNumber() As Integer
     
    ' As a general rule, all subclasses should explicitly call an appropriate
    ' base class constructor.
    Public Sub New(ByVal fullName As String, ByVal age As Integer, ByVal empID As Integer, ByVal currPay As Single, ByVal ssn As String, ByVal numbOfSales As Integer)
        MyBase.New(fullName, age, empID, currPay, ssn)
        ' This belongs with us!
        Me.SalesNumber = numbOfSales
    End Sub

    ' Be sure to add back a default constructor for
    ' the Manager and SalesPerson types.

    Public Sub New()
    End Sub

    ' A salesperson's bonus is influenced by the number of sales.
    Public Overrides Sub GiveBonus(ByVal amount As Single)
        Dim salesBonus As Integer = 0
        If SalesNumber >= 0 AndAlso SalesNumber <= 100 Then
            salesBonus = 10
        Else
            If SalesNumber >= 101 AndAlso SalesNumber <= 200 Then
                salesBonus = 15
            Else
                salesBonus = 20
            End If
        End If
        MyBase.GiveBonus(amount * salesBonus)
    End Sub

    Public Overrides Sub DisplayStats()
        MyBase.DisplayStats()
        Console.WriteLine("Number of Sales: {0}", SalesNumber)
    End Sub


End Class

