﻿Public Class Employee
#Region "Constructors"
    Public Sub New()
    End Sub
    Public Sub New(ByVal name As String, ByVal id As Integer, ByVal pay As Single)
        Me.New(name, 0, id, pay, "")
    End Sub
    Public Sub New(ByVal name As String, ByVal age As Integer, ByVal id As Integer, ByVal pay As Single, ByVal ssn As String)
        ' Better!  Use properties when setting class data.
        ' This reduces the amount of duplicate error checks.
        Me.Name = name
        Me.Age = age
        Me.ID = id
        Me.Pay = pay
        Me.SocialSecurityNumber = ssn
    End Sub
    Shared Sub New()
        companyName = "Intertech Training"
    End Sub
#End Region

#Region "Properties"
    Public Shared Property Company() As String
        Get
            Return companyName
        End Get
        Set(ByVal value As String)
            companyName = value
        End Set
    End Property

    Public Property Name() As String
        Get
            Return empName
        End Get
        Set(ByVal value As String)
            ' Here, value is really a string.
            If value.Length > 15 Then
                Console.WriteLine("Error!  Name must be less than 15 characters!")
            Else
                empName = value
            End If
        End Set
    End Property

    Public Property ID() As Integer
        Get
            Return empID
        End Get
        Set(ByVal value As Integer)
            empID = value
        End Set
    End Property

    Public Property Pay() As Single
        Get
            Return currPay
        End Get
        Set(ByVal value As Single)
            currPay = value
        End Set
    End Property

    Public Property Age() As Integer
        Get
            Return empAge
        End Get
        Set(ByVal value As Integer)
            empAge = value
        End Set
    End Property

    Public Property SocialSecurityNumber() As String
        Get
            Return empSSN
        End Get
        Set(ByVal value As String)
            empSSN = value
        End Set
    End Property
#End Region
End Class


