﻿' This example illustrates the details of building 
' class heirarchies.

' We are enabling this option to ensure that we must
' explicitly cast 
Option Strict On
Module Program
    Sub Main()
        Console.WriteLine("***** The Employee Class Hierarchy *****" & vbLf)
        ' Assume Manager has a constructor matching this signature:
        'ByVal fullName As String, ByVal age As Integer, ByVal empID As 
        'Integer, ByVal currPay As Single, ByVal ssn As String, ByVal 'numbOfOpts As Integer

        Dim chucky As New Manager("Chucky", 50, 92, 100000, "333-23-2322", 9000)
        chucky.GiveBonus(300)
        chucky.DisplayStats()
        Console.WriteLine()

        Dim danny As New SalesPerson()
        danny.Age = 31
        danny.Name = "Danny"
        danny.SalesNumber = 50

        danny.GiveBonus(200)
        danny.DisplayStats()

        CastingExamples()

        Console.ReadLine()
    End Sub
   
    Sub CastingExamples()
        ' A Manager "is-a" System.Object, so we can 
        ' store a Manager reference in an Object variable just fine.
        Dim frank As Object = New Manager("Frank Zappa", 9, 3000, 40000, "111-11-1111", 5)
        GivePromotion(DirectCast(frank, Manager))

        ' A Manager "is-an" Employee too.
        Dim moonUnit As Employee = New Manager("MoonUnit Zappa", 2, 3001, 20000, "101-11-1321", 1)
        GivePromotion(moonUnit)

        ' A PTSalesPerson "is-a" SalesPerson.
        Dim jill As SalesPerson = New PTSalesPerson("Jill", 834, 3002, 100000, "111-12-1119", 90)
        GivePromotion(jill)
    End Sub

    Sub GivePromotion(ByVal emp As Employee)
        Console.WriteLine("{0} was promoted!", emp.Name)

        If TypeOf emp Is SalesPerson Then
            Console.WriteLine("{0} made {1} sale(s)!", emp.Name, (DirectCast(emp, SalesPerson)).SalesNumber)
            Console.WriteLine()
        End If
        If TypeOf emp Is Manager Then
            Console.WriteLine("{0} had {1} stock options...", emp.Name, (DirectCast(emp, Manager)).StockOptions)
            Console.WriteLine()
        End If
    End Sub

End Module
