﻿Module Module1

    Sub Main()


        'Wait for Enter Key to exit
        Console.ReadLine()



    End Sub

    Public Sub ConfigureCUI()

    End Sub

End Module
