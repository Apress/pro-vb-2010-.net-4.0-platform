﻿
Public Class SportsCar
    Inherits Car

End Class
