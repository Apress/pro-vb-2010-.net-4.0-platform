﻿
Public Class Car
    Public petName As String




End Class
