﻿''' <summary>
''' Interaction logic for MainWindow.xaml
''' </summary>
''' <remarks></remarks>
Public Class MainWindow
    Private Enum SelectedShape
        Circle
        Rectangle
        Line
    End Enum
    Private currentShape As SelectedShape

    Private isFlipped As Boolean = False

#Region "Add item to canvas"
    Private Sub canvasDrawingArea_MouseLeftButtonDown(ByVal sender As Object, ByVal e As MouseButtonEventArgs) Handles canvasDrawingArea.MouseDown
        Dim shapeToRender As Shape = Nothing

        ' configure the correct shape to draw.
        Select Case currentShape
            Case SelectedShape.Circle
                shapeToRender = New Ellipse() With {
                 .Height = 35, _
                 .Width = 35 _
                }
                Dim brush As New RadialGradientBrush()
                brush.GradientStops.Add(New GradientStop(DirectCast(ColorConverter.ConvertFromString("#FF87E71B"), Color), 0.589))
                brush.GradientStops.Add(New GradientStop(DirectCast(ColorConverter.ConvertFromString("#FF2BA92B"), Color), 0.013))
                brush.GradientStops.Add(New GradientStop(DirectCast(ColorConverter.ConvertFromString("#FF34B71B"), Color), 1))
                shapeToRender.Fill = brush

            Case SelectedShape.Rectangle
                shapeToRender = New Rectangle() With { _
                 .Fill = Brushes.Red, _
                 .Height = 35, _
                 .Width = 35, _
                 .RadiusX = 10, _
                 .RadiusY = 10 _
                }

            Case SelectedShape.Line
                shapeToRender = New Line() With { _
                 .Stroke = Brushes.Blue, _
                 .StrokeThickness = 10, _
                 .X1 = 0, _
                 .X2 = 50, _
                 .Y1 = 0, _
                 .Y2 = 50, _
                 .StrokeStartLineCap = PenLineCap.Triangle, _
                 .StrokeEndLineCap = PenLineCap.Round _
                }

            Case Else
                Return
        End Select

        If isFlipped Then
            Dim rotate As New RotateTransform(-180)
            shapeToRender.RenderTransform = rotate
        End If

        ' Set top / left to draw in the canvas. 
        Canvas.SetLeft(shapeToRender, e.GetPosition(canvasDrawingArea).X)
        Canvas.SetTop(shapeToRender, e.GetPosition(canvasDrawingArea).Y)

        ' Draw shape!
        canvasDrawingArea.Children.Add(shapeToRender)
    End Sub

#End Region

#Region "Button click handlers"
    Private Sub circleOption_Click(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles circleOption.Click
        currentShape = SelectedShape.Circle
    End Sub

    Private Sub rectOption_Click(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles rectOption.Click
        currentShape = SelectedShape.Rectangle
    End Sub

    Private Sub lineOption_Click(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles lineOption.Click
        currentShape = SelectedShape.Line
    End Sub
#End Region

#Region "Remove item from canvas."
    Private Sub canvasDrawingArea_MouseRightButtonDown(ByVal sender As Object, ByVal e As MouseButtonEventArgs) Handles canvasDrawingArea.MouseRightButtonDown

        ' First, get the X,Y location of where the user clicked.
        Dim pt As Point = e.GetPosition(DirectCast(sender, Canvas))

        ' Use the HitTest() method of VisualTreeHelper to see if the user clicked
        ' on an item in the canvas. 
        Dim result As HitTestResult = VisualTreeHelper.HitTest(canvasDrawingArea, pt)

        ' If the result is not null, they DID click on a shape!
        If result IsNot Nothing Then
            ' Get the underlying shape clicked on, and remove it from 
            ' the canvas. 
            canvasDrawingArea.Children.Remove(TryCast(result.VisualHit, Shape))
        End If
    End Sub
#End Region

#Region "Flip!"
    Private Sub flipCanvas_Click(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles flipCanvas.Click
        If flipCanvas.IsChecked = True Then
            Dim rotate As New RotateTransform(-180)
            canvasDrawingArea.LayoutTransform = rotate
            isFlipped = True
        Else
            canvasDrawingArea.LayoutTransform = Nothing
            isFlipped = False
        End If
    End Sub
#End Region
End Class