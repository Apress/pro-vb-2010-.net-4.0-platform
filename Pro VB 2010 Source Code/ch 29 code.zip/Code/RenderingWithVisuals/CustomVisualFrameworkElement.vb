﻿Class CustomVisualFrameworkElement
    Inherits FrameworkElement
    ' A collection of all the visuals we are building.
    Private theVisuals As VisualCollection

#Region "Fill the VisualCollection"
    Public Sub New()
        ' Fill the VisualCollection with a few DrawingVisual objects.
        theVisuals = New VisualCollection(Me)
        theVisuals.Add(AddRect())
        theVisuals.Add(AddCircle())

        ' Handle the MouseDown event.
        AddHandler Me.MouseDown, AddressOf MyVisualHost_MouseDown
    End Sub

    Private Function AddCircle() As Visual
        Dim drawingVisual As New DrawingVisual()

        ' Retrieve the DrawingContext in order to create new drawing content.
        Using drawingContext As DrawingContext = drawingVisual.RenderOpen()

            ' Create a rectangle and draw it in the DrawingContext.
            Dim rect As New Rect(New Point(160, 100), New Size(320, 80))
            drawingContext.DrawEllipse(Brushes.DarkBlue, Nothing, New Point(70, 90), 40, 50)
        End Using
        Return drawingVisual
    End Function

    Private Function AddRect() As Visual
        Dim drawingVisual As New DrawingVisual()

        ' Retrieve the DrawingContext in order to create new drawing content.
        Using drawingContext As DrawingContext = drawingVisual.RenderOpen()

            ' Create a rectangle and draw it in the DrawingContext.
            Dim rect As New Rect(New Point(160, 100), New Size(320, 80))
            drawingContext.DrawRectangle(Brushes.Tomato, Nothing, rect)
        End Using
        Return drawingVisual
    End Function
#End Region

#Region "Required overrides"
    Protected Overrides ReadOnly Property VisualChildrenCount() As Integer
        Get
            Return theVisuals.Count
        End Get
    End Property

    Protected Overrides Function GetVisualChild(ByVal index As Integer) As Visual
        ' Value must be creater than zero, so do a sainity check.
        If index < 0 OrElse index >= theVisuals.Count Then
            Throw New ArgumentOutOfRangeException()
        End If

        Return theVisuals(index)
    End Function
#End Region

#Region "Hit testing logic"
    Private Sub MyVisualHost_MouseDown(ByVal sender As Object, ByVal e As MouseButtonEventArgs)
        ' Figure out where the user clicked.
        Dim pt As Point = e.GetPosition(DirectCast(sender, UIElement))

        ' Call helper function via delegate to see if we clicked on a visual.
        VisualTreeHelper.HitTest(Me, Nothing,
                                 New HitTestResultCallback(AddressOf myCallback),
                                 New PointHitTestParameters(pt))
    End Sub

    Public Function myCallback(ByVal result As HitTestResult) As HitTestResultBehavior
        ' Toggle between a skewed rendering and normal rendering,
        ' if a visual was clicked. 
        If result.VisualHit.GetType() = GetType(DrawingVisual) Then
            If DirectCast(result.VisualHit, DrawingVisual).Transform Is Nothing Then
                DirectCast(result.VisualHit, DrawingVisual).Transform = New SkewTransform(7, 7)
            Else
                DirectCast(result.VisualHit, DrawingVisual).Transform = Nothing
            End If
        End If

        ' Tell HitTest() to stop drilling into the visual tree.
        Return HitTestResultBehavior.Stop
    End Function
#End Region
End Class