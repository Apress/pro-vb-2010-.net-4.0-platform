﻿''' <summary>
''' Interaction logic for Application.xaml
''' </summary>
Public Class Application
End Class