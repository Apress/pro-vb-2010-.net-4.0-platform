﻿''' <summary>
''' Interaction logic for MainWindow.xaml
''' </summary>
Public Class MainWindow

#Region "Loaded handler"
    Private Sub Window_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles MyBase.Loaded
        Const TextFontSize As Integer = 30

        ' Make a System.Windows.Media.FormattedText object.
        Dim text As New FormattedText("Hello Visual Layer!",
                                      New System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight,
                                      New Typeface(Me.FontFamily,
                                                   FontStyles.Italic,
                                                   FontWeights.DemiBold,
                                                   FontStretches.UltraExpanded), TextFontSize, Brushes.Green)

        ' Create a DrawingVisual, and obtain the DrawingContext.
        Dim drawingVisual As New DrawingVisual()
        Using drawingContext As DrawingContext = drawingVisual.RenderOpen()
            ' Now, call any of the methods of DrawingContext to render data. 
            drawingContext.DrawRoundedRectangle(Brushes.Yellow,
                                                New Pen(Brushes.Black, 5),
                                                New Rect(5, 5, 450, 100), 20, 20)
            drawingContext.DrawText(text, New Point(20, 20))
        End Using

        ' Dynamically make a bitmap, using the data in the DrawingVisual.
        Dim bmp As New RenderTargetBitmap(500, 100, 100, 90, PixelFormats.Pbgra32)
        bmp.Render(drawingVisual)

        ' Set the source of the Image control!
        myImage.Source = bmp
    End Sub
#End Region
End Class