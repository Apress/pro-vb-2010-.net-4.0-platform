﻿
Public Class Car
    ' Constant for maximum speed.
    Public Const MaxSpeed As Integer = 100

    ' Car properties.
    Public Property CurrentSpeed() As Integer
    Public Property PetName() As String

    ' Is the car still operational?
    Private carIsDead As Boolean

    ' A car has-a radio.
    Private theMusicBox As New Radio()

    ' Constructors.
    Public Sub New()
    End Sub
    Public Sub New(ByVal name As String, ByVal speed As Integer)
        CurrentSpeed = speed
        PetName = name
    End Sub

    Public Sub CrankTunes(ByVal state As Boolean)
        ' Delegate request to inner object.
        theMusicBox.TurnOn(state)
    End Sub

    ' See if Car has overheated.
    Public Sub Accelerate(ByVal delta As Integer)
        If carIsDead Then
            Console.WriteLine("{0} is out of order...", PetName)
        Else
            CurrentSpeed += delta
            If CurrentSpeed > MaxSpeed Then
                Console.WriteLine("{0} has overheated!", PetName)
                CurrentSpeed = 0
                carIsDead = True
            Else
                Console.WriteLine("=> CurrentSpeed = {0}", CurrentSpeed)
            End If
        End If
    End Sub
End Class
