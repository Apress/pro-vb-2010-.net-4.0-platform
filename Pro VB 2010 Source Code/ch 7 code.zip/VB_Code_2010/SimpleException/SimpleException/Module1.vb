﻿Module Module1

    Sub Main()
        Console.WriteLine("***** Simple Exception Example *****")
        Console.WriteLine("=> Creating a car and stepping on it!")
        Dim myCar As New Car("Zippy", 20)
        myCar.CrankTunes(True)

        ' Speed up past the car's max speed to
        ' trigger the exception.
        Try
            For i As Integer = 0 To 9
                myCar.Accelerate(10)
            Next
        Catch e As Exception
            Console.WriteLine(vbLf & "*** Error! ***")
            Console.WriteLine("Member name: {0}", e.TargetSite)
            Console.WriteLine("Class defining member: {0}", e.TargetSite.DeclaringType)
            Console.WriteLine("Member type: {0}", e.TargetSite.MemberType)
            Console.WriteLine("Message: {0}", e.Message)
            Console.WriteLine("Source: {0}", e.Source)
            Console.WriteLine("Stack: {0}", e.StackTrace)
            Console.WriteLine("Help Link: {0}", e.HelpLink)

            ' By default, the data field is empty, so check for null.
            Console.WriteLine(vbLf & "-> Custom Data:")
            If e.Data IsNot Nothing Then
                For Each de As DictionaryEntry In e.Data
                    Console.WriteLine("-> {0}: {1}", de.Key, de.Value)
                Next
            End If
        End Try
        Console.ReadLine()
    End Sub

End Module
