﻿Public Class Car

    ' Constant for maximum speed.
    Public Const MaxSpeed As Integer = 100

    ' Car properties.
    Public Property CurrentSpeed() As Integer

    Public Property PetName() As String

    ' Is the car still operational?
    Private carIsDead As Boolean

    ' A car has-a radio.
    Private theMusicBox As New Radio()

    ' Constructors.
    Public Sub New()
    End Sub

    Public Sub New(ByVal name As String, ByVal speed As Integer)
        CurrentSpeed = speed
        PetName = name
    End Sub

    Public Sub CrankTunes(ByVal state As Boolean)
        ' Delegate request to inner object.
        theMusicBox.TurnOn(state)
    End Sub

    ' See if Car has overheated.
    Public Sub Accelerate(ByVal delta As Integer)
        If delta < 0 Then
            Throw New ArgumentOutOfRangeException("delta", "Speed must be greater than zero!")
        End If

        If carIsDead Then
            Console.WriteLine("{0} is out of order...", PetName)
        Else
            CurrentSpeed += delta
            If CurrentSpeed >= MaxSpeed Then
                carIsDead = True
                CurrentSpeed = 0

                ' We need to call the HelpLink property, thus we need
                ' to create a local variable before throwing the Exception object.
                Dim ex As New CarIsDeadException(String.Format("{0} has overheated!", PetName), "You have a lead foot", DateTime.Now)
                ex.HelpLink = "http://www.CarsRUs.com"
                Throw ex
            Else
                Console.WriteLine("=> CurrentSpeed = {0}", CurrentSpeed)
            End If
        End If
    End Sub

End Class
