﻿Module Module1

    Sub Main()
        Console.WriteLine("***** Handling Multiple Exceptions *****" & vbLf)
        Dim myCar As New Car("Rusty", 90)
      Try
            ' Speed up car logic.

        Catch e As CarIsDeadException
            ' Process CarIsDeadException.

        Catch e As ArgumentOutOfRangeException
            ' Process ArgumentOutOfRangeException.

        Catch e As Exception
            ' This will catch any other exception
            ' beyond CarIsDeadException or ArgumentOutOfRangeException.

        Finally
            ' This will always occur. Exception or not.
            myCar.CrankTunes(False)

        End Try
        Console.ReadLine()
    End Sub

End Module
