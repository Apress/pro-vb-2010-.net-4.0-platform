﻿
<System.Serializable()> _
Public Class CarIsDeadException
    Inherits ApplicationException

    Public Sub New()
    End Sub

    Public Sub New(ByVal message As String)
        MyBase.New(message)
    End Sub

    Public Sub New(ByVal message As String, ByVal inner As Exception)
        MyBase.New(message, inner)
    End Sub

    Protected Sub New(ByVal info As System.Runtime.Serialization.SerializationInfo, ByVal context As System.Runtime.Serialization.StreamingContext)
        MyBase.New(info, context)
    End Sub

    ' Custom members for our exception.
    Public Property ErrorTimeStamp() As DateTime

    Public Property CauseOfError() As String

    Public Sub New(ByVal message As String, ByVal cause As String, ByVal time As DateTime)
        MyBase.New(message)
        CauseOfError = cause
        ErrorTimeStamp = time
    End Sub

End Class


