﻿Module Module1

    Sub Main()
        Console.WriteLine("***** Fun with Custom Exceptions *****" & vbLf)
        Dim myCar As New Car("Rusty", 90)

        Try
            ' Trip exception.
            myCar.Accelerate(50)
        Catch e As CarIsDeadException
            Console.WriteLine(e.Message)
            Console.WriteLine(e.ErrorTimeStamp)
            Console.WriteLine(e.CauseOfError)
        End Try
        Console.ReadLine()

    End Sub

End Module
