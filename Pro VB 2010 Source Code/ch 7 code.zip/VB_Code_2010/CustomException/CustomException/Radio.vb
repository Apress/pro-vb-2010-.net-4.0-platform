﻿Public Class Radio

    Public Sub TurnOn(ByVal IsOn As Boolean)
        If IsOn Then
            Console.WriteLine("Jamming...")
        Else
            Console.WriteLine("Quiet time...")
        End If
    End Sub
End Class
