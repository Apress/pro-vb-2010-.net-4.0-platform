﻿Partial Class ValidationGroups
    Inherits System.Web.UI.Page


    Protected Sub bntValidateRequired_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntValidateRequired.Click

    End Sub

    Protected Sub btnValidateSSN_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnValidateSSN.Click

    End Sub
End Class