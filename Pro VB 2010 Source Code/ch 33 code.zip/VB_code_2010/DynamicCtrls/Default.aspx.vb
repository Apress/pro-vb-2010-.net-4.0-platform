﻿Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ListControlsInPanel()

    End Sub

#Region "List controls in the Panel"
    Private Sub ListControlsInPanel()
        Dim theInfo As String = ""
        theInfo = String.Format("<b>Does the panel have controls? {0} </b><br/>", myPanel.HasControls())

        ' Get all controls in the panel.
        For Each c As Control In myPanel.Controls
            If Not Object.ReferenceEquals(c.GetType(), GetType(System.Web.UI.LiteralControl)) Then
                theInfo &= "***************************<br/>"
                theInfo &= String.Format("Control Name? {0} <br/>", c.ToString())
                theInfo &= String.Format("ID? {0} <br>", c.ID)
                theInfo &= String.Format("Control Visible? {0} <br/>", c.Visible)
                theInfo &= String.Format("ViewState? {0} <br/>", c.EnableViewState)
            End If
        Next c
        lblControlInfo.Text = theInfo
    End Sub
#End Region

#Region "Add / remove items to panel"
    Protected Sub btnClearPanel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClearPanel.Click
        ' Clear all content from the panel, then re-list items.
        myPanel.Controls.Clear()
        ListControlsInPanel()
    End Sub

    Protected Sub btnAddWidgets_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAddWidgets.Click
        For i = 0 To 2
            ' Assign a name so we can get
            ' the text value out later
            ' using the incoming form data.
            Dim t As New TextBox()
            t.ID = String.Format("newTextBox{0}", i)
            myPanel.Controls.Add(t)
            ListControlsInPanel()
        Next
    End Sub
#End Region

#Region "Get data in dynamic text boxes"
    Protected Sub btnGetTextData_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGetTextData.Click
        ' Get teach text box by name.
        Dim lableData As String = String.Format("<li>{0}</li><br/>", Request.Form.Get("newTextBox0"))
        lableData &= String.Format("<li>{0}</li><br/>", Request.Form.Get("newTextBox1"))
        lableData &= String.Format("<li>{0}</li><br/>", Request.Form.Get("newTextBox2"))
        lblTextBoxData.Text = lableData
    End Sub

#End Region

End Class
